
if (typeof(window['CODES']) === 'undefined') {
    window['CODES'] = {}
}
window['CODES']['9deadc5f-e649-41fd-898d-4e8707e71dcb'] = '<div class="9deadc5f-e649-41fd-898d-4e8707e71dcb pre"><span class="line-1 line"><span class="lineno">   1 </span><span class="cm">/*</span><sup class="after"></sup>\n' + 
'</span><span class="line-2 line"><span class="lineno">   2 </span><span class="cm"> * sar, sadc, sadf, mpstat and iostat common routines.</span><sup class="after"></sup>\n' + 
'</span><span class="line-3 line"><span class="lineno">   3 </span><span class="cm"> * (C) 1999-2018 by Sebastien GODARD (sysstat &lt;at&gt; orange.fr)</span><sup class="after"></sup>\n' + 
'</span><span class="line-4 line"><span class="lineno">   4 </span><span class="cm"> *</span><sup class="after"></sup>\n' + 
'</span><span class="line-5 line"><span class="lineno">   5 </span><span class="cm"> ***************************************************************************</span><sup class="after"></sup>\n' + 
'</span><span class="line-6 line"><span class="lineno">   6 </span><span class="cm"> * This program is free software; you can redistribute it and/or modify it *</span><sup class="after"></sup>\n' + 
'</span><span class="line-7 line"><span class="lineno">   7 </span><span class="cm"> * under the terms of the GNU General Public License as published  by  the *</span><sup class="after"></sup>\n' + 
'</span><span class="line-8 line"><span class="lineno">   8 </span><span class="cm"> * Free Software Foundation; either version 2 of the License, or (at  your *</span><sup class="after"></sup>\n' + 
'</span><span class="line-9 line"><span class="lineno">   9 </span><span class="cm"> * option) any later version.                                              *</span><sup class="after"></sup>\n' + 
'</span><span class="line-10 line"><span class="lineno">  10 </span><span class="cm"> *                                                                         *</span><sup class="after"></sup>\n' + 
'</span><span class="line-11 line"><span class="lineno">  11 </span><span class="cm"> * This program is distributed in the hope that it  will  be  useful,  but *</span><sup class="after"></sup>\n' + 
'</span><span class="line-12 line"><span class="lineno">  12 </span><span class="cm"> * WITHOUT ANY WARRANTY; without the implied warranty  of  MERCHANTABILITY *</span><sup class="after"></sup>\n' + 
'</span><span class="line-13 line"><span class="lineno">  13 </span><span class="cm"> * or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License *</span><sup class="after"></sup>\n' + 
'</span><span class="line-14 line"><span class="lineno">  14 </span><span class="cm"> * for more details.                                                       *</span><sup class="after"></sup>\n' + 
'</span><span class="line-15 line"><span class="lineno">  15 </span><span class="cm"> *                                                                         *</span><sup class="after"></sup>\n' + 
'</span><span class="line-16 line"><span class="lineno">  16 </span><span class="cm"> * You should have received a copy of the GNU General Public License along *</span><sup class="after"></sup>\n' + 
'</span><span class="line-17 line"><span class="lineno">  17 </span><span class="cm"> * with this program; if not, write to the Free Software Foundation, Inc., *</span><sup class="after"></sup>\n' + 
'</span><span class="line-18 line"><span class="lineno">  18 </span><span class="cm"> * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1335 USA              *</span><sup class="after"></sup>\n' + 
'</span><span class="line-19 line"><span class="lineno">  19 </span><span class="cm"> ***************************************************************************</span><sup class="after"></sup>\n' + 
'</span><span class="line-20 line"><span class="lineno">  20 </span><span class="cm"> */</span><sup class="after"></sup>\n' + 
'</span><span class="line-21 line"><span class="lineno">  21 </span><sup class="after"></sup>\n' + 
'</span><span class="line-22 line"><span class="lineno">  22 </span><span class="cp">#include</span> <span class="cpf">&lt;stdio.h&gt;</span><span class="cp"></span><sup class="after"></sup>\n' + 
'</span><span class="line-23 line"><span class="lineno">  23 </span><span class="cp">#include</span> <span class="cpf">&lt;string.h&gt;</span><span class="cp"></span><sup class="after"></sup>\n' + 
'</span><span class="line-24 line"><span class="lineno">  24 </span><span class="cp">#include</span> <span class="cpf">&lt;stdlib.h&gt;</span><span class="cp"></span><sup class="after"></sup>\n' + 
'</span><span class="line-25 line"><span class="lineno">  25 </span><span class="cp">#include</span> <span class="cpf">&lt;stdarg.h&gt;</span><span class="cp"></span><sup class="after"></sup>\n' + 
'</span><span class="line-26 line"><span class="lineno">  26 </span><span class="cp">#include</span> <span class="cpf">&lt;inttypes.h&gt;</span><span class="cp"></span><sup class="after"></sup>\n' + 
'</span><span class="line-27 line"><span class="lineno">  27 </span><span class="cp">#include</span> <span class="cpf">&lt;time.h&gt;</span><span class="cp"></span><sup class="after"></sup>\n' + 
'</span><span class="line-28 line"><span class="lineno">  28 </span><span class="cp">#include</span> <span class="cpf">&lt;errno.h&gt;</span><span class="cp"></span><sup class="after"></sup>\n' + 
'</span><span class="line-29 line"><span class="lineno">  29 </span><span class="cp">#include</span> <span class="cpf">&lt;unistd.h&gt;	/* For STDOUT_FILENO, among others */</span><span class="cp"></span><sup class="after"></sup>\n' + 
'</span><span class="line-30 line"><span class="lineno">  30 </span><span class="cp">#include</span> <span class="cpf">&lt;sys/ioctl.h&gt;</span><span class="cp"></span><sup class="after"></sup>\n' + 
'</span><span class="line-31 line"><span class="lineno">  31 </span><span class="cp">#include</span> <span class="cpf">&lt;sys/types.h&gt;</span><span class="cp"></span><sup class="after"></sup>\n' + 
'</span><span class="line-32 line"><span class="lineno">  32 </span><span class="cp">#include</span> <span class="cpf">&lt;dirent.h&gt;</span><span class="cp"></span><sup class="after"></sup>\n' + 
'</span><span class="line-33 line"><span class="lineno">  33 </span><span class="cp">#include</span> <span class="cpf">&lt;ctype.h&gt;</span><span class="cp"></span><sup class="after"></sup>\n' + 
'</span><span class="line-34 line"><span class="lineno">  34 </span><span class="cp">#include</span> <span class="cpf">&lt;libgen.h&gt;</span><span class="cp"></span><sup class="after"></sup>\n' + 
'</span><span class="line-35 line"><span class="lineno">  35 </span><sup class="after"></sup>\n' + 
'</span><span class="line-36 line"><span class="lineno">  36 </span><span class="cp">#include</span> <span class="cpf">&quot;version.h&quot;</span><span class="cp"></span><sup class="after"></sup>\n' + 
'</span><span class="line-37 line"><span class="lineno">  37 </span><span class="cp">#include</span> <span class="cpf">&quot;common.h&quot;</span><span class="cp"></span><sup class="after"></sup>\n' + 
'</span><span class="line-38 line"><span class="lineno">  38 </span><sup class="after"></sup>\n' + 
'</span><span class="line-39 line"><span class="lineno">  39 </span><span class="cp">#ifdef USE_NLS</span><sup class="after"></sup>\n' + 
'</span><span class="line-40 line"><span class="lineno">  40 </span><span class="cp">#include</span> <span class="cpf">&lt;locale.h&gt;</span><span class="cp"></span><sup class="after"></sup>\n' + 
'</span><span class="line-41 line"><span class="lineno">  41 </span><span class="cp">#include</span> <span class="cpf">&lt;libintl.h&gt;</span><span class="cp"></span><sup class="after"></sup>\n' + 
'</span><span class="line-42 line"><span class="lineno">  42 </span><span class="cp">#define _(string) gettext(string)</span><sup class="after"></sup>\n' + 
'</span><span class="line-43 line"><span class="lineno">  43 </span><span class="cp">#else</span><sup class="after"></sup>\n' + 
'</span><span class="line-44 line"><span class="lineno">  44 </span><span class="cp">#define _(string) (string)</span><sup class="after"></sup>\n' + 
'</span><span class="line-45 line"><span class="lineno">  45 </span><span class="cp">#endif</span><sup class="after"></sup>\n' + 
'</span><span class="line-46 line"><span class="lineno">  46 </span><sup class="after"></sup>\n' + 
'</span><span class="line-47 line"><span class="lineno">  47 </span><span class="cm">/* Number of decimal places */</span><sup class="after"></sup>\n' + 
'</span><span class="line-48 line"><span class="lineno">  48 </span><span class="k">extern</span> <span class="kt">int</span> <span class="n">dplaces_nr</span><span class="p">;</span><sup class="after"></sup>\n' + 
'</span><span class="line-49 line"><span class="lineno">  49 </span><sup class="after"></sup>\n' + 
'</span><span class="line-50 line"><span class="lineno">  50 </span><span class="cm">/* Units (sectors, Bytes, kilobytes, etc.) */</span><sup class="after"></sup>\n' + 
'</span><span class="line-51 line"><span class="lineno">  51 </span><span class="kt">char</span> <span class="n">units</span><span class="p">[]</span> <span class="o">=</span> <span class="p">{</span><span class="sc">&#39;s&#39;</span><span class="p">,</span> <span class="sc">&#39;B&#39;</span><span class="p">,</span> <span class="sc">&#39;k&#39;</span><span class="p">,</span> <span class="sc">&#39;M&#39;</span><span class="p">,</span> <span class="sc">&#39;G&#39;</span><span class="p">,</span> <span class="sc">&#39;T&#39;</span><span class="p">,</span> <span class="sc">&#39;P&#39;</span><span class="p">,</span> <span class="sc">&#39;?&#39;</span><span class="p">};</span><sup class="after"></sup>\n' + 
'</span><span class="line-52 line"><span class="lineno">  52 </span><sup class="after"></sup>\n' + 
'</span><span class="line-53 line"><span class="lineno">  53 </span><span class="cm">/* Number of ticks per second */</span><sup class="after"></sup>\n' + 
'</span><span class="line-54 line"><span class="lineno">  54 </span><span class="kt">unsigned</span> <span class="kt">long</span> <span class="n">hz</span><span class="p">;</span><sup class="after"></sup>\n' + 
'</span><span class="line-55 line"><span class="lineno">  55 </span><span class="cm">/* Number of bit shifts to convert pages to kB */</span><sup class="after"></sup>\n' + 
'</span><span class="line-56 line"><span class="lineno">  56 </span><span class="kt">unsigned</span> <span class="kt">int</span> <span class="n">kb_shift</span><span class="p">;</span><sup class="after"></sup>\n' + 
'</span><span class="line-57 line"><span class="lineno">  57 </span><sup class="after"></sup>\n' + 
'</span><span class="line-58 line"><span class="lineno">  58 </span><span class="cm">/* Colors strings */</span><sup class="after"></sup>\n' + 
'</span><span class="line-59 line"><span class="lineno">  59 </span><span class="kt">char</span> <span class="n">sc_percent_high</span><span class="p">[</span><span class="n">MAX_SGR_LEN</span><span class="p">]</span> <span class="o">=</span> <span class="n">C_BOLD_RED</span><span class="p">;</span><sup class="after"></sup>\n' + 
'</span><span class="line-60 line"><span class="lineno">  60 </span><span class="kt">char</span> <span class="n">sc_percent_low</span><span class="p">[</span><span class="n">MAX_SGR_LEN</span><span class="p">]</span> <span class="o">=</span> <span class="n">C_BOLD_MAGENTA</span><span class="p">;</span><sup class="after"></sup>\n' + 
'</span><span class="line-61 line"><span class="lineno">  61 </span><span class="kt">char</span> <span class="n">sc_zero_int_stat</span><span class="p">[</span><span class="n">MAX_SGR_LEN</span><span class="p">]</span> <span class="o">=</span> <span class="n">C_LIGHT_BLUE</span><span class="p">;</span><sup class="after"></sup>\n' + 
'</span><span class="line-62 line"><span class="lineno">  62 </span><span class="kt">char</span> <span class="n">sc_int_stat</span><span class="p">[</span><span class="n">MAX_SGR_LEN</span><span class="p">]</span> <span class="o">=</span> <span class="n">C_BOLD_BLUE</span><span class="p">;</span><sup class="after"></sup>\n' + 
'</span><span class="line-63 line"><span class="lineno">  63 </span><span class="kt">char</span> <span class="n">sc_item_name</span><span class="p">[</span><span class="n">MAX_SGR_LEN</span><span class="p">]</span> <span class="o">=</span> <span class="n">C_LIGHT_GREEN</span><span class="p">;</span><sup class="after"></sup>\n' + 
'</span><span class="line-64 line"><span class="lineno">  64 </span><span class="kt">char</span> <span class="n">sc_sa_restart</span><span class="p">[</span><span class="n">MAX_SGR_LEN</span><span class="p">]</span> <span class="o">=</span> <span class="n">C_LIGHT_RED</span><span class="p">;</span><sup class="after"></sup>\n' + 
'</span><span class="line-65 line"><span class="lineno">  65 </span><span class="kt">char</span> <span class="n">sc_sa_comment</span><span class="p">[</span><span class="n">MAX_SGR_LEN</span><span class="p">]</span> <span class="o">=</span> <span class="n">C_LIGHT_YELLOW</span><span class="p">;</span><sup class="after"></sup>\n' + 
'</span><span class="line-66 line"><span class="lineno">  66 </span><span class="kt">char</span> <span class="n">sc_normal</span><span class="p">[</span><span class="n">MAX_SGR_LEN</span><span class="p">]</span> <span class="o">=</span> <span class="n">C_NORMAL</span><span class="p">;</span><sup class="after"></sup>\n' + 
'</span><span class="line-67 line"><span class="lineno">  67 </span><sup class="after"></sup>\n' + 
'</span><span class="line-68 line"><span class="lineno">  68 </span><span class="cm">/* Type of persistent device names used in sar and iostat */</span><sup class="after"></sup>\n' + 
'</span><span class="line-69 line"><span class="lineno">  69 </span><span class="kt">char</span> <span class="n">persistent_name_type</span><span class="p">[</span><span class="n">MAX_FILE_LEN</span><span class="p">];</span><sup class="after"></sup>\n' + 
'</span><span class="line-70 line"><span class="lineno">  70 </span><sup class="after"></sup>\n' + 
'</span><span class="line-71 line"><span class="lineno">  71 </span><span class="cm">/*</span><sup class="after"></sup>\n' + 
'</span><span class="line-72 line"><span class="lineno">  72 </span><span class="cm"> ***************************************************************************</span><sup class="after"></sup>\n' + 
'</span><span class="line-73 line"><span class="lineno">  73 </span><span class="cm"> * Print sysstat version number and exit.</span><sup class="after"></sup>\n' + 
'</span><span class="line-74 line"><span class="lineno">  74 </span><span class="cm"> ***************************************************************************</span><sup class="after"></sup>\n' + 
'</span><span class="line-75 line"><span class="lineno">  75 </span><span class="cm"> */</span><sup class="after"></sup>\n' + 
'</span><span class="line-76 line"><span class="lineno">  76 </span><span class="kt">void</span> <span class="nf">print_version</span><span class="p">(</span><span class="kt">void</span><span class="p">)</span><sup class="after"></sup>\n' + 
'</span><span class="line-77 line"><span class="lineno">  77 </span><span class="p">{</span><sup class="after"></sup>\n' + 
'</span><span class="line-78 line"><span class="lineno">  78 </span>	<span class="n">printf</span><span class="p">(</span><span class="n">_</span><span class="p">(</span><span class="s">&quot;sysstat version %s</span><span class="se">\\n</span><span class="s">&quot;</span><span class="p">),</span> <span class="n">VERSION</span><span class="p">);</span><sup class="after"></sup>\n' + 
'</span><span class="line-79 line"><span class="lineno">  79 </span>	<span class="n">printf</span><span class="p">(</span><span class="s">&quot;(C) Sebastien Godard (sysstat &lt;at&gt; orange.fr)</span><span class="se">\\n</span><span class="s">&quot;</span><span class="p">);</span><sup class="after"></sup>\n' + 
'</span><span class="line-80 line"><span class="lineno">  80 </span>	<span class="n">exit</span><span class="p">(</span><span class="mi">0</span><span class="p">);</span><sup class="after"></sup>\n' + 
'</span><span class="line-81 line"><span class="lineno">  81 </span><span class="p">}</span><sup class="after"></sup>\n' + 
'</span><span class="line-82 line"><span class="lineno">  82 </span><sup class="after"></sup>\n' + 
'</span><span class="line-83 line"><span class="lineno">  83 </span><span class="cm">/*</span><sup class="after"></sup>\n' + 
'</span><span class="line-84 line"><span class="lineno">  84 </span><span class="cm"> ***************************************************************************</span><sup class="after"></sup>\n' + 
'</span><span class="line-85 line"><span class="lineno">  85 </span><span class="cm"> * Get local date and time.</span><sup class="after"></sup>\n' + 
'</span><span class="line-86 line"><span class="lineno">  86 </span><span class="cm"> *</span><sup class="after"></sup>\n' + 
'</span><span class="line-87 line"><span class="lineno">  87 </span><span class="cm"> * IN:</span><sup class="after"></sup>\n' + 
'</span><span class="line-88 line"><span class="lineno">  88 </span><span class="cm"> * @d_off	Day offset (number of days to go back in the past).</span><sup class="after"></sup>\n' + 
'</span><span class="line-89 line"><span class="lineno">  89 </span><span class="cm"> *</span><sup class="after"></sup>\n' + 
'</span><span class="line-90 line"><span class="lineno">  90 </span><span class="cm"> * OUT:</span><sup class="after"></sup>\n' + 
'</span><span class="line-91 line"><span class="lineno">  91 </span><span class="cm"> * @rectime	Current local date and time.</span><sup class="after"></sup>\n' + 
'</span><span class="line-92 line"><span class="lineno">  92 </span><span class="cm"> *</span><sup class="after"></sup>\n' + 
'</span><span class="line-93 line"><span class="lineno">  93 </span><span class="cm"> * RETURNS:</span><sup class="after"></sup>\n' + 
'</span><span class="line-94 line"><span class="lineno">  94 </span><span class="cm"> * Value of time in seconds since the Epoch.</span><sup class="after"></sup>\n' + 
'</span><span class="line-95 line"><span class="lineno">  95 </span><span class="cm"> ***************************************************************************</span><sup class="after"></sup>\n' + 
'</span><span class="line-96 line"><span class="lineno">  96 </span><span class="cm"> */</span><sup class="after"></sup>\n' + 
'</span><span class="line-97 line"><span class="lineno">  97 </span><span class="kt">time_t</span> <span class="nf">get_localtime</span><span class="p">(</span><span class="k">struct</span> <span class="n">tm</span> <span class="o">*</span><span class="n">rectime</span><span class="p">,</span> <span class="kt">int</span> <span class="n">d_off</span><span class="p">)</span><sup class="after"></sup>\n' + 
'</span><span class="line-98 line"><span class="lineno">  98 </span><span class="p">{</span><sup class="after"></sup>\n' + 
'</span><span class="line-99 line"><span class="lineno">  99 </span>	<span class="kt">time_t</span> <span class="n">timer</span><span class="p">;</span><sup class="after"></sup>\n' + 
'</span><span class="line-100 line"><span class="lineno"> 100 </span><sup class="after"></sup>\n' + 
'</span><span class="line-101 line"><span class="lineno"> 101 </span>	<span class="n">time</span><span class="p">(</span><span class="o">&amp;</span><span class="n">timer</span><span class="p">);</span><sup class="after"></sup>\n' + 
'</span><span class="line-102 line"><span class="lineno"> 102 </span>	<span class="n">timer</span> <span class="o">-=</span> <span class="n">SEC_PER_DAY</span> <span class="o">*</span> <span class="n">d_off</span><span class="p">;</span><sup class="after"></sup>\n' + 
'</span><span class="line-103 line"><span class="lineno"> 103 </span>	<span class="n">localtime_r</span><span class="p">(</span><span class="o">&amp;</span><span class="n">timer</span><span class="p">,</span> <span class="n">rectime</span><span class="p">);</span><sup class="after"></sup>\n' + 
'</span><span class="line-104 line"><span class="lineno"> 104 </span><sup class="after"></sup>\n' + 
'</span><span class="line-105 line"><span class="lineno"> 105 </span>	<span class="k">return</span> <span class="n">timer</span><span class="p">;</span><sup class="after"></sup>\n' + 
'</span><span class="line-106 line"><span class="lineno"> 106 </span><span class="p">}</span><sup class="after"></sup>\n' + 
'</span><span class="line-107 line"><span class="lineno"> 107 </span><sup class="after"></sup>\n' + 
'</span><span class="line-108 line"><span class="lineno"> 108 </span><span class="cm">/*</span><sup class="after"></sup>\n' + 
'</span><span class="line-109 line"><span class="lineno"> 109 </span><span class="cm"> ***************************************************************************</span><sup class="after"></sup>\n' + 
'</span><span class="line-110 line"><span class="lineno"> 110 </span><span class="cm"> * Get date and time expressed in UTC.</span><sup class="after"></sup>\n' + 
'</span><span class="line-111 line"><span class="lineno"> 111 </span><span class="cm"> *</span><sup class="after"></sup>\n' + 
'</span><span class="line-112 line"><span class="lineno"> 112 </span><span class="cm"> * IN:</span><sup class="after"></sup>\n' + 
'</span><span class="line-113 line"><span class="lineno"> 113 </span><span class="cm"> * @d_off	Day offset (number of days to go back in the past).</span><sup class="after"></sup>\n' + 
'</span><span class="line-114 line"><span class="lineno"> 114 </span><span class="cm"> *</span><sup class="after"></sup>\n' + 
'</span><span class="line-115 line"><span class="lineno"> 115 </span><span class="cm"> * OUT:</span><sup class="after"></sup>\n' + 
'</span><span class="line-116 line"><span class="lineno"> 116 </span><span class="cm"> * @rectime	Current date and time expressed in UTC.</span><sup class="after"></sup>\n' + 
'</span><span class="line-117 line"><span class="lineno"> 117 </span><span class="cm"> *</span><sup class="after"></sup>\n' + 
'</span><span class="line-118 line"><span class="lineno"> 118 </span><span class="cm"> * RETURNS:</span><sup class="after"></sup>\n' + 
'</span><span class="line-119 line"><span class="lineno"> 119 </span><span class="cm"> * Value of time in seconds since the Epoch.</span><sup class="after"></sup>\n' + 
'</span><span class="line-120 line"><span class="lineno"> 120 </span><span class="cm"> ***************************************************************************</span><sup class="after"></sup>\n' + 
'</span><span class="line-121 line"><span class="lineno"> 121 </span><span class="cm"> */</span><sup class="after"></sup>\n' + 
'</span><span class="line-122 line"><span class="lineno"> 122 </span><span class="kt">time_t</span> <span class="nf">get_gmtime</span><span class="p">(</span><span class="k">struct</span> <span class="n">tm</span> <span class="o">*</span><span class="n">rectime</span><span class="p">,</span> <span class="kt">int</span> <span class="n">d_off</span><span class="p">)</span><sup class="after"></sup>\n' + 
'</span><span class="line-123 line"><span class="lineno"> 123 </span><span class="p">{</span><sup class="after"></sup>\n' + 
'</span><span class="line-124 line"><span class="lineno"> 124 </span>	<span class="kt">time_t</span> <span class="n">timer</span><span class="p">;</span><sup class="after"></sup>\n' + 
'</span><span class="line-125 line"><span class="lineno"> 125 </span><sup class="after"></sup>\n' + 
'</span><span class="line-126 line"><span class="lineno"> 126 </span>	<span class="n">time</span><span class="p">(</span><span class="o">&amp;</span><span class="n">timer</span><span class="p">);</span><sup class="after"></sup>\n' + 
'</span><span class="line-127 line"><span class="lineno"> 127 </span>	<span class="n">timer</span> <span class="o">-=</span> <span class="n">SEC_PER_DAY</span> <span class="o">*</span> <span class="n">d_off</span><span class="p">;</span><sup class="after"></sup>\n' + 
'</span><span class="line-128 line"><span class="lineno"> 128 </span>	<span class="n">gmtime_r</span><span class="p">(</span><span class="o">&amp;</span><span class="n">timer</span><span class="p">,</span> <span class="n">rectime</span><span class="p">);</span><sup class="after"></sup>\n' + 
'</span><span class="line-129 line"><span class="lineno"> 129 </span><sup class="after"></sup>\n' + 
'</span><span class="line-130 line"><span class="lineno"> 130 </span>	<span class="k">return</span> <span class="n">timer</span><span class="p">;</span><sup class="after"></sup>\n' + 
'</span><span class="line-131 line"><span class="lineno"> 131 </span><span class="p">}</span><sup class="after"></sup>\n' + 
'</span><span class="line-132 line"><span class="lineno"> 132 </span><sup class="after"></sup>\n' + 
'</span><span class="line-133 line"><span class="lineno"> 133 </span><span class="cm">/*</span><sup class="after"></sup>\n' + 
'</span><span class="line-134 line"><span class="lineno"> 134 </span><span class="cm"> ***************************************************************************</span><sup class="after"></sup>\n' + 
'</span><span class="line-135 line"><span class="lineno"> 135 </span><span class="cm"> * Get date and time and take into account &lt;ENV_TIME_DEFTM&gt; variable.</span><sup class="after"></sup>\n' + 
'</span><span class="line-136 line"><span class="lineno"> 136 </span><span class="cm"> *</span><sup class="after"></sup>\n' + 
'</span><span class="line-137 line"><span class="lineno"> 137 </span><span class="cm"> * IN:</span><sup class="after"></sup>\n' + 
'</span><span class="line-138 line"><span class="lineno"> 138 </span><span class="cm"> * @d_off	Day offset (number of days to go back in the past).</span><sup class="after"></sup>\n' + 
'</span><span class="line-139 line"><span class="lineno"> 139 </span><span class="cm"> *</span><sup class="after"></sup>\n' + 
'</span><span class="line-140 line"><span class="lineno"> 140 </span><span class="cm"> * OUT:</span><sup class="after"></sup>\n' + 
'</span><span class="line-141 line"><span class="lineno"> 141 </span><span class="cm"> * @rectime	Current date and time.</span><sup class="after"></sup>\n' + 
'</span><span class="line-142 line"><span class="lineno"> 142 </span><span class="cm"> *</span><sup class="after"></sup>\n' + 
'</span><span class="line-143 line"><span class="lineno"> 143 </span><span class="cm"> * RETURNS:</span><sup class="after"></sup>\n' + 
'</span><span class="line-144 line"><span class="lineno"> 144 </span><span class="cm"> * Value of time in seconds since the Epoch.</span><sup class="after"></sup>\n' + 
'</span><span class="line-145 line"><span class="lineno"> 145 </span><span class="cm"> ***************************************************************************</span><sup class="after"></sup>\n' + 
'</span><span class="line-146 line"><span class="lineno"> 146 </span><span class="cm"> */</span><sup class="after"></sup>\n' + 
'</span><span class="line-147 line"><span class="lineno"> 147 </span><span class="kt">time_t</span> <span class="nf">get_time</span><span class="p">(</span><span class="k">struct</span> <span class="n">tm</span> <span class="o">*</span><span class="n">rectime</span><span class="p">,</span> <span class="kt">int</span> <span class="n">d_off</span><span class="p">)</span><sup class="after"></sup>\n' + 
'</span><span class="line-148 line"><span class="lineno"> 148 </span><span class="p">{</span><sup class="after"></sup>\n' + 
'</span><span class="line-149 line"><span class="lineno"> 149 </span>	<span class="k">static</span> <span class="kt">int</span> <span class="n">utc</span> <span class="o">=</span> <span class="mi">0</span><span class="p">;</span><sup class="after"></sup>\n' + 
'</span><span class="line-150 line"><span class="lineno"> 150 </span>	<span class="kt">char</span> <span class="o">*</span><span class="n">e</span><span class="p">;</span><sup class="after"></sup>\n' + 
'</span><span class="line-151 line"><span class="lineno"> 151 </span><sup class="after"></sup>\n' + 
'</span><span class="line-152 line"><span class="lineno"> 152 </span>	<span class="k">if</span> <span class="p">(</span><span class="o">!</span><span class="n">utc</span><span class="p">)</span> <span class="p">{</span><sup class="after"></sup>\n' + 
'</span><span class="line-153 line"><span class="lineno"> 153 </span>		<span class="cm">/* Read environment variable value once */</span><sup class="after"></sup>\n' + 
'</span><span class="line-154 line"><span class="lineno"> 154 </span>		<span class="k">if</span> <span class="p">((</span><span class="n">e</span> <span class="o">=</span> <span class="n">getenv</span><span class="p">(</span><span class="n">ENV_TIME_DEFTM</span><span class="p">))</span> <span class="o">!=</span> <span class="nb">NULL</span><span class="p">)</span> <span class="p">{</span><sup class="after"></sup>\n' + 
'</span><span class="line-155 line"><span class="lineno"> 155 </span>			<span class="n">utc</span> <span class="o">=</span> <span class="o">!</span><span class="n">strcmp</span><span class="p">(</span><span class="n">e</span><span class="p">,</span> <span class="n">K_UTC</span><span class="p">);</span><sup class="after"></sup>\n' + 
'</span><span class="line-156 line"><span class="lineno"> 156 </span>		<span class="p">}</span><sup class="after"></sup>\n' + 
'</span><span class="line-157 line"><span class="lineno"> 157 </span>		<span class="n">utc</span><span class="o">++</span><span class="p">;</span><sup class="after"></sup>\n' + 
'</span><span class="line-158 line"><span class="lineno"> 158 </span>	<span class="p">}</span><sup class="after"></sup>\n' + 
'</span><span class="line-159 line"><span class="lineno"> 159 </span><sup class="after"></sup>\n' + 
'</span><span class="line-160 line"><span class="lineno"> 160 </span>	<span class="k">if</span> <span class="p">(</span><span class="n">utc</span> <span class="o">==</span> <span class="mi">2</span><span class="p">)</span><sup class="after"></sup>\n' + 
'</span><span class="line-161 line"><span class="lineno"> 161 </span>		<span class="k">return</span> <span class="n">get_gmtime</span><span class="p">(</span><span class="n">rectime</span><span class="p">,</span> <span class="n">d_off</span><span class="p">);</span><sup class="after"></sup>\n' + 
'</span><span class="line-162 line"><span class="lineno"> 162 </span>	<span class="k">else</span><sup class="after"></sup>\n' + 
'</span><span class="line-163 line"><span class="lineno"> 163 </span>		<span class="k">return</span> <span class="n">get_localtime</span><span class="p">(</span><span class="n">rectime</span><span class="p">,</span> <span class="n">d_off</span><span class="p">);</span><sup class="after"></sup>\n' + 
'</span><span class="line-164 line"><span class="lineno"> 164 </span><span class="p">}</span><sup class="after"></sup>\n' + 
'</span><span class="line-165 line"><span class="lineno"> 165 </span><sup class="after"></sup>\n' + 
'</span><span class="line-166 line"><span class="lineno"> 166 </span><span class="cp">#ifdef USE_NLS</span><sup class="after"></sup>\n' + 
'</span><span class="line-167 line"><span class="lineno"> 167 </span><span class="cm">/*</span><sup class="after"></sup>\n' + 
'</span><span class="line-168 line"><span class="lineno"> 168 </span><span class="cm"> ***************************************************************************</span><sup class="after"></sup>\n' + 
'</span><span class="line-169 line"><span class="lineno"> 169 </span><span class="cm"> * Init National Language Support.</span><sup class="after"></sup>\n' + 
'</span><span class="line-170 line"><span class="lineno"> 170 </span><span class="cm"> ***************************************************************************</span><sup class="after"></sup>\n' + 
'</span><span class="line-171 line"><span class="lineno"> 171 </span><span class="cm"> */</span><sup class="after"></sup>\n' + 
'</span><span class="line-172 line"><span class="lineno"> 172 </span><span class="kt">void</span> <span class="nf">init_nls</span><span class="p">(</span><span class="kt">void</span><span class="p">)</span><sup class="after"></sup>\n' + 
'</span><span class="line-173 line"><span class="lineno"> 173 </span><span class="p">{</span><sup class="after"></sup>\n' + 
'</span><span class="line-174 line"><span class="lineno"> 174 </span>	<span class="n">setlocale</span><span class="p">(</span><span class="n">LC_MESSAGES</span><span class="p">,</span> <span class="s">&quot;&quot;</span><span class="p">);</span><sup class="after"></sup>\n' + 
'</span><span class="line-175 line"><span class="lineno"> 175 </span>	<span class="n">setlocale</span><span class="p">(</span><span class="n">LC_CTYPE</span><span class="p">,</span> <span class="s">&quot;&quot;</span><span class="p">);</span><sup class="after"></sup>\n' + 
'</span><span class="line-176 line"><span class="lineno"> 176 </span>	<span class="n">setlocale</span><span class="p">(</span><span class="n">LC_TIME</span><span class="p">,</span> <span class="s">&quot;&quot;</span><span class="p">);</span><sup class="after"></sup>\n' + 
'</span><span class="line-177 line"><span class="lineno"> 177 </span>	<span class="n">setlocale</span><span class="p">(</span><span class="n">LC_NUMERIC</span><span class="p">,</span> <span class="s">&quot;&quot;</span><span class="p">);</span><sup class="after"></sup>\n' + 
'</span><span class="line-178 line"><span class="lineno"> 178 </span><sup class="after"></sup>\n' + 
'</span><span class="line-179 line"><span class="lineno"> 179 </span>	<span class="n">bindtextdomain</span><span class="p">(</span><span class="n">PACKAGE</span><span class="p">,</span> <span class="n">LOCALEDIR</span><span class="p">);</span><sup class="after"></sup>\n' + 
'</span><span class="line-180 line"><span class="lineno"> 180 </span>	<span class="n">textdomain</span><span class="p">(</span><span class="n">PACKAGE</span><span class="p">);</span><sup class="after"></sup>\n' + 
'</span><span class="line-181 line"><span class="lineno"> 181 </span><span class="p">}</span><sup class="after"></sup>\n' + 
'</span><span class="line-182 line"><span class="lineno"> 182 </span><span class="cp">#endif</span><sup class="after"></sup>\n' + 
'</span><span class="line-183 line"><span class="lineno"> 183 </span><sup class="after"></sup>\n' + 
'</span><span class="line-184 line"><span class="lineno"> 184 </span><span class="cm">/*</span><sup class="after"></sup>\n' + 
'</span><span class="line-185 line"><span class="lineno"> 185 </span><span class="cm"> ***************************************************************************</span><sup class="after"></sup>\n' + 
'</span><span class="line-186 line"><span class="lineno"> 186 </span><span class="cm"> * Test whether given name is a device or a partition, using sysfs.</span><sup class="after"></sup>\n' + 
'</span><span class="line-187 line"><span class="lineno"> 187 </span><span class="cm"> * This is more straightforward that using ioc_iswhole() function from</span><sup class="after"></sup>\n' + 
'</span><span class="line-188 line"><span class="lineno"> 188 </span><span class="cm"> * ioconf.c which should be used only with kernels that don&#39;t have sysfs.</span><sup class="after"></sup>\n' + 
'</span><span class="line-189 line"><span class="lineno"> 189 </span><span class="cm"> *</span><sup class="after"></sup>\n' + 
'</span><span class="line-190 line"><span class="lineno"> 190 </span><span class="cm"> * IN:</span><sup class="after"></sup>\n' + 
'</span><span class="line-191 line"><span class="lineno"> 191 </span><span class="cm"> * @name		Device or partition name.</span><sup class="after"></sup>\n' + 
'</span><span class="line-192 line"><span class="lineno"> 192 </span><span class="cm"> * @allow_virtual	TRUE if virtual devices are also accepted.</span><sup class="after"></sup>\n' + 
'</span><span class="line-193 line"><span class="lineno"> 193 </span><span class="cm"> *			The device is assumed to be virtual if no</span><sup class="after"></sup>\n' + 
'</span><span class="line-194 line"><span class="lineno"> 194 </span><span class="cm"> *			/sys/block/&lt;device&gt;/device link exists.</span><sup class="after"></sup>\n' + 
'</span><span class="line-195 line"><span class="lineno"> 195 </span><span class="cm"> *</span><sup class="after"></sup>\n' + 
'</span><span class="line-196 line"><span class="lineno"> 196 </span><span class="cm"> * RETURNS:</span><sup class="after"></sup>\n' + 
'</span><span class="line-197 line"><span class="lineno"> 197 </span><span class="cm"> * TRUE if @name is not a partition.</span><sup class="after"></sup>\n' + 
'</span><span class="line-198 line"><span class="lineno"> 198 </span><span class="cm"> ***************************************************************************</span><sup class="after"></sup>\n' + 
'</span><span class="line-199 line"><span class="lineno"> 199 </span><span class="cm"> */</span><sup class="after"></sup>\n' + 
'</span><span class="line-200 line"><span class="lineno"> 200 </span><span class="kt">int</span> <span class="nf">is_device</span><span class="p">(</span><span class="kt">char</span> <span class="o">*</span><span class="n">name</span><span class="p">,</span> <span class="kt">int</span> <span class="n">allow_virtual</span><span class="p">)</span><sup class="after"></sup>\n' + 
'</span><span class="line-201 line"><span class="lineno"> 201 </span><span class="p">{</span><sup class="after"></sup>\n' + 
'</span><span class="line-202 line"><span class="lineno"> 202 </span>	<span class="kt">char</span> <span class="n">syspath</span><span class="p">[</span><span class="n">PATH_MAX</span><span class="p">];</span><sup class="after"></sup>\n' + 
'</span><span class="line-203 line"><span class="lineno"> 203 </span>	<span class="kt">char</span> <span class="o">*</span><span class="n">slash</span><span class="p">;</span><sup class="after"></sup>\n' + 
'</span><span class="line-204 line"><span class="lineno"> 204 </span><sup class="after"></sup>\n' + 
'</span><span class="line-205 line"><span class="lineno"> 205 </span>	<span class="cm">/* Some devices may have a slash in their name (eg. cciss/c0d0...) */</span><sup class="after"></sup>\n' + 
'</span><span class="line-206 line"><span class="lineno"> 206 </span>	<span class="k">while</span> <span class="p">((</span><span class="n">slash</span> <span class="o">=</span> <span class="n">strchr</span><span class="p">(</span><span class="n">name</span><span class="p">,</span> <span class="sc">&#39;/&#39;</span><span class="p">)))</span> <span class="p">{</span><sup class="after"></sup>\n' + 
'</span><span class="line-207 line"><span class="lineno"> 207 </span>		<span class="o">*</span><span class="n">slash</span> <span class="o">=</span> <span class="sc">&#39;!&#39;</span><span class="p">;</span><sup class="after"></sup>\n' + 
'</span><span class="line-208 line"><span class="lineno"> 208 </span>	<span class="p">}</span><sup class="after"></sup>\n' + 
'</span><span class="line-209 line"><span class="lineno"> 209 </span>	<span class="n">snprintf</span><span class="p">(</span><span class="n">syspath</span><span class="p">,</span> <span class="k">sizeof</span><span class="p">(</span><span class="n">syspath</span><span class="p">),</span> <span class="s">&quot;%s/%s%s&quot;</span><span class="p">,</span> <span class="n">SYSFS_BLOCK</span><span class="p">,</span> <span class="n">name</span><span class="p">,</span><sup class="after"></sup>\n' + 
'</span><span class="line-210 line"><span class="lineno"> 210 </span>		 <span class="n">allow_virtual</span> <span class="o">?</span> <span class="s">&quot;&quot;</span> <span class="o">:</span> <span class="s">&quot;/device&quot;</span><span class="p">);</span><sup class="after"></sup>\n' + 
'</span><span class="line-211 line"><span class="lineno"> 211 </span><sup class="after"></sup>\n' + 
'</span><span class="line-212 line"><span class="lineno"> 212 </span>	<span class="k">return</span> <span class="o">!</span><span class="p">(</span><span class="n">access</span><span class="p">(</span><span class="n">syspath</span><span class="p">,</span> <span class="n">F_OK</span><span class="p">));</span><sup class="after"></sup>\n' + 
'</span><span class="line-213 line"><span class="lineno"> 213 </span><span class="p">}</span><sup class="after"></sup>\n' + 
'</span><span class="line-214 line"><span class="lineno"> 214 </span><sup class="after"></sup>\n' + 
'</span><span class="line-215 line"><span class="lineno"> 215 </span><span class="cm">/*</span><sup class="after"></sup>\n' + 
'</span><span class="line-216 line"><span class="lineno"> 216 </span><span class="cm"> ***************************************************************************</span><sup class="after"></sup>\n' + 
'</span><span class="line-217 line"><span class="lineno"> 217 </span><span class="cm"> * Get page shift in kB.</span><sup class="after"></sup>\n' + 
'</span><span class="line-218 line"><span class="lineno"> 218 </span><span class="cm"> ***************************************************************************</span><sup class="after"></sup>\n' + 
'</span><span class="line-219 line"><span class="lineno"> 219 </span><span class="cm"> */</span><sup class="after"></sup>\n' + 
'</span><span class="line-220 line"><span class="lineno"> 220 </span><span class="kt">void</span> <span class="nf">get_kb_shift</span><span class="p">(</span><span class="kt">void</span><span class="p">)</span><sup class="after"></sup>\n' + 
'</span><span class="line-221 line"><span class="lineno"> 221 </span><span class="p">{</span><sup class="after"></sup>\n' + 
'</span><span class="line-222 line"><span class="lineno"> 222 </span>	<span class="kt">int</span> <span class="n">shift</span> <span class="o">=</span> <span class="mi">0</span><span class="p">;</span><sup class="after"></sup>\n' + 
'</span><span class="line-223 line"><span class="lineno"> 223 </span>	<span class="kt">long</span> <span class="n">size</span><span class="p">;</span><sup class="after"></sup>\n' + 
'</span><span class="line-224 line"><span class="lineno"> 224 </span><sup class="after"></sup>\n' + 
'</span><span class="line-225 line"><span class="lineno"> 225 </span>	<span class="cm">/* One can also use getpagesize() to get the size of a page */</span><sup class="after"></sup>\n' + 
'</span><span class="line-226 line"><span class="lineno"> 226 </span>	<span class="k">if</span> <span class="p">((</span><span class="n">size</span> <span class="o">=</span> <span class="n">sysconf</span><span class="p">(</span><span class="n">_SC_PAGESIZE</span><span class="p">))</span> <span class="o">==</span> <span class="o">-</span><span class="mi">1</span><span class="p">)</span> <span class="p">{</span><sup class="after"></sup>\n' + 
'</span><span class="line-227 line"><span class="lineno"> 227 </span>		<span class="n">perror</span><span class="p">(</span><span class="s">&quot;sysconf&quot;</span><span class="p">);</span><sup class="after"></sup>\n' + 
'</span><span class="line-228 line"><span class="lineno"> 228 </span>	<span class="p">}</span><sup class="after"></sup>\n' + 
'</span><span class="line-229 line"><span class="lineno"> 229 </span><sup class="after"></sup>\n' + 
'</span><span class="line-230 line"><span class="lineno"> 230 </span>	<span class="n">size</span> <span class="o">&gt;&gt;=</span> <span class="mi">10</span><span class="p">;</span>	<span class="cm">/* Assume that a page has a minimum size of 1 kB */</span><sup class="after"></sup>\n' + 
'</span><span class="line-231 line"><span class="lineno"> 231 </span><sup class="after"></sup>\n' + 
'</span><span class="line-232 line"><span class="lineno"> 232 </span>	<span class="k">while</span> <span class="p">(</span><span class="n">size</span> <span class="o">&gt;</span> <span class="mi">1</span><span class="p">)</span> <span class="p">{</span><sup class="after"></sup>\n' + 
'</span><span class="line-233 line"><span class="lineno"> 233 </span>		<span class="n">shift</span><span class="o">++</span><span class="p">;</span><sup class="after"></sup>\n' + 
'</span><span class="line-234 line"><span class="lineno"> 234 </span>		<span class="n">size</span> <span class="o">&gt;&gt;=</span> <span class="mi">1</span><span class="p">;</span><sup class="after"></sup>\n' + 
'</span><span class="line-235 line"><span class="lineno"> 235 </span>	<span class="p">}</span><sup class="after"></sup>\n' + 
'</span><span class="line-236 line"><span class="lineno"> 236 </span><sup class="after"></sup>\n' + 
'</span><span class="line-237 line"><span class="lineno"> 237 </span>	<span class="n">kb_shift</span> <span class="o">=</span> <span class="p">(</span><span class="kt">unsigned</span> <span class="kt">int</span><span class="p">)</span> <span class="n">shift</span><span class="p">;</span><sup class="after"></sup>\n' + 
'</span><span class="line-238 line"><span class="lineno"> 238 </span><span class="p">}</span><sup class="after"></sup>\n' + 
'</span><span class="line-239 line"><span class="lineno"> 239 </span><sup class="after"></sup>\n' + 
'</span><span class="line-240 line"><span class="lineno"> 240 </span><span class="cm">/*</span><sup class="after"></sup>\n' + 
'</span><span class="line-241 line"><span class="lineno"> 241 </span><span class="cm"> ***************************************************************************</span><sup class="after"></sup>\n' + 
'</span><span class="line-242 line"><span class="lineno"> 242 </span><span class="cm"> * Get number of clock ticks per second.</span><sup class="after"></sup>\n' + 
'</span><span class="line-243 line"><span class="lineno"> 243 </span><span class="cm"> ***************************************************************************</span><sup class="after"></sup>\n' + 
'</span><span class="line-244 line"><span class="lineno"> 244 </span><span class="cm"> */</span><sup class="after"></sup>\n' + 
'</span><span class="line-245 line"><span class="lineno"> 245 </span><span class="kt">void</span> <span class="nf">get_HZ</span><span class="p">(</span><span class="kt">void</span><span class="p">)</span><sup class="after"></sup>\n' + 
'</span><span class="line-246 line"><span class="lineno"> 246 </span><span class="p">{</span><sup class="after"></sup>\n' + 
'</span><span class="line-247 line"><span class="lineno"> 247 </span>	<span class="kt">long</span> <span class="n">ticks</span><span class="p">;</span><sup class="after"></sup>\n' + 
'</span><span class="line-248 line"><span class="lineno"> 248 </span><sup class="after"></sup>\n' + 
'</span><span class="line-249 line"><span class="lineno"> 249 </span>	<span class="k">if</span> <span class="p">((</span><span class="n">ticks</span> <span class="o">=</span> <span class="n">sysconf</span><span class="p">(</span><span class="n">_SC_CLK_TCK</span><span class="p">))</span> <span class="o">==</span> <span class="o">-</span><span class="mi">1</span><span class="p">)</span> <span class="p">{</span><sup class="after"></sup>\n' + 
'</span><span class="line-250 line"><span class="lineno"> 250 </span>		<span class="n">perror</span><span class="p">(</span><span class="s">&quot;sysconf&quot;</span><span class="p">);</span><sup class="after"></sup>\n' + 
'</span><span class="line-251 line"><span class="lineno"> 251 </span>	<span class="p">}</span><sup class="after"></sup>\n' + 
'</span><span class="line-252 line"><span class="lineno"> 252 </span><sup class="after"></sup>\n' + 
'</span><span class="line-253 line"><span class="lineno"> 253 </span>	<span class="n">hz</span> <span class="o">=</span> <span class="p">(</span><span class="kt">unsigned</span> <span class="kt">long</span><span class="p">)</span> <span class="n">ticks</span><span class="p">;</span><sup class="after"></sup>\n' + 
'</span><span class="line-254 line"><span class="lineno"> 254 </span><span class="p">}</span><sup class="after"></sup>\n' + 
'</span><span class="line-255 line"><span class="lineno"> 255 </span><sup class="after"></sup>\n' + 
'</span><span class="line-256 line"><span class="lineno"> 256 </span><span class="cm">/*</span><sup class="after"></sup>\n' + 
'</span><span class="line-257 line"><span class="lineno"> 257 </span><span class="cm"> ***************************************************************************</span><sup class="after"></sup>\n' + 
'</span><span class="line-258 line"><span class="lineno"> 258 </span><span class="cm"> * Unhandled situation: Panic and exit. Should never happen.</span><sup class="after"></sup>\n' + 
'</span><span class="line-259 line"><span class="lineno"> 259 </span><span class="cm"> *</span><sup class="after"></sup>\n' + 
'</span><span class="line-260 line"><span class="lineno"> 260 </span><span class="cm"> * IN:</span><sup class="after"></sup>\n' + 
'</span><span class="line-261 line"><span class="lineno"> 261 </span><span class="cm"> * @function	Function name where situation occured.</span><sup class="after"></sup>\n' + 
'</span><span class="line-262 line"><span class="lineno"> 262 </span><span class="cm"> * @error_code	Error code.</span><sup class="after"></sup>\n' + 
'</span><span class="line-263 line"><span class="lineno"> 263 </span><span class="cm"> ***************************************************************************</span><sup class="after"></sup>\n' + 
'</span><span class="line-264 line"><span class="lineno"> 264 </span><span class="cm"> */</span><sup class="after"></sup>\n' + 
'</span><span class="line-265 line"><span class="lineno"> 265 </span><span class="kt">void</span> <span class="nf">sysstat_panic</span><span class="p">(</span><span class="k">const</span> <span class="kt">char</span> <span class="o">*</span><span class="n">function</span><span class="p">,</span> <span class="kt">int</span> <span class="n">error_code</span><span class="p">)</span><sup class="after"></sup>\n' + 
'</span><span class="line-266 line"><span class="lineno"> 266 </span><span class="p">{</span><sup class="after"></sup>\n' + 
'</span><span class="line-267 line"><span class="lineno"> 267 </span>	<span class="n">fprintf</span><span class="p">(</span><span class="n">stderr</span><span class="p">,</span> <span class="s">&quot;sysstat: %s[%d]: Internal error...</span><span class="se">\\n</span><span class="s">&quot;</span><span class="p">,</span><sup class="after"></sup>\n' + 
'</span><span class="line-268 line"><span class="lineno"> 268 </span>		<span class="n">function</span><span class="p">,</span> <span class="n">error_code</span><span class="p">);</span><sup class="after"></sup>\n' + 
'</span><span class="line-269 line"><span class="lineno"> 269 </span>	<span class="n">exit</span><span class="p">(</span><span class="mi">1</span><span class="p">);</span><sup class="after"></sup>\n' + 
'</span><span class="line-270 line"><span class="lineno"> 270 </span><span class="p">}</span><sup class="after"></sup>\n' + 
'</span><span class="line-271 line"><span class="lineno"> 271 </span><sup class="after"></sup>\n' + 
'</span><span class="line-272 line"><span class="lineno"> 272 </span><span class="cp">#ifndef SOURCE_SADC</span><sup class="after"></sup>\n' + 
'</span><span class="line-273 line"><span class="lineno"> 273 </span><span class="cm">/*</span><sup class="after"></sup>\n' + 
'</span><span class="line-274 line"><span class="lineno"> 274 </span><span class="cm"> ***************************************************************************</span><sup class="after"></sup>\n' + 
'</span><span class="line-275 line"><span class="lineno"> 275 </span><span class="cm"> * Count number of comma-separated values in arguments list. For example,</span><sup class="after"></sup>\n' + 
'</span><span class="line-276 line"><span class="lineno"> 276 </span><span class="cm"> * the number will be 3 for the list &quot;foobar -p 1 -p 2,3,4 2 5&quot;.</span><sup class="after"></sup>\n' + 
'</span><span class="line-277 line"><span class="lineno"> 277 </span><span class="cm"> *</span><sup class="after"></sup>\n' + 
'</span><span class="line-278 line"><span class="lineno"> 278 </span><span class="cm"> * IN:</span><sup class="after"></sup>\n' + 
'</span><span class="line-279 line"><span class="lineno"> 279 </span><span class="cm"> * @arg_c	Number of arguments in the list.</span><sup class="after"></sup>\n' + 
'</span><span class="line-280 line"><span class="lineno"> 280 </span><span class="cm"> * @arg_v	Arguments list.</span><sup class="after"></sup>\n' + 
'</span><span class="line-281 line"><span class="lineno"> 281 </span><span class="cm"> *</span><sup class="after"></sup>\n' + 
'</span><span class="line-282 line"><span class="lineno"> 282 </span><span class="cm"> * RETURNS:</span><sup class="after"></sup>\n' + 
'</span><span class="line-283 line"><span class="lineno"> 283 </span><span class="cm"> * Number of comma-separated values in the list.</span><sup class="after"></sup>\n' + 
'</span><span class="line-284 line"><span class="lineno"> 284 </span><span class="cm"> ***************************************************************************</span><sup class="after"></sup>\n' + 
'</span><span class="line-285 line"><span class="lineno"> 285 </span><span class="cm"> */</span><sup class="after"></sup>\n' + 
'</span><span class="line-286 line"><span class="lineno"> 286 </span><span class="kt">int</span> <span class="nf">count_csvalues</span><span class="p">(</span><span class="kt">int</span> <span class="n">arg_c</span><span class="p">,</span> <span class="kt">char</span> <span class="o">**</span><span class="n">arg_v</span><span class="p">)</span><sup class="after"></sup>\n' + 
'</span><span class="line-287 line"><span class="lineno"> 287 </span><span class="p">{</span><sup class="after"></sup>\n' + 
'</span><span class="line-288 line"><span class="lineno"> 288 </span>	<span class="kt">int</span> <span class="n">opt</span> <span class="o">=</span> <span class="mi">1</span><span class="p">;</span><sup class="after"></sup>\n' + 
'</span><span class="line-289 line"><span class="lineno"> 289 </span>	<span class="kt">int</span> <span class="n">nr</span> <span class="o">=</span> <span class="mi">0</span><span class="p">;</span><sup class="after"></sup>\n' + 
'</span><span class="line-290 line"><span class="lineno"> 290 </span>	<span class="kt">char</span> <span class="o">*</span><span class="n">t</span><span class="p">;</span><sup class="after"></sup>\n' + 
'</span><span class="line-291 line"><span class="lineno"> 291 </span><sup class="after"></sup>\n' + 
'</span><span class="line-292 line"><span class="lineno"> 292 </span>	<span class="k">while</span> <span class="p">(</span><span class="n">opt</span> <span class="o">&lt;</span> <span class="n">arg_c</span><span class="p">)</span> <span class="p">{</span><sup class="after"></sup>\n' + 
'</span><span class="line-293 line"><span class="lineno"> 293 </span>		<span class="k">if</span> <span class="p">(</span><span class="n">strchr</span><span class="p">(</span><span class="n">arg_v</span><span class="p">[</span><span class="n">opt</span><span class="p">],</span> <span class="sc">&#39;,&#39;</span><span class="p">))</span> <span class="p">{</span><sup class="after"></sup>\n' + 
'</span><span class="line-294 line"><span class="lineno"> 294 </span>			<span class="k">for</span> <span class="p">(</span><span class="n">t</span> <span class="o">=</span> <span class="n">arg_v</span><span class="p">[</span><span class="n">opt</span><span class="p">];</span> <span class="n">t</span><span class="p">;</span> <span class="n">t</span> <span class="o">=</span> <span class="n">strchr</span><span class="p">(</span><span class="n">t</span> <span class="o">+</span> <span class="mi">1</span><span class="p">,</span> <span class="sc">&#39;,&#39;</span><span class="p">))</span> <span class="p">{</span><sup class="after"></sup>\n' + 
'</span><span class="line-295 line"><span class="lineno"> 295 </span>				<span class="n">nr</span><span class="o">++</span><span class="p">;</span><sup class="after"></sup>\n' + 
'</span><span class="line-296 line"><span class="lineno"> 296 </span>			<span class="p">}</span><sup class="after"></sup>\n' + 
'</span><span class="line-297 line"><span class="lineno"> 297 </span>		<span class="p">}</span><sup class="after"></sup>\n' + 
'</span><span class="line-298 line"><span class="lineno"> 298 </span>		<span class="n">opt</span><span class="o">++</span><span class="p">;</span><sup class="after"></sup>\n' + 
'</span><span class="line-299 line"><span class="lineno"> 299 </span>	<span class="p">}</span><sup class="after"></sup>\n' + 
'</span><span class="line-300 line"><span class="lineno"> 300 </span><sup class="after"></sup>\n' + 
'</span><span class="line-301 line"><span class="lineno"> 301 </span>	<span class="k">return</span> <span class="n">nr</span><span class="p">;</span><sup class="after"></sup>\n' + 
'</span><span class="line-302 line"><span class="lineno"> 302 </span><span class="p">}</span><sup class="after"></sup>\n' + 
'</span><span class="line-303 line"><span class="lineno"> 303 </span><sup class="after"></sup>\n' + 
'</span><span class="line-304 line"><span class="lineno"> 304 </span><span class="cm">/*</span><sup class="after"></sup>\n' + 
'</span><span class="line-305 line"><span class="lineno"> 305 </span><span class="cm"> ***************************************************************************</span><sup class="after"></sup>\n' + 
'</span><span class="line-306 line"><span class="lineno"> 306 </span><span class="cm"> * Look for partitions of a given block device in /sys filesystem.</span><sup class="after"></sup>\n' + 
'</span><span class="line-307 line"><span class="lineno"> 307 </span><span class="cm"> *</span><sup class="after"></sup>\n' + 
'</span><span class="line-308 line"><span class="lineno"> 308 </span><span class="cm"> * IN:</span><sup class="after"></sup>\n' + 
'</span><span class="line-309 line"><span class="lineno"> 309 </span><span class="cm"> * @dev_name	Name of the block device.</span><sup class="after"></sup>\n' + 
'</span><span class="line-310 line"><span class="lineno"> 310 </span><span class="cm"> *</span><sup class="after"></sup>\n' + 
'</span><span class="line-311 line"><span class="lineno"> 311 </span><span class="cm"> * RETURNS:</span><sup class="after"></sup>\n' + 
'</span><span class="line-312 line"><span class="lineno"> 312 </span><span class="cm"> * Number of partitions for the given block device.</span><sup class="after"></sup>\n' + 
'</span><span class="line-313 line"><span class="lineno"> 313 </span><span class="cm"> ***************************************************************************</span><sup class="after"></sup>\n' + 
'</span><span class="line-314 line"><span class="lineno"> 314 </span><span class="cm"> */</span><sup class="after"></sup>\n' + 
'</span><span class="line-315 line"><span class="lineno"> 315 </span><span class="kt">int</span> <span class="nf">get_dev_part_nr</span><span class="p">(</span><span class="kt">char</span> <span class="o">*</span><span class="n">dev_name</span><span class="p">)</span><sup class="after"></sup>\n' + 
'</span><span class="line-316 line"><span class="lineno"> 316 </span><span class="p">{</span><sup class="after"></sup>\n' + 
'</span><span class="line-317 line"><span class="lineno"> 317 </span>	<span class="kt">DIR</span> <span class="o">*</span><span class="n">dir</span><span class="p">;</span><sup class="after"></sup>\n' + 
'</span><span class="line-318 line"><span class="lineno"> 318 </span>	<span class="k">struct</span> <span class="n">dirent</span> <span class="o">*</span><span class="n">drd</span><span class="p">;</span><sup class="after"></sup>\n' + 
'</span><span class="line-319 line"><span class="lineno"> 319 </span>	<span class="kt">char</span> <span class="n">dfile</span><span class="p">[</span><span class="n">MAX_PF_NAME</span><span class="p">],</span> <span class="n">line</span><span class="p">[</span><span class="n">MAX_PF_NAME</span><span class="p">];</span><sup class="after"></sup>\n' + 
'</span><span class="line-320 line"><span class="lineno"> 320 </span>	<span class="kt">int</span> <span class="n">part</span> <span class="o">=</span> <span class="mi">0</span><span class="p">,</span> <span class="n">err</span><span class="p">;</span><sup class="after"></sup>\n' + 
'</span><span class="line-321 line"><span class="lineno"> 321 </span><sup class="after"></sup>\n' + 
'</span><span class="line-322 line"><span class="lineno"> 322 </span>	<span class="n">snprintf</span><span class="p">(</span><span class="n">dfile</span><span class="p">,</span> <span class="n">MAX_PF_NAME</span><span class="p">,</span> <span class="s">&quot;%s/%s&quot;</span><span class="p">,</span> <span class="n">SYSFS_BLOCK</span><span class="p">,</span> <span class="n">dev_name</span><span class="p">);</span><sup class="after"></sup>\n' + 
'</span><span class="line-323 line"><span class="lineno"> 323 </span>	<span class="n">dfile</span><span class="p">[</span><span class="n">MAX_PF_NAME</span> <span class="o">-</span> <span class="mi">1</span><span class="p">]</span> <span class="o">=</span> <span class="sc">&#39;\\0&#39;</span><span class="p">;</span><sup class="after"></sup>\n' + 
'</span><span class="line-324 line"><span class="lineno"> 324 </span><sup class="after"></sup>\n' + 
'</span><span class="line-325 line"><span class="lineno"> 325 </span>	<span class="cm">/* Open current device directory in /sys/block */</span><sup class="after"></sup>\n' + 
'</span><span class="line-326 line"><span class="lineno"> 326 </span>	<span class="k">if</span> <span class="p">((</span><span class="n">dir</span> <span class="o">=</span> <span class="n">opendir</span><span class="p">(</span><span class="n">dfile</span><span class="p">))</span> <span class="o">==</span> <span class="nb">NULL</span><span class="p">)</span><sup class="after"></sup>\n' + 
'</span><span class="line-327 line"><span class="lineno"> 327 </span>		<span class="k">return</span> <span class="mi">0</span><span class="p">;</span><sup class="after"></sup>\n' + 
'</span><span class="line-328 line"><span class="lineno"> 328 </span><sup class="after"></sup>\n' + 
'</span><span class="line-329 line"><span class="lineno"> 329 </span>	<span class="cm">/* Get current file entry */</span><sup class="after"></sup>\n' + 
'</span><span class="line-330 line"><span class="lineno"> 330 </span>	<span class="k">while</span> <span class="p">((</span><span class="n">drd</span> <span class="o">=</span> <span class="n">readdir</span><span class="p">(</span><span class="n">dir</span><span class="p">))</span> <span class="o">!=</span> <span class="nb">NULL</span><span class="p">)</span> <span class="p">{</span><sup class="after"></sup>\n' + 
'</span><span class="line-331 line"><span class="lineno"> 331 </span>		<span class="k">if</span> <span class="p">(</span><span class="o">!</span><span class="n">strcmp</span><span class="p">(</span><span class="n">drd</span><span class="o">-&gt;</span><span class="n">d_name</span><span class="p">,</span> <span class="s">&quot;.&quot;</span><span class="p">)</span> <span class="o">||</span> <span class="o">!</span><span class="n">strcmp</span><span class="p">(</span><span class="n">drd</span><span class="o">-&gt;</span><span class="n">d_name</span><span class="p">,</span> <span class="s">&quot;..&quot;</span><span class="p">))</span><sup class="after"></sup>\n' + 
'</span><span class="line-332 line"><span class="lineno"> 332 </span>			<span class="k">continue</span><span class="p">;</span><sup class="after"></sup>\n' + 
'</span><span class="line-333 line"><span class="lineno"> 333 </span>		<span class="n">err</span> <span class="o">=</span> <span class="n">snprintf</span><span class="p">(</span><span class="n">line</span><span class="p">,</span> <span class="n">MAX_PF_NAME</span><span class="p">,</span> <span class="s">&quot;%s/%s/%s&quot;</span><span class="p">,</span> <span class="n">dfile</span><span class="p">,</span> <span class="n">drd</span><span class="o">-&gt;</span><span class="n">d_name</span><span class="p">,</span> <span class="n">S_STAT</span><span class="p">);</span><sup class="after"></sup>\n' + 
'</span><span class="line-334 line"><span class="lineno"> 334 </span>		<span class="k">if</span> <span class="p">((</span><span class="n">err</span> <span class="o">&lt;</span> <span class="mi">0</span><span class="p">)</span> <span class="o">||</span> <span class="p">(</span><span class="n">err</span> <span class="o">&gt;=</span> <span class="n">MAX_PF_NAME</span><span class="p">))</span><sup class="after"></sup>\n' + 
'</span><span class="line-335 line"><span class="lineno"> 335 </span>			<span class="k">continue</span><span class="p">;</span><sup class="after"></sup>\n' + 
'</span><span class="line-336 line"><span class="lineno"> 336 </span><sup class="after"></sup>\n' + 
'</span><span class="line-337 line"><span class="lineno"> 337 </span>		<span class="cm">/* Try to guess if current entry is a directory containing a stat file */</span><sup class="after"></sup>\n' + 
'</span><span class="line-338 line"><span class="lineno"> 338 </span>		<span class="k">if</span> <span class="p">(</span><span class="o">!</span><span class="n">access</span><span class="p">(</span><span class="n">line</span><span class="p">,</span> <span class="n">R_OK</span><span class="p">))</span> <span class="p">{</span><sup class="after"></sup>\n' + 
'</span><span class="line-339 line"><span class="lineno"> 339 </span>			<span class="cm">/* Yep... */</span><sup class="after"></sup>\n' + 
'</span><span class="line-340 line"><span class="lineno"> 340 </span>			<span class="n">part</span><span class="o">++</span><span class="p">;</span><sup class="after"></sup>\n' + 
'</span><span class="line-341 line"><span class="lineno"> 341 </span>		<span class="p">}</span><sup class="after"></sup>\n' + 
'</span><span class="line-342 line"><span class="lineno"> 342 </span>	<span class="p">}</span><sup class="after"></sup>\n' + 
'</span><span class="line-343 line"><span class="lineno"> 343 </span><sup class="after"></sup>\n' + 
'</span><span class="line-344 line"><span class="lineno"> 344 </span>	<span class="cm">/* Close directory */</span><sup class="after"></sup>\n' + 
'</span><span class="line-345 line"><span class="lineno"> 345 </span>	<span class="n">closedir</span><span class="p">(</span><span class="n">dir</span><span class="p">);</span><sup class="after"></sup>\n' + 
'</span><span class="line-346 line"><span class="lineno"> 346 </span><sup class="after"></sup>\n' + 
'</span><span class="line-347 line"><span class="lineno"> 347 </span>	<span class="k">return</span> <span class="n">part</span><span class="p">;</span><sup class="after"></sup>\n' + 
'</span><span class="line-348 line"><span class="lineno"> 348 </span><span class="p">}</span><sup class="after"></sup>\n' + 
'</span><span class="line-349 line"><span class="lineno"> 349 </span><sup class="after"></sup>\n' + 
'</span><span class="line-350 line"><span class="lineno"> 350 </span><span class="cm">/*</span><sup class="after"></sup>\n' + 
'</span><span class="line-351 line"><span class="lineno"> 351 </span><span class="cm"> ***************************************************************************</span><sup class="after"></sup>\n' + 
'</span><span class="line-352 line"><span class="lineno"> 352 </span><span class="cm"> * Look for block devices present in /sys/ filesystem:</span><sup class="after"></sup>\n' + 
'</span><span class="line-353 line"><span class="lineno"> 353 </span><span class="cm"> * Check first that sysfs is mounted (done by trying to open /sys/block</span><sup class="after"></sup>\n' + 
'</span><span class="line-354 line"><span class="lineno"> 354 </span><span class="cm"> * directory), then find number of devices registered.</span><sup class="after"></sup>\n' + 
'</span><span class="line-355 line"><span class="lineno"> 355 </span><span class="cm"> *</span><sup class="after"></sup>\n' + 
'</span><span class="line-356 line"><span class="lineno"> 356 </span><span class="cm"> * IN:</span><sup class="after"></sup>\n' + 
'</span><span class="line-357 line"><span class="lineno"> 357 </span><span class="cm"> * @display_partitions	Set to TRUE if partitions must also be counted.</span><sup class="after"></sup>\n' + 
'</span><span class="line-358 line"><span class="lineno"> 358 </span><span class="cm"> *</span><sup class="after"></sup>\n' + 
'</span><span class="line-359 line"><span class="lineno"> 359 </span><span class="cm"> * RETURNS:</span><sup class="after"></sup>\n' + 
'</span><span class="line-360 line"><span class="lineno"> 360 </span><span class="cm"> * Total number of block devices (and partitions if @display_partitions was</span><sup class="after"></sup>\n' + 
'</span><span class="line-361 line"><span class="lineno"> 361 </span><span class="cm"> * set).</span><sup class="after"></sup>\n' + 
'</span><span class="line-362 line"><span class="lineno"> 362 </span><span class="cm"> ***************************************************************************</span><sup class="after"></sup>\n' + 
'</span><span class="line-363 line"><span class="lineno"> 363 </span><span class="cm"> */</span><sup class="after"></sup>\n' + 
'</span><span class="line-364 line"><span class="lineno"> 364 </span><span class="kt">int</span> <span class="nf">get_sysfs_dev_nr</span><span class="p">(</span><span class="kt">int</span> <span class="n">display_partitions</span><span class="p">)</span><sup class="after"></sup>\n' + 
'</span><span class="line-365 line"><span class="lineno"> 365 </span><span class="p">{</span><sup class="after"></sup>\n' + 
'</span><span class="line-366 line"><span class="lineno"> 366 </span>	<span class="kt">DIR</span> <span class="o">*</span><span class="n">dir</span><span class="p">;</span><sup class="after"></sup>\n' + 
'</span><span class="line-367 line"><span class="lineno"> 367 </span>	<span class="k">struct</span> <span class="n">dirent</span> <span class="o">*</span><span class="n">drd</span><span class="p">;</span><sup class="after"></sup>\n' + 
'</span><span class="line-368 line"><span class="lineno"> 368 </span>	<span class="kt">char</span> <span class="n">line</span><span class="p">[</span><span class="n">MAX_PF_NAME</span><span class="p">];</span><sup class="after"></sup>\n' + 
'</span><span class="line-369 line"><span class="lineno"> 369 </span>	<span class="kt">int</span> <span class="n">dev</span> <span class="o">=</span> <span class="mi">0</span><span class="p">;</span><sup class="after"></sup>\n' + 
'</span><span class="line-370 line"><span class="lineno"> 370 </span><sup class="after"></sup>\n' + 
'</span><span class="line-371 line"><span class="lineno"> 371 </span>	<span class="cm">/* Open /sys/block directory */</span><sup class="after"></sup>\n' + 
'</span><span class="line-372 line"><span class="lineno"> 372 </span>	<span class="k">if</span> <span class="p">((</span><span class="n">dir</span> <span class="o">=</span> <span class="n">opendir</span><span class="p">(</span><span class="n">SYSFS_BLOCK</span><span class="p">))</span> <span class="o">==</span> <span class="nb">NULL</span><span class="p">)</span><sup class="after"></sup>\n' + 
'</span><span class="line-373 line"><span class="lineno"> 373 </span>		<span class="cm">/* sysfs not mounted, or perhaps this is an old kernel */</span><sup class="after"></sup>\n' + 
'</span><span class="line-374 line"><span class="lineno"> 374 </span>		<span class="k">return</span> <span class="mi">0</span><span class="p">;</span><sup class="after"></sup>\n' + 
'</span><span class="line-375 line"><span class="lineno"> 375 </span><sup class="after"></sup>\n' + 
'</span><span class="line-376 line"><span class="lineno"> 376 </span>	<span class="cm">/* Get current file entry in /sys/block directory */</span><sup class="after"></sup>\n' + 
'</span><span class="line-377 line"><span class="lineno"> 377 </span>	<span class="k">while</span> <span class="p">((</span><span class="n">drd</span> <span class="o">=</span> <span class="n">readdir</span><span class="p">(</span><span class="n">dir</span><span class="p">))</span> <span class="o">!=</span> <span class="nb">NULL</span><span class="p">)</span> <span class="p">{</span><sup class="after"></sup>\n' + 
'</span><span class="line-378 line"><span class="lineno"> 378 </span>		<span class="k">if</span> <span class="p">(</span><span class="o">!</span><span class="n">strcmp</span><span class="p">(</span><span class="n">drd</span><span class="o">-&gt;</span><span class="n">d_name</span><span class="p">,</span> <span class="s">&quot;.&quot;</span><span class="p">)</span> <span class="o">||</span> <span class="o">!</span><span class="n">strcmp</span><span class="p">(</span><span class="n">drd</span><span class="o">-&gt;</span><span class="n">d_name</span><span class="p">,</span> <span class="s">&quot;..&quot;</span><span class="p">))</span><sup class="after"></sup>\n' + 
'</span><span class="line-379 line"><span class="lineno"> 379 </span>			<span class="k">continue</span><span class="p">;</span><sup class="after"></sup>\n' + 
'</span><span class="line-380 line"><span class="lineno"> 380 </span>		<span class="n">snprintf</span><span class="p">(</span><span class="n">line</span><span class="p">,</span> <span class="n">MAX_PF_NAME</span><span class="p">,</span> <span class="s">&quot;%s/%s/%s&quot;</span><span class="p">,</span> <span class="n">SYSFS_BLOCK</span><span class="p">,</span> <span class="n">drd</span><span class="o">-&gt;</span><span class="n">d_name</span><span class="p">,</span> <span class="n">S_STAT</span><span class="p">);</span><sup class="after"></sup>\n' + 
'</span><span class="line-381 line"><span class="lineno"> 381 </span>		<span class="n">line</span><span class="p">[</span><span class="n">MAX_PF_NAME</span> <span class="o">-</span> <span class="mi">1</span><span class="p">]</span> <span class="o">=</span> <span class="sc">&#39;\\0&#39;</span><span class="p">;</span><sup class="after"></sup>\n' + 
'</span><span class="line-382 line"><span class="lineno"> 382 </span><sup class="after"></sup>\n' + 
'</span><span class="line-383 line"><span class="lineno"> 383 </span>		<span class="cm">/* Try to guess if current entry is a directory containing a stat file */</span><sup class="after"></sup>\n' + 
'</span><span class="line-384 line"><span class="lineno"> 384 </span>		<span class="k">if</span> <span class="p">(</span><span class="o">!</span><span class="n">access</span><span class="p">(</span><span class="n">line</span><span class="p">,</span> <span class="n">R_OK</span><span class="p">))</span> <span class="p">{</span><sup class="after"></sup>\n' + 
'</span><span class="line-385 line"><span class="lineno"> 385 </span>			<span class="cm">/* Yep... */</span><sup class="after"></sup>\n' + 
'</span><span class="line-386 line"><span class="lineno"> 386 </span>			<span class="n">dev</span><span class="o">++</span><span class="p">;</span><sup class="after"></sup>\n' + 
'</span><span class="line-387 line"><span class="lineno"> 387 </span><sup class="after"></sup>\n' + 
'</span><span class="line-388 line"><span class="lineno"> 388 </span>			<span class="k">if</span> <span class="p">(</span><span class="n">display_partitions</span><span class="p">)</span> <span class="p">{</span><sup class="after"></sup>\n' + 
'</span><span class="line-389 line"><span class="lineno"> 389 </span>				<span class="cm">/* We also want the number of partitions for this device */</span><sup class="after"></sup>\n' + 
'</span><span class="line-390 line"><span class="lineno"> 390 </span>				<span class="n">dev</span> <span class="o">+=</span> <span class="n">get_dev_part_nr</span><span class="p">(</span><span class="n">drd</span><span class="o">-&gt;</span><span class="n">d_name</span><span class="p">);</span><sup class="after"></sup>\n' + 
'</span><span class="line-391 line"><span class="lineno"> 391 </span>			<span class="p">}</span><sup class="after"></sup>\n' + 
'</span><span class="line-392 line"><span class="lineno"> 392 </span>		<span class="p">}</span><sup class="after"></sup>\n' + 
'</span><span class="line-393 line"><span class="lineno"> 393 </span>	<span class="p">}</span><sup class="after"></sup>\n' + 
'</span><span class="line-394 line"><span class="lineno"> 394 </span><sup class="after"></sup>\n' + 
'</span><span class="line-395 line"><span class="lineno"> 395 </span>	<span class="cm">/* Close /sys/block directory */</span><sup class="after"></sup>\n' + 
'</span><span class="line-396 line"><span class="lineno"> 396 </span>	<span class="n">closedir</span><span class="p">(</span><span class="n">dir</span><span class="p">);</span><sup class="after"></sup>\n' + 
'</span><span class="line-397 line"><span class="lineno"> 397 </span><sup class="after"></sup>\n' + 
'</span><span class="line-398 line"><span class="lineno"> 398 </span>	<span class="k">return</span> <span class="n">dev</span><span class="p">;</span><sup class="after"></sup>\n' + 
'</span><span class="line-399 line"><span class="lineno"> 399 </span><span class="p">}</span><sup class="after"></sup>\n' + 
'</span><span class="line-400 line"><span class="lineno"> 400 </span><sup class="after"></sup>\n' + 
'</span><span class="line-401 line"><span class="lineno"> 401 </span><span class="cm">/*</span><sup class="after"></sup>\n' + 
'</span><span class="line-402 line"><span class="lineno"> 402 </span><span class="cm"> ***************************************************************************</span><sup class="after"></sup>\n' + 
'</span><span class="line-403 line"><span class="lineno"> 403 </span><span class="cm"> * Read /proc/devices file and get device-mapper major number.</span><sup class="after"></sup>\n' + 
'</span><span class="line-404 line"><span class="lineno"> 404 </span><span class="cm"> * If device-mapper entry is not found in file, assume it&#39;s not active.</span><sup class="after"></sup>\n' + 
'</span><span class="line-405 line"><span class="lineno"> 405 </span><span class="cm"> *</span><sup class="after"></sup>\n' + 
'</span><span class="line-406 line"><span class="lineno"> 406 </span><span class="cm"> * RETURNS:</span><sup class="after"></sup>\n' + 
'</span><span class="line-407 line"><span class="lineno"> 407 </span><span class="cm"> * Device-mapper major number.</span><sup class="after"></sup>\n' + 
'</span><span class="line-408 line"><span class="lineno"> 408 </span><span class="cm"> ***************************************************************************</span><sup class="after"></sup>\n' + 
'</span><span class="line-409 line"><span class="lineno"> 409 </span><span class="cm"> */</span><sup class="after"></sup>\n' + 
'</span><span class="line-410 line"><span class="lineno"> 410 </span><span class="kt">unsigned</span> <span class="kt">int</span> <span class="nf">get_devmap_major</span><span class="p">(</span><span class="kt">void</span><span class="p">)</span><sup class="after"></sup>\n' + 
'</span><span class="line-411 line"><span class="lineno"> 411 </span><span class="p">{</span><sup class="after"></sup>\n' + 
'</span><span class="line-412 line"><span class="lineno"> 412 </span>	<span class="kt">FILE</span> <span class="o">*</span><span class="n">fp</span><span class="p">;</span><sup class="after"></sup>\n' + 
'</span><span class="line-413 line"><span class="lineno"> 413 </span>	<span class="kt">char</span> <span class="n">line</span><span class="p">[</span><span class="mi">128</span><span class="p">];</span><sup class="after"></sup>\n' + 
'</span><span class="line-414 line"><span class="lineno"> 414 </span>	<span class="cm">/*</span><sup class="after"></sup>\n' + 
'</span><span class="line-415 line"><span class="lineno"> 415 </span><span class="cm">	 * Linux uses 12 bits for the major number,</span><sup class="after"></sup>\n' + 
'</span><span class="line-416 line"><span class="lineno"> 416 </span><span class="cm">	 * so this shouldn&#39;t match any real device.</span><sup class="after"></sup>\n' + 
'</span><span class="line-417 line"><span class="lineno"> 417 </span><span class="cm">	 */</span><sup class="after"></sup>\n' + 
'</span><span class="line-418 line"><span class="lineno"> 418 </span>	<span class="kt">unsigned</span> <span class="kt">int</span> <span class="n">dm_major</span> <span class="o">=</span> <span class="o">~</span><span class="mi">0U</span><span class="p">;</span><sup class="after"></sup>\n' + 
'</span><span class="line-419 line"><span class="lineno"> 419 </span><sup class="after"></sup>\n' + 
'</span><span class="line-420 line"><span class="lineno"> 420 </span>	<span class="k">if</span> <span class="p">((</span><span class="n">fp</span> <span class="o">=</span> <span class="n">fopen</span><span class="p">(</span><span class="n">DEVICES</span><span class="p">,</span> <span class="s">&quot;r&quot;</span><span class="p">))</span> <span class="o">==</span> <span class="nb">NULL</span><span class="p">)</span><sup class="after"></sup>\n' + 
'</span><span class="line-421 line"><span class="lineno"> 421 </span>		<span class="k">return</span> <span class="n">dm_major</span><span class="p">;</span><sup class="after"></sup>\n' + 
'</span><span class="line-422 line"><span class="lineno"> 422 </span><sup class="after"></sup>\n' + 
'</span><span class="line-423 line"><span class="lineno"> 423 </span>	<span class="k">while</span> <span class="p">(</span><span class="n">fgets</span><span class="p">(</span><span class="n">line</span><span class="p">,</span> <span class="k">sizeof</span><span class="p">(</span><span class="n">line</span><span class="p">),</span> <span class="n">fp</span><span class="p">)</span> <span class="o">!=</span> <span class="nb">NULL</span><span class="p">)</span> <span class="p">{</span><sup class="after"></sup>\n' + 
'</span><span class="line-424 line"><span class="lineno"> 424 </span><sup class="after"></sup>\n' + 
'</span><span class="line-425 line"><span class="lineno"> 425 </span>		<span class="k">if</span> <span class="p">(</span><span class="n">strstr</span><span class="p">(</span><span class="n">line</span><span class="p">,</span> <span class="s">&quot;device-mapper&quot;</span><span class="p">))</span> <span class="p">{</span><sup class="after"></sup>\n' + 
'</span><span class="line-426 line"><span class="lineno"> 426 </span>			<span class="cm">/* Read device-mapper major number */</span><sup class="after"></sup>\n' + 
'</span><span class="line-427 line"><span class="lineno"> 427 </span>			<span class="n">sscanf</span><span class="p">(</span><span class="n">line</span><span class="p">,</span> <span class="s">&quot;%u&quot;</span><span class="p">,</span> <span class="o">&amp;</span><span class="n">dm_major</span><span class="p">);</span><sup class="after"></sup>\n' + 
'</span><span class="line-428 line"><span class="lineno"> 428 </span>		<span class="p">}</span><sup class="after"></sup>\n' + 
'</span><span class="line-429 line"><span class="lineno"> 429 </span>	<span class="p">}</span><sup class="after"></sup>\n' + 
'</span><span class="line-430 line"><span class="lineno"> 430 </span><sup class="after"></sup>\n' + 
'</span><span class="line-431 line"><span class="lineno"> 431 </span>	<span class="n">fclose</span><span class="p">(</span><span class="n">fp</span><span class="p">);</span><sup class="after"></sup>\n' + 
'</span><span class="line-432 line"><span class="lineno"> 432 </span><sup class="after"></sup>\n' + 
'</span><span class="line-433 line"><span class="lineno"> 433 </span>	<span class="k">return</span> <span class="n">dm_major</span><span class="p">;</span><sup class="after"></sup>\n' + 
'</span><span class="line-434 line"><span class="lineno"> 434 </span><span class="p">}</span><sup class="after"></sup>\n' + 
'</span><span class="line-435 line"><span class="lineno"> 435 </span><sup class="after"></sup>\n' + 
'</span><span class="line-436 line"><span class="lineno"> 436 </span><span class="cm">/*</span><sup class="after"></sup>\n' + 
'</span><span class="line-437 line"><span class="lineno"> 437 </span><span class="cm"> ***************************************************************************</span><sup class="after"></sup>\n' + 
'</span><span class="line-438 line"><span class="lineno"> 438 </span><span class="cm"> * Returns whether S_TIME_FORMAT is set to ISO.</span><sup class="after"></sup>\n' + 
'</span><span class="line-439 line"><span class="lineno"> 439 </span><span class="cm"> *</span><sup class="after"></sup>\n' + 
'</span><span class="line-440 line"><span class="lineno"> 440 </span><span class="cm"> * RETURNS:</span><sup class="after"></sup>\n' + 
'</span><span class="line-441 line"><span class="lineno"> 441 </span><span class="cm"> * TRUE if S_TIME_FORMAT is set to ISO, or FALSE otherwise.</span><sup class="after"></sup>\n' + 
'</span><span class="line-442 line"><span class="lineno"> 442 </span><span class="cm"> ***************************************************************************</span><sup class="after"></sup>\n' + 
'</span><span class="line-443 line"><span class="lineno"> 443 </span><span class="cm"> */</span><sup class="after"></sup>\n' + 
'</span><span class="line-444 line"><span class="lineno"> 444 </span><span class="kt">int</span> <span class="nf">is_iso_time_fmt</span><span class="p">(</span><span class="kt">void</span><span class="p">)</span><sup class="after"></sup>\n' + 
'</span><span class="line-445 line"><span class="lineno"> 445 </span><span class="p">{</span><sup class="after"></sup>\n' + 
'</span><span class="line-446 line"><span class="lineno"> 446 </span>	<span class="k">static</span> <span class="kt">int</span> <span class="n">is_iso</span> <span class="o">=</span> <span class="o">-</span><span class="mi">1</span><span class="p">;</span><sup class="after"></sup>\n' + 
'</span><span class="line-447 line"><span class="lineno"> 447 </span>	<span class="kt">char</span> <span class="o">*</span><span class="n">e</span><span class="p">;</span><sup class="after"></sup>\n' + 
'</span><span class="line-448 line"><span class="lineno"> 448 </span><sup class="after"></sup>\n' + 
'</span><span class="line-449 line"><span class="lineno"> 449 </span>	<span class="k">if</span> <span class="p">(</span><span class="n">is_iso</span> <span class="o">&lt;</span> <span class="mi">0</span><span class="p">)</span> <span class="p">{</span><sup class="after"></sup>\n' + 
'</span><span class="line-450 line"><span class="lineno"> 450 </span>		<span class="n">is_iso</span> <span class="o">=</span> <span class="p">(((</span><span class="n">e</span> <span class="o">=</span> <span class="n">getenv</span><span class="p">(</span><span class="n">ENV_TIME_FMT</span><span class="p">))</span> <span class="o">!=</span> <span class="nb">NULL</span><span class="p">)</span> <span class="o">&amp;&amp;</span> <span class="o">!</span><span class="n">strcmp</span><span class="p">(</span><span class="n">e</span><span class="p">,</span> <span class="n">K_ISO</span><span class="p">));</span><sup class="after"></sup>\n' + 
'</span><span class="line-451 line"><span class="lineno"> 451 </span>	<span class="p">}</span><sup class="after"></sup>\n' + 
'</span><span class="line-452 line"><span class="lineno"> 452 </span>	<span class="k">return</span> <span class="n">is_iso</span><span class="p">;</span><sup class="after"></sup>\n' + 
'</span><span class="line-453 line"><span class="lineno"> 453 </span><span class="p">}</span><sup class="after"></sup>\n' + 
'</span><span class="line-454 line"><span class="lineno"> 454 </span><sup class="after"></sup>\n' + 
'</span><span class="line-455 line"><span class="lineno"> 455 </span><span class="cm">/*</span><sup class="after"></sup>\n' + 
'</span><span class="line-456 line"><span class="lineno"> 456 </span><span class="cm"> ***************************************************************************</span><sup class="after"></sup>\n' + 
'</span><span class="line-457 line"><span class="lineno"> 457 </span><span class="cm"> * Print tabulations</span><sup class="after"></sup>\n' + 
'</span><span class="line-458 line"><span class="lineno"> 458 </span><span class="cm"> *</span><sup class="after"></sup>\n' + 
'</span><span class="line-459 line"><span class="lineno"> 459 </span><span class="cm"> * IN:</span><sup class="after"></sup>\n' + 
'</span><span class="line-460 line"><span class="lineno"> 460 </span><span class="cm"> * @nr_tab	Number of tabs to print.</span><sup class="after"></sup>\n' + 
'</span><span class="line-461 line"><span class="lineno"> 461 </span><span class="cm"> ***************************************************************************</span><sup class="after"></sup>\n' + 
'</span><span class="line-462 line"><span class="lineno"> 462 </span><span class="cm"> */</span><sup class="after"></sup>\n' + 
'</span><span class="line-463 line"><span class="lineno"> 463 </span><span class="kt">void</span> <span class="nf">prtab</span><span class="p">(</span><span class="kt">int</span> <span class="n">nr_tab</span><span class="p">)</span><sup class="after"></sup>\n' + 
'</span><span class="line-464 line"><span class="lineno"> 464 </span><span class="p">{</span><sup class="after"></sup>\n' + 
'</span><span class="line-465 line"><span class="lineno"> 465 </span>	<span class="kt">int</span> <span class="n">i</span><span class="p">;</span><sup class="after"></sup>\n' + 
'</span><span class="line-466 line"><span class="lineno"> 466 </span><sup class="after"></sup>\n' + 
'</span><span class="line-467 line"><span class="lineno"> 467 </span>	<span class="k">for</span> <span class="p">(</span><span class="n">i</span> <span class="o">=</span> <span class="mi">0</span><span class="p">;</span> <span class="n">i</span> <span class="o">&lt;</span> <span class="n">nr_tab</span><span class="p">;</span> <span class="n">i</span><span class="o">++</span><span class="p">)</span> <span class="p">{</span><sup class="after"></sup>\n' + 
'</span><span class="line-468 line"><span class="lineno"> 468 </span>		<span class="n">printf</span><span class="p">(</span><span class="s">&quot;</span><span class="se">\\t</span><span class="s">&quot;</span><span class="p">);</span><sup class="after"></sup>\n' + 
'</span><span class="line-469 line"><span class="lineno"> 469 </span>	<span class="p">}</span><sup class="after"></sup>\n' + 
'</span><span class="line-470 line"><span class="lineno"> 470 </span><span class="p">}</span><sup class="after"></sup>\n' + 
'</span><span class="line-471 line"><span class="lineno"> 471 </span><sup class="after"></sup>\n' + 
'</span><span class="line-472 line"><span class="lineno"> 472 </span><span class="cm">/*</span><sup class="after"></sup>\n' + 
'</span><span class="line-473 line"><span class="lineno"> 473 </span><span class="cm"> ***************************************************************************</span><sup class="after"></sup>\n' + 
'</span><span class="line-474 line"><span class="lineno"> 474 </span><span class="cm"> * printf() function modified for XML-like output. Don&#39;t print a CR at the</span><sup class="after"></sup>\n' + 
'</span><span class="line-475 line"><span class="lineno"> 475 </span><span class="cm"> * end of the line.</span><sup class="after"></sup>\n' + 
'</span><span class="line-476 line"><span class="lineno"> 476 </span><span class="cm"> *</span><sup class="after"></sup>\n' + 
'</span><span class="line-477 line"><span class="lineno"> 477 </span><span class="cm"> * IN:</span><sup class="after"></sup>\n' + 
'</span><span class="line-478 line"><span class="lineno"> 478 </span><span class="cm"> * @nr_tab	Number of tabs to print.</span><sup class="after"></sup>\n' + 
'</span><span class="line-479 line"><span class="lineno"> 479 </span><span class="cm"> * @fmtf	printf() format.</span><sup class="after"></sup>\n' + 
'</span><span class="line-480 line"><span class="lineno"> 480 </span><span class="cm"> ***************************************************************************</span><sup class="after"></sup>\n' + 
'</span><span class="line-481 line"><span class="lineno"> 481 </span><span class="cm"> */</span><sup class="after"></sup>\n' + 
'</span><span class="line-482 line"><span class="lineno"> 482 </span><span class="kt">void</span> <span class="nf">xprintf0</span><span class="p">(</span><span class="kt">int</span> <span class="n">nr_tab</span><span class="p">,</span> <span class="k">const</span> <span class="kt">char</span> <span class="o">*</span><span class="n">fmtf</span><span class="p">,</span> <span class="p">...)</span><sup class="after"></sup>\n' + 
'</span><span class="line-483 line"><span class="lineno"> 483 </span><span class="p">{</span><sup class="after"></sup>\n' + 
'</span><span class="line-484 line"><span class="lineno"> 484 </span>	<span class="k">static</span> <span class="kt">char</span> <span class="n">buf</span><span class="p">[</span><span class="mi">1024</span><span class="p">];</span><sup class="after"></sup>\n' + 
'</span><span class="line-485 line"><span class="lineno"> 485 </span>	<span class="kt">va_list</span> <span class="n">args</span><span class="p">;</span><sup class="after"></sup>\n' + 
'</span><span class="line-486 line"><span class="lineno"> 486 </span><sup class="after"></sup>\n' + 
'</span><span class="line-487 line"><span class="lineno"> 487 </span>	<span class="n">va_start</span><span class="p">(</span><span class="n">args</span><span class="p">,</span> <span class="n">fmtf</span><span class="p">);</span><sup class="after"></sup>\n' + 
'</span><span class="line-488 line"><span class="lineno"> 488 </span>	<span class="n">vsnprintf</span><span class="p">(</span><span class="n">buf</span><span class="p">,</span> <span class="k">sizeof</span><span class="p">(</span><span class="n">buf</span><span class="p">),</span> <span class="n">fmtf</span><span class="p">,</span> <span class="n">args</span><span class="p">);</span><sup class="after"></sup>\n' + 
'</span><span class="line-489 line"><span class="lineno"> 489 </span>	<span class="n">va_end</span><span class="p">(</span><span class="n">args</span><span class="p">);</span><sup class="after"></sup>\n' + 
'</span><span class="line-490 line"><span class="lineno"> 490 </span><sup class="after"></sup>\n' + 
'</span><span class="line-491 line"><span class="lineno"> 491 </span>	<span class="n">prtab</span><span class="p">(</span><span class="n">nr_tab</span><span class="p">);</span><sup class="after"></sup>\n' + 
'</span><span class="line-492 line"><span class="lineno"> 492 </span>	<span class="n">printf</span><span class="p">(</span><span class="s">&quot;%s&quot;</span><span class="p">,</span> <span class="n">buf</span><span class="p">);</span><sup class="after"></sup>\n' + 
'</span><span class="line-493 line"><span class="lineno"> 493 </span><span class="p">}</span><sup class="after"></sup>\n' + 
'</span><span class="line-494 line"><span class="lineno"> 494 </span><sup class="after"></sup>\n' + 
'</span><span class="line-495 line"><span class="lineno"> 495 </span><span class="cm">/*</span><sup class="after"></sup>\n' + 
'</span><span class="line-496 line"><span class="lineno"> 496 </span><span class="cm"> ***************************************************************************</span><sup class="after"></sup>\n' + 
'</span><span class="line-497 line"><span class="lineno"> 497 </span><span class="cm"> * printf() function modified for XML-like output. Print a CR at the end of</span><sup class="after"></sup>\n' + 
'</span><span class="line-498 line"><span class="lineno"> 498 </span><span class="cm"> * the line.</span><sup class="after"></sup>\n' + 
'</span><span class="line-499 line"><span class="lineno"> 499 </span><span class="cm"> *</span><sup class="after"></sup>\n' + 
'</span><span class="line-500 line"><span class="lineno"> 500 </span><span class="cm"> * IN:</span><sup class="after"></sup>\n' + 
'</span><span class="line-501 line"><span class="lineno"> 501 </span><span class="cm"> * @nr_tab	Number of tabs to print.</span><sup class="after"></sup>\n' + 
'</span><span class="line-502 line"><span class="lineno"> 502 </span><span class="cm"> * @fmtf	printf() format.</span><sup class="after"></sup>\n' + 
'</span><span class="line-503 line"><span class="lineno"> 503 </span><span class="cm"> ***************************************************************************</span><sup class="after"></sup>\n' + 
'</span><span class="line-504 line"><span class="lineno"> 504 </span><span class="cm"> */</span><sup class="after"></sup>\n' + 
'</span><span class="line-505 line"><span class="lineno"> 505 </span><span class="kt">void</span> <span class="nf">xprintf</span><span class="p">(</span><span class="kt">int</span> <span class="n">nr_tab</span><span class="p">,</span> <span class="k">const</span> <span class="kt">char</span> <span class="o">*</span><span class="n">fmtf</span><span class="p">,</span> <span class="p">...)</span><sup class="after"></sup>\n' + 
'</span><span class="line-506 line"><span class="lineno"> 506 </span><span class="p">{</span><sup class="after"></sup>\n' + 
'</span><span class="line-507 line"><span class="lineno"> 507 </span>	<span class="k">static</span> <span class="kt">char</span> <span class="n">buf</span><span class="p">[</span><span class="mi">1024</span><span class="p">];</span><sup class="after"></sup>\n' + 
'</span><span class="line-508 line"><span class="lineno"> 508 </span>	<span class="kt">va_list</span> <span class="n">args</span><span class="p">;</span><sup class="after"></sup>\n' + 
'</span><span class="line-509 line"><span class="lineno"> 509 </span><sup class="after"></sup>\n' + 
'</span><span class="line-510 line"><span class="lineno"> 510 </span>	<span class="n">va_start</span><span class="p">(</span><span class="n">args</span><span class="p">,</span> <span class="n">fmtf</span><span class="p">);</span><sup class="after"></sup>\n' + 
'</span><span class="line-511 line"><span class="lineno"> 511 </span>	<span class="n">vsnprintf</span><span class="p">(</span><span class="n">buf</span><span class="p">,</span> <span class="k">sizeof</span><span class="p">(</span><span class="n">buf</span><span class="p">),</span> <span class="n">fmtf</span><span class="p">,</span> <span class="n">args</span><span class="p">);</span><sup class="after"></sup>\n' + 
'</span><span class="line-512 line"><span class="lineno"> 512 </span>	<span class="n">va_end</span><span class="p">(</span><span class="n">args</span><span class="p">);</span><sup class="after"></sup>\n' + 
'</span><span class="line-513 line"><span class="lineno"> 513 </span><sup class="after"></sup>\n' + 
'</span><span class="line-514 line"><span class="lineno"> 514 </span>	<span class="n">prtab</span><span class="p">(</span><span class="n">nr_tab</span><span class="p">);</span><sup class="after"></sup>\n' + 
'</span><span class="line-515 line"><span class="lineno"> 515 </span>	<span class="n">printf</span><span class="p">(</span><span class="s">&quot;%s</span><span class="se">\\n</span><span class="s">&quot;</span><span class="p">,</span> <span class="n">buf</span><span class="p">);</span><sup class="after"></sup>\n' + 
'</span><span class="line-516 line"><span class="lineno"> 516 </span><span class="p">}</span><sup class="after"></sup>\n' + 
'</span><span class="line-517 line"><span class="lineno"> 517 </span><sup class="after"></sup>\n' + 
'</span><span class="line-518 line"><span class="lineno"> 518 </span><span class="cm">/*</span><sup class="after"></sup>\n' + 
'</span><span class="line-519 line"><span class="lineno"> 519 </span><span class="cm"> ***************************************************************************</span><sup class="after"></sup>\n' + 
'</span><span class="line-520 line"><span class="lineno"> 520 </span><span class="cm"> * Get report date as a string of characters.</span><sup class="after"></sup>\n' + 
'</span><span class="line-521 line"><span class="lineno"> 521 </span><span class="cm"> *</span><sup class="after"></sup>\n' + 
'</span><span class="line-522 line"><span class="lineno"> 522 </span><span class="cm"> * IN:</span><sup class="after"></sup>\n' + 
'</span><span class="line-523 line"><span class="lineno"> 523 </span><span class="cm"> * @rectime	Date to display (don&#39;t use time fields).</span><sup class="after"></sup>\n' + 
'</span><span class="line-524 line"><span class="lineno"> 524 </span><span class="cm"> * @cur_date	String where date will be saved.</span><sup class="after"></sup>\n' + 
'</span><span class="line-525 line"><span class="lineno"> 525 </span><span class="cm"> * @sz		Max size of cur_date string.</span><sup class="after"></sup>\n' + 
'</span><span class="line-526 line"><span class="lineno"> 526 </span><span class="cm"> *</span><sup class="after"></sup>\n' + 
'</span><span class="line-527 line"><span class="lineno"> 527 </span><span class="cm"> * OUT:</span><sup class="after"></sup>\n' + 
'</span><span class="line-528 line"><span class="lineno"> 528 </span><span class="cm"> * @cur_date	Date (string format).</span><sup class="after"></sup>\n' + 
'</span><span class="line-529 line"><span class="lineno"> 529 </span><span class="cm"> *</span><sup class="after"></sup>\n' + 
'</span><span class="line-530 line"><span class="lineno"> 530 </span><span class="cm"> * RETURNS:</span><sup class="after"></sup>\n' + 
'</span><span class="line-531 line"><span class="lineno"> 531 </span><span class="cm"> * TRUE if S_TIME_FORMAT is set to ISO, or FALSE otherwise.</span><sup class="after"></sup>\n' + 
'</span><span class="line-532 line"><span class="lineno"> 532 </span><span class="cm"> ***************************************************************************</span><sup class="after"></sup>\n' + 
'</span><span class="line-533 line"><span class="lineno"> 533 </span><span class="cm"> */</span><sup class="after"></sup>\n' + 
'</span><span class="line-534 line"><span class="lineno"> 534 </span><span class="kt">int</span> <span class="nf">set_report_date</span><span class="p">(</span><span class="k">struct</span> <span class="n">tm</span> <span class="o">*</span><span class="n">rectime</span><span class="p">,</span> <span class="kt">char</span> <span class="n">cur_date</span><span class="p">[],</span> <span class="kt">int</span> <span class="n">sz</span><span class="p">)</span><sup class="after"></sup>\n' + 
'</span><span class="line-535 line"><span class="lineno"> 535 </span><span class="p">{</span><sup class="after"></sup>\n' + 
'</span><span class="line-536 line"><span class="lineno"> 536 </span>	<span class="k">if</span> <span class="p">(</span><span class="n">rectime</span> <span class="o">==</span> <span class="nb">NULL</span><span class="p">)</span> <span class="p">{</span><sup class="after"></sup>\n' + 
'</span><span class="line-537 line"><span class="lineno"> 537 </span>		<span class="n">strncpy</span><span class="p">(</span><span class="n">cur_date</span><span class="p">,</span> <span class="s">&quot;?/?/?&quot;</span><span class="p">,</span> <span class="n">sz</span><span class="p">);</span><sup class="after"></sup>\n' + 
'</span><span class="line-538 line"><span class="lineno"> 538 </span>		<span class="n">cur_date</span><span class="p">[</span><span class="n">sz</span> <span class="o">-</span> <span class="mi">1</span><span class="p">]</span> <span class="o">=</span> <span class="sc">&#39;\\0&#39;</span><span class="p">;</span><sup class="after"></sup>\n' + 
'</span><span class="line-539 line"><span class="lineno"> 539 </span>	<span class="p">}</span><sup class="after"></sup>\n' + 
'</span><span class="line-540 line"><span class="lineno"> 540 </span>	<span class="k">else</span> <span class="k">if</span> <span class="p">(</span><span class="n">is_iso_time_fmt</span><span class="p">())</span> <span class="p">{</span><sup class="after"></sup>\n' + 
'</span><span class="line-541 line"><span class="lineno"> 541 </span>		<span class="n">strftime</span><span class="p">(</span><span class="n">cur_date</span><span class="p">,</span> <span class="n">sz</span><span class="p">,</span> <span class="s">&quot;%Y-%m-%d&quot;</span><span class="p">,</span> <span class="n">rectime</span><span class="p">);</span><sup class="after"></sup>\n' + 
'</span><span class="line-542 line"><span class="lineno"> 542 </span>		<span class="k">return</span> <span class="mi">1</span><span class="p">;</span><sup class="after"></sup>\n' + 
'</span><span class="line-543 line"><span class="lineno"> 543 </span>	<span class="p">}</span><sup class="after"></sup>\n' + 
'</span><span class="line-544 line"><span class="lineno"> 544 </span>	<span class="k">else</span> <span class="p">{</span><sup class="after"></sup>\n' + 
'</span><span class="line-545 line"><span class="lineno"> 545 </span>		<span class="n">strftime</span><span class="p">(</span><span class="n">cur_date</span><span class="p">,</span> <span class="n">sz</span><span class="p">,</span> <span class="s">&quot;%x&quot;</span><span class="p">,</span> <span class="n">rectime</span><span class="p">);</span><sup class="after"></sup>\n' + 
'</span><span class="line-546 line"><span class="lineno"> 546 </span>	<span class="p">}</span><sup class="after"></sup>\n' + 
'</span><span class="line-547 line"><span class="lineno"> 547 </span><sup class="after"></sup>\n' + 
'</span><span class="line-548 line"><span class="lineno"> 548 </span>	<span class="k">return</span> <span class="mi">0</span><span class="p">;</span><sup class="after"></sup>\n' + 
'</span><span class="line-549 line"><span class="lineno"> 549 </span><span class="p">}</span><sup class="after"></sup>\n' + 
'</span><span class="line-550 line"><span class="lineno"> 550 </span><sup class="after"></sup>\n' + 
'</span><span class="line-551 line"><span class="lineno"> 551 </span><span class="cm">/*</span><sup class="after"></sup>\n' + 
'</span><span class="line-552 line"><span class="lineno"> 552 </span><span class="cm"> ***************************************************************************</span><sup class="after"></sup>\n' + 
'</span><span class="line-553 line"><span class="lineno"> 553 </span><span class="cm"> * Print banner.</span><sup class="after"></sup>\n' + 
'</span><span class="line-554 line"><span class="lineno"> 554 </span><span class="cm"> *</span><sup class="after"></sup>\n' + 
'</span><span class="line-555 line"><span class="lineno"> 555 </span><span class="cm"> * IN:</span><sup class="after"></sup>\n' + 
'</span><span class="line-556 line"><span class="lineno"> 556 </span><span class="cm"> * @rectime	Date to display (don&#39;t use time fields).</span><sup class="after"></sup>\n' + 
'</span><span class="line-557 line"><span class="lineno"> 557 </span><span class="cm"> * @sysname	System name to display.</span><sup class="after"></sup>\n' + 
'</span><span class="line-558 line"><span class="lineno"> 558 </span><span class="cm"> * @release	System release number to display.</span><sup class="after"></sup>\n' + 
'</span><span class="line-559 line"><span class="lineno"> 559 </span><span class="cm"> * @nodename	Hostname to display.</span><sup class="after"></sup>\n' + 
'</span><span class="line-560 line"><span class="lineno"> 560 </span><span class="cm"> * @machine	Machine architecture to display.</span><sup class="after"></sup>\n' + 
'</span><span class="line-561 line"><span class="lineno"> 561 </span><span class="cm"> * @cpu_nr	Number of CPU.</span><sup class="after"></sup>\n' + 
'</span><span class="line-562 line"><span class="lineno"> 562 </span><span class="cm"> * @format	Set to FALSE for (default) plain output, and to TRUE for</span><sup class="after"></sup>\n' + 
'</span><span class="line-563 line"><span class="lineno"> 563 </span><span class="cm"> * 		JSON format output.</span><sup class="after"></sup>\n' + 
'</span><span class="line-564 line"><span class="lineno"> 564 </span><span class="cm"> *</span><sup class="after"></sup>\n' + 
'</span><span class="line-565 line"><span class="lineno"> 565 </span><span class="cm"> * RETURNS:</span><sup class="after"></sup>\n' + 
'</span><span class="line-566 line"><span class="lineno"> 566 </span><span class="cm"> * TRUE if S_TIME_FORMAT is set to ISO, or FALSE otherwise.</span><sup class="after"></sup>\n' + 
'</span><span class="line-567 line"><span class="lineno"> 567 </span><span class="cm"> ***************************************************************************</span><sup class="after"></sup>\n' + 
'</span><span class="line-568 line"><span class="lineno"> 568 </span><span class="cm"> */</span><sup class="after"></sup>\n' + 
'</span><span class="line-569 line"><span class="lineno"> 569 </span><span class="kt">int</span> <span class="nf">print_gal_header</span><span class="p">(</span><span class="k">struct</span> <span class="n">tm</span> <span class="o">*</span><span class="n">rectime</span><span class="p">,</span> <span class="kt">char</span> <span class="o">*</span><span class="n">sysname</span><span class="p">,</span> <span class="kt">char</span> <span class="o">*</span><span class="n">release</span><span class="p">,</span><sup class="after"></sup>\n' + 
'</span><span class="line-570 line"><span class="lineno"> 570 </span>		     <span class="kt">char</span> <span class="o">*</span><span class="n">nodename</span><span class="p">,</span> <span class="kt">char</span> <span class="o">*</span><span class="n">machine</span><span class="p">,</span> <span class="kt">int</span> <span class="n">cpu_nr</span><span class="p">,</span> <span class="kt">int</span> <span class="n">format</span><span class="p">)</span><sup class="after"></sup>\n' + 
'</span><span class="line-571 line"><span class="lineno"> 571 </span><span class="p">{</span><sup class="after"></sup>\n' + 
'</span><span class="line-572 line"><span class="lineno"> 572 </span>	<span class="kt">char</span> <span class="n">cur_date</span><span class="p">[</span><span class="n">TIMESTAMP_LEN</span><span class="p">];</span><sup class="after"></sup>\n' + 
'</span><span class="line-573 line"><span class="lineno"> 573 </span>	<span class="kt">int</span> <span class="n">rc</span> <span class="o">=</span> <span class="mi">0</span><span class="p">;</span><sup class="after"></sup>\n' + 
'</span><span class="line-574 line"><span class="lineno"> 574 </span><sup class="after"></sup>\n' + 
'</span><span class="line-575 line"><span class="lineno"> 575 </span>	<span class="n">rc</span> <span class="o">=</span> <span class="n">set_report_date</span><span class="p">(</span><span class="n">rectime</span><span class="p">,</span> <span class="n">cur_date</span><span class="p">,</span> <span class="k">sizeof</span><span class="p">(</span><span class="n">cur_date</span><span class="p">));</span><sup class="after"></sup>\n' + 
'</span><span class="line-576 line"><span class="lineno"> 576 </span><sup class="after"></sup>\n' + 
'</span><span class="line-577 line"><span class="lineno"> 577 </span>	<span class="k">if</span> <span class="p">(</span><span class="n">format</span> <span class="o">==</span> <span class="n">PLAIN_OUTPUT</span><span class="p">)</span> <span class="p">{</span><sup class="after"></sup>\n' + 
'</span><span class="line-578 line"><span class="lineno"> 578 </span>		<span class="cm">/* Plain output */</span><sup class="after"></sup>\n' + 
'</span><span class="line-579 line"><span class="lineno"> 579 </span>		<span class="n">printf</span><span class="p">(</span><span class="s">&quot;%s %s (%s) </span><span class="se">\\t</span><span class="s">%s </span><span class="se">\\t</span><span class="s">_%s_</span><span class="se">\\t</span><span class="s">(%d CPU)</span><span class="se">\\n</span><span class="s">&quot;</span><span class="p">,</span> <span class="n">sysname</span><span class="p">,</span> <span class="n">release</span><span class="p">,</span> <span class="n">nodename</span><span class="p">,</span><sup class="after"></sup>\n' + 
'</span><span class="line-580 line"><span class="lineno"> 580 </span>		       <span class="n">cur_date</span><span class="p">,</span> <span class="n">machine</span><span class="p">,</span> <span class="n">cpu_nr</span><span class="p">);</span><sup class="after"></sup>\n' + 
'</span><span class="line-581 line"><span class="lineno"> 581 </span>	<span class="p">}</span><sup class="after"></sup>\n' + 
'</span><span class="line-582 line"><span class="lineno"> 582 </span>	<span class="k">else</span> <span class="p">{</span><sup class="after"></sup>\n' + 
'</span><span class="line-583 line"><span class="lineno"> 583 </span>		<span class="cm">/* JSON output */</span><sup class="after"></sup>\n' + 
'</span><span class="line-584 line"><span class="lineno"> 584 </span>		<span class="n">xprintf</span><span class="p">(</span><span class="mi">0</span><span class="p">,</span> <span class="s">&quot;{</span><span class="se">\\&quot;</span><span class="s">sysstat</span><span class="se">\\&quot;</span><span class="s">: {&quot;</span><span class="p">);</span><sup class="after"></sup>\n' + 
'</span><span class="line-585 line"><span class="lineno"> 585 </span>		<span class="n">xprintf</span><span class="p">(</span><span class="mi">1</span><span class="p">,</span> <span class="s">&quot;</span><span class="se">\\&quot;</span><span class="s">hosts</span><span class="se">\\&quot;</span><span class="s">: [&quot;</span><span class="p">);</span><sup class="after"></sup>\n' + 
'</span><span class="line-586 line"><span class="lineno"> 586 </span>		<span class="n">xprintf</span><span class="p">(</span><span class="mi">2</span><span class="p">,</span> <span class="s">&quot;{&quot;</span><span class="p">);</span><sup class="after"></sup>\n' + 
'</span><span class="line-587 line"><span class="lineno"> 587 </span>		<span class="n">xprintf</span><span class="p">(</span><span class="mi">3</span><span class="p">,</span> <span class="s">&quot;</span><span class="se">\\&quot;</span><span class="s">nodename</span><span class="se">\\&quot;</span><span class="s">: </span><span class="se">\\&quot;</span><span class="s">%s</span><span class="se">\\&quot;</span><span class="s">,&quot;</span><span class="p">,</span> <span class="n">nodename</span><span class="p">);</span><sup class="after"></sup>\n' + 
'</span><span class="line-588 line"><span class="lineno"> 588 </span>		<span class="n">xprintf</span><span class="p">(</span><span class="mi">3</span><span class="p">,</span> <span class="s">&quot;</span><span class="se">\\&quot;</span><span class="s">sysname</span><span class="se">\\&quot;</span><span class="s">: </span><span class="se">\\&quot;</span><span class="s">%s</span><span class="se">\\&quot;</span><span class="s">,&quot;</span><span class="p">,</span> <span class="n">sysname</span><span class="p">);</span><sup class="after"></sup>\n' + 
'</span><span class="line-589 line"><span class="lineno"> 589 </span>		<span class="n">xprintf</span><span class="p">(</span><span class="mi">3</span><span class="p">,</span> <span class="s">&quot;</span><span class="se">\\&quot;</span><span class="s">release</span><span class="se">\\&quot;</span><span class="s">: </span><span class="se">\\&quot;</span><span class="s">%s</span><span class="se">\\&quot;</span><span class="s">,&quot;</span><span class="p">,</span> <span class="n">release</span><span class="p">);</span><sup class="after"></sup>\n' + 
'</span><span class="line-590 line"><span class="lineno"> 590 </span>		<span class="n">xprintf</span><span class="p">(</span><span class="mi">3</span><span class="p">,</span> <span class="s">&quot;</span><span class="se">\\&quot;</span><span class="s">machine</span><span class="se">\\&quot;</span><span class="s">: </span><span class="se">\\&quot;</span><span class="s">%s</span><span class="se">\\&quot;</span><span class="s">,&quot;</span><span class="p">,</span> <span class="n">machine</span><span class="p">);</span><sup class="after"></sup>\n' + 
'</span><span class="line-591 line"><span class="lineno"> 591 </span>		<span class="n">xprintf</span><span class="p">(</span><span class="mi">3</span><span class="p">,</span> <span class="s">&quot;</span><span class="se">\\&quot;</span><span class="s">number-of-cpus</span><span class="se">\\&quot;</span><span class="s">: %d,&quot;</span><span class="p">,</span> <span class="n">cpu_nr</span><span class="p">);</span><sup class="after"></sup>\n' + 
'</span><span class="line-592 line"><span class="lineno"> 592 </span>		<span class="n">xprintf</span><span class="p">(</span><span class="mi">3</span><span class="p">,</span> <span class="s">&quot;</span><span class="se">\\&quot;</span><span class="s">date</span><span class="se">\\&quot;</span><span class="s">: </span><span class="se">\\&quot;</span><span class="s">%s</span><span class="se">\\&quot;</span><span class="s">,&quot;</span><span class="p">,</span> <span class="n">cur_date</span><span class="p">);</span><sup class="after"></sup>\n' + 
'</span><span class="line-593 line"><span class="lineno"> 593 </span>		<span class="n">xprintf</span><span class="p">(</span><span class="mi">3</span><span class="p">,</span> <span class="s">&quot;</span><span class="se">\\&quot;</span><span class="s">statistics</span><span class="se">\\&quot;</span><span class="s">: [&quot;</span><span class="p">);</span><sup class="after"></sup>\n' + 
'</span><span class="line-594 line"><span class="lineno"> 594 </span>	<span class="p">}</span><sup class="after"></sup>\n' + 
'</span><span class="line-595 line"><span class="lineno"> 595 </span><sup class="after"></sup>\n' + 
'</span><span class="line-596 line"><span class="lineno"> 596 </span>	<span class="k">return</span> <span class="n">rc</span><span class="p">;</span><sup class="after"></sup>\n' + 
'</span><span class="line-597 line"><span class="lineno"> 597 </span><span class="p">}</span><sup class="after"></sup>\n' + 
'</span><span class="line-598 line"><span class="lineno"> 598 </span><sup class="after"></sup>\n' + 
'</span><span class="line-599 line"><span class="lineno"> 599 </span><span class="cm">/*</span><sup class="after"></sup>\n' + 
'</span><span class="line-600 line"><span class="lineno"> 600 </span><span class="cm"> ***************************************************************************</span><sup class="after"></sup>\n' + 
'</span><span class="line-601 line"><span class="lineno"> 601 </span><span class="cm"> * Get number of rows for current window.</span><sup class="after"></sup>\n' + 
'</span><span class="line-602 line"><span class="lineno"> 602 </span><span class="cm"> *</span><sup class="after"></sup>\n' + 
'</span><span class="line-603 line"><span class="lineno"> 603 </span><span class="cm"> * RETURNS:</span><sup class="after"></sup>\n' + 
'</span><span class="line-604 line"><span class="lineno"> 604 </span><span class="cm"> * Number of rows.</span><sup class="after"></sup>\n' + 
'</span><span class="line-605 line"><span class="lineno"> 605 </span><span class="cm"> ***************************************************************************</span><sup class="after"></sup>\n' + 
'</span><span class="line-606 line"><span class="lineno"> 606 </span><span class="cm"> */</span><sup class="after"></sup>\n' + 
'</span><span class="line-607 line"><span class="lineno"> 607 </span><span class="kt">int</span> <span class="nf">get_win_height</span><span class="p">(</span><span class="kt">void</span><span class="p">)</span><sup class="after"></sup>\n' + 
'</span><span class="line-608 line"><span class="lineno"> 608 </span><span class="p">{</span><sup class="after"></sup>\n' + 
'</span><span class="line-609 line"><span class="lineno"> 609 </span>	<span class="k">struct</span> <span class="n">winsize</span> <span class="n">win</span><span class="p">;</span><sup class="after"></sup>\n' + 
'</span><span class="line-610 line"><span class="lineno"> 610 </span>	<span class="cm">/*</span><sup class="after"></sup>\n' + 
'</span><span class="line-611 line"><span class="lineno"> 611 </span><span class="cm">	 * This default value will be used whenever STDOUT</span><sup class="after"></sup>\n' + 
'</span><span class="line-612 line"><span class="lineno"> 612 </span><span class="cm">	 * is redirected to a pipe or a file</span><sup class="after"></sup>\n' + 
'</span><span class="line-613 line"><span class="lineno"> 613 </span><span class="cm">	 */</span><sup class="after"></sup>\n' + 
'</span><span class="line-614 line"><span class="lineno"> 614 </span>	<span class="kt">int</span> <span class="n">rows</span> <span class="o">=</span> <span class="mi">3600</span> <span class="o">*</span> <span class="mi">24</span><span class="p">;</span><sup class="after"></sup>\n' + 
'</span><span class="line-615 line"><span class="lineno"> 615 </span><sup class="after"></sup>\n' + 
'</span><span class="line-616 line"><span class="lineno"> 616 </span>	<span class="k">if</span> <span class="p">(</span><span class="n">ioctl</span><span class="p">(</span><span class="n">STDOUT_FILENO</span><span class="p">,</span> <span class="n">TIOCGWINSZ</span><span class="p">,</span> <span class="o">&amp;</span><span class="n">win</span><span class="p">)</span> <span class="o">!=</span> <span class="o">-</span><span class="mi">1</span><span class="p">)</span> <span class="p">{</span><sup class="after"></sup>\n' + 
'</span><span class="line-617 line"><span class="lineno"> 617 </span>		<span class="k">if</span> <span class="p">(</span><span class="n">win</span><span class="p">.</span><span class="n">ws_row</span> <span class="o">&gt;</span> <span class="mi">2</span><span class="p">)</span> <span class="p">{</span><sup class="after"></sup>\n' + 
'</span><span class="line-618 line"><span class="lineno"> 618 </span>			<span class="n">rows</span> <span class="o">=</span> <span class="n">win</span><span class="p">.</span><span class="n">ws_row</span> <span class="o">-</span> <span class="mi">2</span><span class="p">;</span><sup class="after"></sup>\n' + 
'</span><span class="line-619 line"><span class="lineno"> 619 </span>		<span class="p">}</span><sup class="after"></sup>\n' + 
'</span><span class="line-620 line"><span class="lineno"> 620 </span>	<span class="p">}</span><sup class="after"></sup>\n' + 
'</span><span class="line-621 line"><span class="lineno"> 621 </span>	<span class="k">return</span> <span class="n">rows</span><span class="p">;</span><sup class="after"></sup>\n' + 
'</span><span class="line-622 line"><span class="lineno"> 622 </span><span class="p">}</span><sup class="after"></sup>\n' + 
'</span><span class="line-623 line"><span class="lineno"> 623 </span><sup class="after"></sup>\n' + 
'</span><span class="line-624 line"><span class="lineno"> 624 </span><span class="cm">/*</span><sup class="after"></sup>\n' + 
'</span><span class="line-625 line"><span class="lineno"> 625 </span><span class="cm"> ***************************************************************************</span><sup class="after"></sup>\n' + 
'</span><span class="line-626 line"><span class="lineno"> 626 </span><span class="cm"> * Canonicalize and remove /dev from path name.</span><sup class="after"></sup>\n' + 
'</span><span class="line-627 line"><span class="lineno"> 627 </span><span class="cm"> *</span><sup class="after"></sup>\n' + 
'</span><span class="line-628 line"><span class="lineno"> 628 </span><span class="cm"> * IN:</span><sup class="after"></sup>\n' + 
'</span><span class="line-629 line"><span class="lineno"> 629 </span><span class="cm"> * @name	Device name (may begin with &quot;/dev/&quot; or can be a symlink).</span><sup class="after"></sup>\n' + 
'</span><span class="line-630 line"><span class="lineno"> 630 </span><span class="cm"> *</span><sup class="after"></sup>\n' + 
'</span><span class="line-631 line"><span class="lineno"> 631 </span><span class="cm"> * RETURNS:</span><sup class="after"></sup>\n' + 
'</span><span class="line-632 line"><span class="lineno"> 632 </span><span class="cm"> * Device basename.</span><sup class="after"></sup>\n' + 
'</span><span class="line-633 line"><span class="lineno"> 633 </span><span class="cm"> ***************************************************************************</span><sup class="after"></sup>\n' + 
'</span><span class="line-634 line"><span class="lineno"> 634 </span><span class="cm"> */</span><sup class="after"></sup>\n' + 
'</span><span class="line-635 line"><span class="lineno"> 635 </span><span class="kt">char</span> <span class="o">*</span><span class="nf">device_name</span><span class="p">(</span><span class="kt">char</span> <span class="o">*</span><span class="n">name</span><span class="p">)</span><sup class="after"></sup>\n' + 
'</span><span class="line-636 line"><span class="lineno"> 636 </span><span class="p">{</span><sup class="after"></sup>\n' + 
'</span><span class="line-637 line"><span class="lineno"> 637 </span>	<span class="k">static</span> <span class="kt">char</span> <span class="n">out</span><span class="p">[</span><span class="n">MAX_FILE_LEN</span><span class="p">];</span><sup class="after"></sup>\n' + 
'</span><span class="line-638 line"><span class="lineno"> 638 </span>	<span class="kt">char</span> <span class="o">*</span><span class="n">resolved_name</span><span class="p">;</span><sup class="after"></sup>\n' + 
'</span><span class="line-639 line"><span class="lineno"> 639 </span>	<span class="kt">int</span> <span class="n">i</span> <span class="o">=</span> <span class="mi">0</span><span class="p">;</span><sup class="after"></sup>\n' + 
'</span><span class="line-640 line"><span class="lineno"> 640 </span><sup class="after"></sup>\n' + 
'</span><span class="line-641 line"><span class="lineno"> 641 </span>	<span class="cm">/* realpath() creates new string, so we need to free it later */</span><sup class="after"></sup>\n' + 
'</span><span class="line-642 line"><span class="lineno"> 642 </span>	<span class="n">resolved_name</span> <span class="o">=</span> <span class="n">realpath</span><span class="p">(</span><span class="n">name</span><span class="p">,</span> <span class="nb">NULL</span><span class="p">);</span><sup class="after"></sup>\n' + 
'</span><span class="line-643 line"><span class="lineno"> 643 </span><sup class="after"></sup>\n' + 
'</span><span class="line-644 line"><span class="lineno"> 644 </span>	<span class="cm">/* If path doesn&#39;t exist, just return input */</span><sup class="after"></sup>\n' + 
'</span><span class="line-645 line"><span class="lineno"> 645 </span>	<span class="k">if</span> <span class="p">(</span><span class="o">!</span><span class="n">resolved_name</span><span class="p">)</span> <span class="p">{</span><sup class="after"></sup>\n' + 
'</span><span class="line-646 line"><span class="lineno"> 646 </span>		<span class="k">return</span> <span class="n">name</span><span class="p">;</span><sup class="after"></sup>\n' + 
'</span><span class="line-647 line"><span class="lineno"> 647 </span>	<span class="p">}</span><sup class="after"></sup>\n' + 
'</span><span class="line-648 line"><span class="lineno"> 648 </span><sup class="after"></sup>\n' + 
'</span><span class="line-649 line"><span class="lineno"> 649 </span>	<span class="k">if</span> <span class="p">(</span><span class="o">!</span><span class="n">strncmp</span><span class="p">(</span><span class="n">resolved_name</span><span class="p">,</span> <span class="s">&quot;/dev/&quot;</span><span class="p">,</span> <span class="mi">5</span><span class="p">))</span> <span class="p">{</span><sup class="after"></sup>\n' + 
'</span><span class="line-650 line"><span class="lineno"> 650 </span>		<span class="n">i</span> <span class="o">=</span> <span class="mi">5</span><span class="p">;</span><sup class="after"></sup>\n' + 
'</span><span class="line-651 line"><span class="lineno"> 651 </span>	<span class="p">}</span><sup class="after"></sup>\n' + 
'</span><span class="line-652 line"><span class="lineno"> 652 </span>	<span class="n">strncpy</span><span class="p">(</span><span class="n">out</span><span class="p">,</span> <span class="n">resolved_name</span> <span class="o">+</span> <span class="n">i</span><span class="p">,</span> <span class="n">MAX_FILE_LEN</span><span class="p">);</span><sup class="after"></sup>\n' + 
'</span><span class="line-653 line"><span class="lineno"> 653 </span>	<span class="n">out</span><span class="p">[</span><span class="n">MAX_FILE_LEN</span> <span class="o">-</span> <span class="mi">1</span><span class="p">]</span> <span class="o">=</span> <span class="sc">&#39;\\0&#39;</span><span class="p">;</span><sup class="after"></sup>\n' + 
'</span><span class="line-654 line"><span class="lineno"> 654 </span><sup class="after"></sup>\n' + 
'</span><span class="line-655 line"><span class="lineno"> 655 </span>	<span class="n">free</span><span class="p">(</span><span class="n">resolved_name</span><span class="p">);</span><sup class="after"></sup>\n' + 
'</span><span class="line-656 line"><span class="lineno"> 656 </span><sup class="after"></sup>\n' + 
'</span><span class="line-657 line"><span class="lineno"> 657 </span>	<span class="k">return</span> <span class="n">out</span><span class="p">;</span><sup class="after"></sup>\n' + 
'</span><span class="line-658 line"><span class="lineno"> 658 </span><span class="p">}</span><sup class="after"></sup>\n' + 
'</span><span class="line-659 line"><span class="lineno"> 659 </span><sup class="after"></sup>\n' + 
'</span><span class="line-660 line"><span class="lineno"> 660 </span><span class="cm">/*</span><sup class="after"></sup>\n' + 
'</span><span class="line-661 line"><span class="lineno"> 661 </span><span class="cm"> ***************************************************************************</span><sup class="after"></sup>\n' + 
'</span><span class="line-662 line"><span class="lineno"> 662 </span><span class="cm"> * Workaround for CPU counters read from /proc/stat: Dyn-tick kernels</span><sup class="after"></sup>\n' + 
'</span><span class="line-663 line"><span class="lineno"> 663 </span><span class="cm"> * have a race issue that can make those counters go backward.</span><sup class="after"></sup>\n' + 
'</span><span class="line-664 line"><span class="lineno"> 664 </span><span class="cm"> ***************************************************************************</span><sup class="after"></sup>\n' + 
'</span><span class="line-665 line"><span class="lineno"> 665 </span><span class="cm"> */</span><sup class="after"></sup>\n' + 
'</span><span class="line-666 line"><span class="lineno"> 666 </span><span class="kt">double</span> <span class="nf">ll_sp_value</span><span class="p">(</span><span class="kt">unsigned</span> <span class="kt">long</span> <span class="kt">long</span> <span class="n">value1</span><span class="p">,</span> <span class="kt">unsigned</span> <span class="kt">long</span> <span class="kt">long</span> <span class="n">value2</span><span class="p">,</span><sup class="after"></sup>\n' + 
'</span><span class="line-667 line"><span class="lineno"> 667 </span>		   <span class="kt">unsigned</span> <span class="kt">long</span> <span class="kt">long</span> <span class="n">itv</span><span class="p">)</span><sup class="after"></sup>\n' + 
'</span><span class="line-668 line"><span class="lineno"> 668 </span><span class="p">{</span><sup class="after"></sup>\n' + 
'</span><span class="line-669 line"><span class="lineno"> 669 </span>	<span class="k">if</span> <span class="p">(</span><span class="n">value2</span> <span class="o">&lt;</span> <span class="n">value1</span><span class="p">)</span><sup class="after"></sup>\n' + 
'</span><span class="line-670 line"><span class="lineno"> 670 </span>		<span class="k">return</span> <span class="p">(</span><span class="kt">double</span><span class="p">)</span> <span class="mi">0</span><span class="p">;</span><sup class="after"></sup>\n' + 
'</span><span class="line-671 line"><span class="lineno"> 671 </span>	<span class="k">else</span><sup class="after"></sup>\n' + 
'</span><span class="line-672 line"><span class="lineno"> 672 </span>		<span class="k">return</span> <span class="n">SP_VALUE</span><span class="p">(</span><span class="n">value1</span><span class="p">,</span> <span class="n">value2</span><span class="p">,</span> <span class="n">itv</span><span class="p">);</span><sup class="after"></sup>\n' + 
'</span><span class="line-673 line"><span class="lineno"> 673 </span><span class="p">}</span><sup class="after"></sup>\n' + 
'</span><span class="line-674 line"><span class="lineno"> 674 </span><sup class="after"></sup>\n' + 
'</span><span class="line-675 line"><span class="lineno"> 675 </span><span class="cm">/*</span><sup class="after"></sup>\n' + 
'</span><span class="line-676 line"><span class="lineno"> 676 </span><span class="cm"> ***************************************************************************</span><sup class="after"></sup>\n' + 
'</span><span class="line-677 line"><span class="lineno"> 677 </span><span class="cm"> * Compute time interval.</span><sup class="after"></sup>\n' + 
'</span><span class="line-678 line"><span class="lineno"> 678 </span><span class="cm"> *</span><sup class="after"></sup>\n' + 
'</span><span class="line-679 line"><span class="lineno"> 679 </span><span class="cm"> * IN:</span><sup class="after"></sup>\n' + 
'</span><span class="line-680 line"><span class="lineno"> 680 </span><span class="cm"> * @prev_uptime	Previous uptime value (in jiffies or 1/100th of a second).</span><sup class="after"></sup>\n' + 
'</span><span class="line-681 line"><span class="lineno"> 681 </span><span class="cm"> * @curr_uptime	Current uptime value (in jiffies or 1/100th of a second).</span><sup class="after"></sup>\n' + 
'</span><span class="line-682 line"><span class="lineno"> 682 </span><span class="cm"> *</span><sup class="after"></sup>\n' + 
'</span><span class="line-683 line"><span class="lineno"> 683 </span><span class="cm"> * RETURNS:</span><sup class="after"></sup>\n' + 
'</span><span class="line-684 line"><span class="lineno"> 684 </span><span class="cm"> * Interval of time in jiffies or 1/100th of a second.</span><sup class="after"></sup>\n' + 
'</span><span class="line-685 line"><span class="lineno"> 685 </span><span class="cm"> ***************************************************************************</span><sup class="after"></sup>\n' + 
'</span><span class="line-686 line"><span class="lineno"> 686 </span><span class="cm"> */</span><sup class="after"></sup>\n' + 
'</span><span class="line-687 line"><span class="lineno"> 687 </span><span class="kt">unsigned</span> <span class="kt">long</span> <span class="kt">long</span> <span class="nf">get_interval</span><span class="p">(</span><span class="kt">unsigned</span> <span class="kt">long</span> <span class="kt">long</span> <span class="n">prev_uptime</span><span class="p">,</span><sup class="after"></sup>\n' + 
'</span><span class="line-688 line"><span class="lineno"> 688 </span>				<span class="kt">unsigned</span> <span class="kt">long</span> <span class="kt">long</span> <span class="n">curr_uptime</span><span class="p">)</span><sup class="after"></sup>\n' + 
'</span><span class="line-689 line"><span class="lineno"> 689 </span><span class="p">{</span><sup class="after"></sup>\n' + 
'</span><span class="line-690 line"><span class="lineno"> 690 </span>	<span class="kt">unsigned</span> <span class="kt">long</span> <span class="kt">long</span> <span class="n">itv</span><span class="p">;</span><sup class="after"></sup>\n' + 
'</span><span class="line-691 line"><span class="lineno"> 691 </span><sup class="after"></sup>\n' + 
'</span><span class="line-692 line"><span class="lineno"> 692 </span>	<span class="cm">/* prev_time=0 when displaying stats since system startup */</span><sup class="after"></sup>\n' + 
'</span><span class="line-693 line"><span class="lineno"> 693 </span>	<span class="n">itv</span> <span class="o">=</span> <span class="n">curr_uptime</span> <span class="o">-</span> <span class="n">prev_uptime</span><span class="p">;</span><sup class="after"></sup>\n' + 
'</span><span class="line-694 line"><span class="lineno"> 694 </span><sup class="after"></sup>\n' + 
'</span><span class="line-695 line"><span class="lineno"> 695 </span>	<span class="k">if</span> <span class="p">(</span><span class="o">!</span><span class="n">itv</span><span class="p">)</span> <span class="p">{</span>	<span class="cm">/* Paranoia checking */</span><sup class="after"></sup>\n' + 
'</span><span class="line-696 line"><span class="lineno"> 696 </span>		<span class="n">itv</span> <span class="o">=</span> <span class="mi">1</span><span class="p">;</span><sup class="after"></sup>\n' + 
'</span><span class="line-697 line"><span class="lineno"> 697 </span>	<span class="p">}</span><sup class="after"></sup>\n' + 
'</span><span class="line-698 line"><span class="lineno"> 698 </span><sup class="after"></sup>\n' + 
'</span><span class="line-699 line"><span class="lineno"> 699 </span>	<span class="k">return</span> <span class="n">itv</span><span class="p">;</span><sup class="after"></sup>\n' + 
'</span><span class="line-700 line"><span class="lineno"> 700 </span><span class="p">}</span><sup class="after"></sup>\n' + 
'</span><span class="line-701 line"><span class="lineno"> 701 </span><sup class="after"></sup>\n' + 
'</span><span class="line-702 line"><span class="lineno"> 702 </span><span class="cm">/*</span><sup class="after"></sup>\n' + 
'</span><span class="line-703 line"><span class="lineno"> 703 </span><span class="cm"> ***************************************************************************</span><sup class="after"></sup>\n' + 
'</span><span class="line-704 line"><span class="lineno"> 704 </span><span class="cm"> * Count number of bits set in an array.</span><sup class="after"></sup>\n' + 
'</span><span class="line-705 line"><span class="lineno"> 705 </span><span class="cm"> *</span><sup class="after"></sup>\n' + 
'</span><span class="line-706 line"><span class="lineno"> 706 </span><span class="cm"> * IN:</span><sup class="after"></sup>\n' + 
'</span><span class="line-707 line"><span class="lineno"> 707 </span><span class="cm"> * @ptr		Pointer to array.</span><sup class="after"></sup>\n' + 
'</span><span class="line-708 line"><span class="lineno"> 708 </span><span class="cm"> * @size	Size of array in bytes.</span><sup class="after"></sup>\n' + 
'</span><span class="line-709 line"><span class="lineno"> 709 </span><span class="cm"> *</span><sup class="after"></sup>\n' + 
'</span><span class="line-710 line"><span class="lineno"> 710 </span><span class="cm"> * RETURNS:</span><sup class="after"></sup>\n' + 
'</span><span class="line-711 line"><span class="lineno"> 711 </span><span class="cm"> * Number of bits set in the array.</span><sup class="after"></sup>\n' + 
'</span><span class="line-712 line"><span class="lineno"> 712 </span><span class="cm"> ***************************************************************************</span><sup class="after"></sup>\n' + 
'</span><span class="line-713 line"><span class="lineno"> 713 </span><span class="cm">*/</span><sup class="after"></sup>\n' + 
'</span><span class="line-714 line"><span class="lineno"> 714 </span><span class="kt">int</span> <span class="nf">count_bits</span><span class="p">(</span><span class="kt">void</span> <span class="o">*</span><span class="n">ptr</span><span class="p">,</span> <span class="kt">int</span> <span class="n">size</span><span class="p">)</span><sup class="after"></sup>\n' + 
'</span><span class="line-715 line"><span class="lineno"> 715 </span><span class="p">{</span><sup class="after"></sup>\n' + 
'</span><span class="line-716 line"><span class="lineno"> 716 </span>	<span class="kt">int</span> <span class="n">nr</span> <span class="o">=</span> <span class="mi">0</span><span class="p">,</span> <span class="n">i</span><span class="p">,</span> <span class="n">k</span><span class="p">;</span><sup class="after"></sup>\n' + 
'</span><span class="line-717 line"><span class="lineno"> 717 </span>	<span class="kt">char</span> <span class="o">*</span><span class="n">p</span><span class="p">;</span><sup class="after"></sup>\n' + 
'</span><span class="line-718 line"><span class="lineno"> 718 </span><sup class="after"></sup>\n' + 
'</span><span class="line-719 line"><span class="lineno"> 719 </span>	<span class="n">p</span> <span class="o">=</span> <span class="n">ptr</span><span class="p">;</span><sup class="after"></sup>\n' + 
'</span><span class="line-720 line"><span class="lineno"> 720 </span>	<span class="k">for</span> <span class="p">(</span><span class="n">i</span> <span class="o">=</span> <span class="mi">0</span><span class="p">;</span> <span class="n">i</span> <span class="o">&lt;</span> <span class="n">size</span><span class="p">;</span> <span class="n">i</span><span class="o">++</span><span class="p">,</span> <span class="n">p</span><span class="o">++</span><span class="p">)</span> <span class="p">{</span><sup class="after"></sup>\n' + 
'</span><span class="line-721 line"><span class="lineno"> 721 </span>		<span class="n">k</span> <span class="o">=</span> <span class="mh">0x80</span><span class="p">;</span><sup class="after"></sup>\n' + 
'</span><span class="line-722 line"><span class="lineno"> 722 </span>		<span class="k">while</span> <span class="p">(</span><span class="n">k</span><span class="p">)</span> <span class="p">{</span><sup class="after"></sup>\n' + 
'</span><span class="line-723 line"><span class="lineno"> 723 </span>			<span class="k">if</span> <span class="p">(</span><span class="o">*</span><span class="n">p</span> <span class="o">&amp;</span> <span class="n">k</span><span class="p">)</span><sup class="after"></sup>\n' + 
'</span><span class="line-724 line"><span class="lineno"> 724 </span>				<span class="n">nr</span><span class="o">++</span><span class="p">;</span><sup class="after"></sup>\n' + 
'</span><span class="line-725 line"><span class="lineno"> 725 </span>			<span class="n">k</span> <span class="o">&gt;&gt;=</span> <span class="mi">1</span><span class="p">;</span><sup class="after"></sup>\n' + 
'</span><span class="line-726 line"><span class="lineno"> 726 </span>		<span class="p">}</span><sup class="after"></sup>\n' + 
'</span><span class="line-727 line"><span class="lineno"> 727 </span>	<span class="p">}</span><sup class="after"></sup>\n' + 
'</span><span class="line-728 line"><span class="lineno"> 728 </span><sup class="after"></sup>\n' + 
'</span><span class="line-729 line"><span class="lineno"> 729 </span>	<span class="k">return</span> <span class="n">nr</span><span class="p">;</span><sup class="after"></sup>\n' + 
'</span><span class="line-730 line"><span class="lineno"> 730 </span><span class="p">}</span><sup class="after"></sup>\n' + 
'</span><span class="line-731 line"><span class="lineno"> 731 </span><sup class="after"></sup>\n' + 
'</span><span class="line-732 line"><span class="lineno"> 732 </span><span class="cm">/*</span><sup class="after"></sup>\n' + 
'</span><span class="line-733 line"><span class="lineno"> 733 </span><span class="cm"> ***************************************************************************</span><sup class="after"></sup>\n' + 
'</span><span class="line-734 line"><span class="lineno"> 734 </span><span class="cm"> * Convert in-place input string to lowercase.</span><sup class="after"></sup>\n' + 
'</span><span class="line-735 line"><span class="lineno"> 735 </span><span class="cm"> *</span><sup class="after"></sup>\n' + 
'</span><span class="line-736 line"><span class="lineno"> 736 </span><span class="cm"> * IN:</span><sup class="after"></sup>\n' + 
'</span><span class="line-737 line"><span class="lineno"> 737 </span><span class="cm"> * @str		String to be converted.</span><sup class="after"></sup>\n' + 
'</span><span class="line-738 line"><span class="lineno"> 738 </span><span class="cm"> *</span><sup class="after"></sup>\n' + 
'</span><span class="line-739 line"><span class="lineno"> 739 </span><span class="cm"> * OUT:</span><sup class="after"></sup>\n' + 
'</span><span class="line-740 line"><span class="lineno"> 740 </span><span class="cm"> * @str		String in lowercase.</span><sup class="after"></sup>\n' + 
'</span><span class="line-741 line"><span class="lineno"> 741 </span><span class="cm"> *</span><sup class="after"></sup>\n' + 
'</span><span class="line-742 line"><span class="lineno"> 742 </span><span class="cm"> * RETURNS:</span><sup class="after"></sup>\n' + 
'</span><span class="line-743 line"><span class="lineno"> 743 </span><span class="cm"> * String in lowercase.</span><sup class="after"></sup>\n' + 
'</span><span class="line-744 line"><span class="lineno"> 744 </span><span class="cm"> ***************************************************************************</span><sup class="after"></sup>\n' + 
'</span><span class="line-745 line"><span class="lineno"> 745 </span><span class="cm">*/</span><sup class="after"></sup>\n' + 
'</span><span class="line-746 line"><span class="lineno"> 746 </span><span class="kt">char</span> <span class="o">*</span><span class="nf">strtolower</span><span class="p">(</span><span class="kt">char</span> <span class="o">*</span><span class="n">str</span><span class="p">)</span><sup class="after"></sup>\n' + 
'</span><span class="line-747 line"><span class="lineno"> 747 </span><span class="p">{</span><sup class="after"></sup>\n' + 
'</span><span class="line-748 line"><span class="lineno"> 748 </span>	<span class="kt">char</span> <span class="o">*</span><span class="n">cp</span> <span class="o">=</span> <span class="n">str</span><span class="p">;</span><sup class="after"></sup>\n' + 
'</span><span class="line-749 line"><span class="lineno"> 749 </span><sup class="after"></sup>\n' + 
'</span><span class="line-750 line"><span class="lineno"> 750 </span>	<span class="k">while</span> <span class="p">(</span><span class="o">*</span><span class="n">cp</span><span class="p">)</span> <span class="p">{</span><sup class="after"></sup>\n' + 
'</span><span class="line-751 line"><span class="lineno"> 751 </span>		<span class="o">*</span><span class="n">cp</span> <span class="o">=</span> <span class="n">tolower</span><span class="p">(</span><span class="o">*</span><span class="n">cp</span><span class="p">);</span><sup class="after"></sup>\n' + 
'</span><span class="line-752 line"><span class="lineno"> 752 </span>		<span class="n">cp</span><span class="o">++</span><span class="p">;</span><sup class="after"></sup>\n' + 
'</span><span class="line-753 line"><span class="lineno"> 753 </span>	<span class="p">}</span><sup class="after"></sup>\n' + 
'</span><span class="line-754 line"><span class="lineno"> 754 </span><sup class="after"></sup>\n' + 
'</span><span class="line-755 line"><span class="lineno"> 755 </span>	<span class="k">return</span><span class="p">(</span><span class="n">str</span><span class="p">);</span><sup class="after"></sup>\n' + 
'</span><span class="line-756 line"><span class="lineno"> 756 </span><span class="p">}</span><sup class="after"></sup>\n' + 
'</span><span class="line-757 line"><span class="lineno"> 757 </span><sup class="after"></sup>\n' + 
'</span><span class="line-758 line"><span class="lineno"> 758 </span><span class="cm">/*</span><sup class="after"></sup>\n' + 
'</span><span class="line-759 line"><span class="lineno"> 759 </span><span class="cm"> ***************************************************************************</span><sup class="after"></sup>\n' + 
'</span><span class="line-760 line"><span class="lineno"> 760 </span><span class="cm"> * Get persistent type name directory from type.</span><sup class="after"></sup>\n' + 
'</span><span class="line-761 line"><span class="lineno"> 761 </span><span class="cm"> *</span><sup class="after"></sup>\n' + 
'</span><span class="line-762 line"><span class="lineno"> 762 </span><span class="cm"> * IN:</span><sup class="after"></sup>\n' + 
'</span><span class="line-763 line"><span class="lineno"> 763 </span><span class="cm"> * @type	Persistent type name (UUID, LABEL, etc.)</span><sup class="after"></sup>\n' + 
'</span><span class="line-764 line"><span class="lineno"> 764 </span><span class="cm"> *</span><sup class="after"></sup>\n' + 
'</span><span class="line-765 line"><span class="lineno"> 765 </span><span class="cm"> * RETURNS:</span><sup class="after"></sup>\n' + 
'</span><span class="line-766 line"><span class="lineno"> 766 </span><span class="cm"> * Path to the persistent type name directory, or NULL if access is denied.</span><sup class="after"></sup>\n' + 
'</span><span class="line-767 line"><span class="lineno"> 767 </span><span class="cm"> ***************************************************************************</span><sup class="after"></sup>\n' + 
'</span><span class="line-768 line"><span class="lineno"> 768 </span><span class="cm">*/</span><sup class="after"></sup>\n' + 
'</span><span class="line-769 line"><span class="lineno"> 769 </span><span class="kt">char</span> <span class="o">*</span><span class="nf">get_persistent_type_dir</span><span class="p">(</span><span class="kt">char</span> <span class="o">*</span><span class="n">type</span><span class="p">)</span><sup class="after"></sup>\n' + 
'</span><span class="line-770 line"><span class="lineno"> 770 </span><span class="p">{</span><sup class="after"></sup>\n' + 
'</span><span class="line-771 line"><span class="lineno"> 771 </span>	<span class="k">static</span> <span class="kt">char</span> <span class="n">dir</span><span class="p">[</span><span class="mi">32</span><span class="p">];</span><sup class="after"></sup>\n' + 
'</span><span class="line-772 line"><span class="lineno"> 772 </span><sup class="after"></sup>\n' + 
'</span><span class="line-773 line"><span class="lineno"> 773 </span>	<span class="n">snprintf</span><span class="p">(</span><span class="n">dir</span><span class="p">,</span> <span class="mi">32</span><span class="p">,</span> <span class="s">&quot;%s-%s&quot;</span><span class="p">,</span> <span class="n">DEV_DISK_BY</span><span class="p">,</span> <span class="n">type</span><span class="p">);</span><sup class="after"></sup>\n' + 
'</span><span class="line-774 line"><span class="lineno"> 774 </span><sup class="after"></sup>\n' + 
'</span><span class="line-775 line"><span class="lineno"> 775 </span>	<span class="k">if</span> <span class="p">(</span><span class="n">access</span><span class="p">(</span><span class="n">dir</span><span class="p">,</span> <span class="n">R_OK</span><span class="p">))</span> <span class="p">{</span><sup class="after"></sup>\n' + 
'</span><span class="line-776 line"><span class="lineno"> 776 </span>		<span class="k">return</span> <span class="p">(</span><span class="nb">NULL</span><span class="p">);</span><sup class="after"></sup>\n' + 
'</span><span class="line-777 line"><span class="lineno"> 777 </span>	<span class="p">}</span><sup class="after"></sup>\n' + 
'</span><span class="line-778 line"><span class="lineno"> 778 </span><sup class="after"></sup>\n' + 
'</span><span class="line-779 line"><span class="lineno"> 779 </span>	<span class="k">return</span> <span class="p">(</span><span class="n">dir</span><span class="p">);</span><sup class="after"></sup>\n' + 
'</span><span class="line-780 line"><span class="lineno"> 780 </span><span class="p">}</span><sup class="after"></sup>\n' + 
'</span><span class="line-781 line"><span class="lineno"> 781 </span><sup class="after"></sup>\n' + 
'</span><span class="line-782 line"><span class="lineno"> 782 </span><span class="cm">/*</span><sup class="after"></sup>\n' + 
'</span><span class="line-783 line"><span class="lineno"> 783 </span><span class="cm"> ***************************************************************************</span><sup class="after"></sup>\n' + 
'</span><span class="line-784 line"><span class="lineno"> 784 </span><span class="cm"> * Get persistent name absolute path.</span><sup class="after"></sup>\n' + 
'</span><span class="line-785 line"><span class="lineno"> 785 </span><span class="cm"> *</span><sup class="after"></sup>\n' + 
'</span><span class="line-786 line"><span class="lineno"> 786 </span><span class="cm"> * IN:</span><sup class="after"></sup>\n' + 
'</span><span class="line-787 line"><span class="lineno"> 787 </span><span class="cm"> * @name	Persistent name.</span><sup class="after"></sup>\n' + 
'</span><span class="line-788 line"><span class="lineno"> 788 </span><span class="cm"> *</span><sup class="after"></sup>\n' + 
'</span><span class="line-789 line"><span class="lineno"> 789 </span><span class="cm"> * RETURNS:</span><sup class="after"></sup>\n' + 
'</span><span class="line-790 line"><span class="lineno"> 790 </span><span class="cm"> * Path to the persistent name, or NULL if file doesn&#39;t exist.</span><sup class="after"></sup>\n' + 
'</span><span class="line-791 line"><span class="lineno"> 791 </span><span class="cm"> ***************************************************************************</span><sup class="after"></sup>\n' + 
'</span><span class="line-792 line"><span class="lineno"> 792 </span><span class="cm">*/</span><sup class="after"></sup>\n' + 
'</span><span class="line-793 line"><span class="lineno"> 793 </span><span class="kt">char</span> <span class="o">*</span><span class="nf">get_persistent_name_path</span><span class="p">(</span><span class="kt">char</span> <span class="o">*</span><span class="n">name</span><span class="p">)</span><sup class="after"></sup>\n' + 
'</span><span class="line-794 line"><span class="lineno"> 794 </span><span class="p">{</span><sup class="after"></sup>\n' + 
'</span><span class="line-795 line"><span class="lineno"> 795 </span>	<span class="k">static</span> <span class="kt">char</span> <span class="n">path</span><span class="p">[</span><span class="n">PATH_MAX</span><span class="p">];</span><sup class="after"></sup>\n' + 
'</span><span class="line-796 line"><span class="lineno"> 796 </span><sup class="after"></sup>\n' + 
'</span><span class="line-797 line"><span class="lineno"> 797 </span>	<span class="n">snprintf</span><span class="p">(</span><span class="n">path</span><span class="p">,</span> <span class="n">PATH_MAX</span><span class="p">,</span> <span class="s">&quot;%s/%s&quot;</span><span class="p">,</span><sup class="after"></sup>\n' + 
'</span><span class="line-798 line"><span class="lineno"> 798 </span>		 <span class="n">get_persistent_type_dir</span><span class="p">(</span><span class="n">persistent_name_type</span><span class="p">),</span> <span class="n">name</span><span class="p">);</span><sup class="after"></sup>\n' + 
'</span><span class="line-799 line"><span class="lineno"> 799 </span><sup class="after"></sup>\n' + 
'</span><span class="line-800 line"><span class="lineno"> 800 </span>	<span class="k">if</span> <span class="p">(</span><span class="n">access</span><span class="p">(</span><span class="n">path</span><span class="p">,</span> <span class="n">F_OK</span><span class="p">))</span> <span class="p">{</span><sup class="after"></sup>\n' + 
'</span><span class="line-801 line"><span class="lineno"> 801 </span>		<span class="k">return</span> <span class="p">(</span><span class="nb">NULL</span><span class="p">);</span><sup class="after"></sup>\n' + 
'</span><span class="line-802 line"><span class="lineno"> 802 </span>	<span class="p">}</span><sup class="after"></sup>\n' + 
'</span><span class="line-803 line"><span class="lineno"> 803 </span><sup class="after"></sup>\n' + 
'</span><span class="line-804 line"><span class="lineno"> 804 </span>	<span class="k">return</span> <span class="p">(</span><span class="n">path</span><span class="p">);</span><sup class="after"></sup>\n' + 
'</span><span class="line-805 line"><span class="lineno"> 805 </span><span class="p">}</span><sup class="after"></sup>\n' + 
'</span><span class="line-806 line"><span class="lineno"> 806 </span><sup class="after"></sup>\n' + 
'</span><span class="line-807 line"><span class="lineno"> 807 </span><span class="cm">/*</span><sup class="after"></sup>\n' + 
'</span><span class="line-808 line"><span class="lineno"> 808 </span><span class="cm"> ***************************************************************************</span><sup class="after"></sup>\n' + 
'</span><span class="line-809 line"><span class="lineno"> 809 </span><span class="cm"> * Get files from persistent type name directory.</span><sup class="after"></sup>\n' + 
'</span><span class="line-810 line"><span class="lineno"> 810 </span><span class="cm"> *</span><sup class="after"></sup>\n' + 
'</span><span class="line-811 line"><span class="lineno"> 811 </span><span class="cm"> * RETURNS:</span><sup class="after"></sup>\n' + 
'</span><span class="line-812 line"><span class="lineno"> 812 </span><span class="cm"> * List of files in the persistent type name directory in alphabetical order.</span><sup class="after"></sup>\n' + 
'</span><span class="line-813 line"><span class="lineno"> 813 </span><span class="cm"> ***************************************************************************</span><sup class="after"></sup>\n' + 
'</span><span class="line-814 line"><span class="lineno"> 814 </span><span class="cm">*/</span><sup class="after"></sup>\n' + 
'</span><span class="line-815 line"><span class="lineno"> 815 </span><span class="kt">char</span> <span class="o">**</span><span class="nf">get_persistent_names</span><span class="p">(</span><span class="kt">void</span><span class="p">)</span><sup class="after"></sup>\n' + 
'</span><span class="line-816 line"><span class="lineno"> 816 </span><span class="p">{</span><sup class="after"></sup>\n' + 
'</span><span class="line-817 line"><span class="lineno"> 817 </span>	<span class="kt">int</span> <span class="n">n</span><span class="p">,</span> <span class="n">i</span><span class="p">,</span> <span class="n">k</span> <span class="o">=</span> <span class="mi">0</span><span class="p">;</span><sup class="after"></sup>\n' + 
'</span><span class="line-818 line"><span class="lineno"> 818 </span>	<span class="kt">char</span> <span class="o">*</span><span class="n">dir</span><span class="p">;</span><sup class="after"></sup>\n' + 
'</span><span class="line-819 line"><span class="lineno"> 819 </span>	<span class="kt">char</span> <span class="o">**</span><span class="n">files</span> <span class="o">=</span> <span class="nb">NULL</span><span class="p">;</span><sup class="after"></sup>\n' + 
'</span><span class="line-820 line"><span class="lineno"> 820 </span>	<span class="k">struct</span> <span class="n">dirent</span> <span class="o">**</span><span class="n">namelist</span><span class="p">;</span><sup class="after"></sup>\n' + 
'</span><span class="line-821 line"><span class="lineno"> 821 </span><sup class="after"></sup>\n' + 
'</span><span class="line-822 line"><span class="lineno"> 822 </span>	<span class="cm">/* Get directory name for selected persistent type */</span><sup class="after"></sup>\n' + 
'</span><span class="line-823 line"><span class="lineno"> 823 </span>	<span class="n">dir</span> <span class="o">=</span> <span class="n">get_persistent_type_dir</span><span class="p">(</span><span class="n">persistent_name_type</span><span class="p">);</span><sup class="after"></sup>\n' + 
'</span><span class="line-824 line"><span class="lineno"> 824 </span>	<span class="k">if</span> <span class="p">(</span><span class="o">!</span><span class="n">dir</span><span class="p">)</span><sup class="after"></sup>\n' + 
'</span><span class="line-825 line"><span class="lineno"> 825 </span>		<span class="k">return</span> <span class="p">(</span><span class="nb">NULL</span><span class="p">);</span><sup class="after"></sup>\n' + 
'</span><span class="line-826 line"><span class="lineno"> 826 </span><sup class="after"></sup>\n' + 
'</span><span class="line-827 line"><span class="lineno"> 827 </span>	<span class="n">n</span> <span class="o">=</span> <span class="n">scandir</span><span class="p">(</span><span class="n">dir</span><span class="p">,</span> <span class="o">&amp;</span><span class="n">namelist</span><span class="p">,</span> <span class="nb">NULL</span><span class="p">,</span> <span class="n">alphasort</span><span class="p">);</span><sup class="after"></sup>\n' + 
'</span><span class="line-828 line"><span class="lineno"> 828 </span>	<span class="k">if</span> <span class="p">(</span><span class="n">n</span> <span class="o">&lt;</span> <span class="mi">0</span><span class="p">)</span><sup class="after"></sup>\n' + 
'</span><span class="line-829 line"><span class="lineno"> 829 </span>		<span class="k">return</span> <span class="p">(</span><span class="nb">NULL</span><span class="p">);</span><sup class="after"></sup>\n' + 
'</span><span class="line-830 line"><span class="lineno"> 830 </span><sup class="after"></sup>\n' + 
'</span><span class="line-831 line"><span class="lineno"> 831 </span>	<span class="cm">/* If directory is empty, it contains 2 entries: &quot;.&quot; and &quot;..&quot; */</span><sup class="after"></sup>\n' + 
'</span><span class="line-832 line"><span class="lineno"> 832 </span>	<span class="k">if</span> <span class="p">(</span><span class="n">n</span> <span class="o">&lt;=</span> <span class="mi">2</span><span class="p">)</span><sup class="after"></sup>\n' + 
'</span><span class="line-833 line"><span class="lineno"> 833 </span>		<span class="cm">/* Free list and return NULL */</span><sup class="after"></sup>\n' + 
'</span><span class="line-834 line"><span class="lineno"> 834 </span>		<span class="k">goto</span> <span class="n">free_list</span><span class="p">;</span><sup class="after"></sup>\n' + 
'</span><span class="line-835 line"><span class="lineno"> 835 </span><sup class="after"></sup>\n' + 
'</span><span class="line-836 line"><span class="lineno"> 836 </span>	<span class="cm">/* Ignore the &quot;.&quot; and &quot;..&quot;, but keep place for one last NULL. */</span><sup class="after"></sup>\n' + 
'</span><span class="line-837 line"><span class="lineno"> 837 </span>	<span class="n">files</span> <span class="o">=</span> <span class="p">(</span><span class="kt">char</span> <span class="o">**</span><span class="p">)</span> <span class="n">calloc</span><span class="p">(</span><span class="n">n</span> <span class="o">-</span> <span class="mi">1</span><span class="p">,</span> <span class="k">sizeof</span><span class="p">(</span><span class="kt">char</span> <span class="o">*</span><span class="p">));</span><sup class="after"></sup>\n' + 
'</span><span class="line-838 line"><span class="lineno"> 838 </span>	<span class="k">if</span> <span class="p">(</span><span class="o">!</span><span class="n">files</span><span class="p">)</span><sup class="after"></sup>\n' + 
'</span><span class="line-839 line"><span class="lineno"> 839 </span>		<span class="k">goto</span> <span class="n">free_list</span><span class="p">;</span><sup class="after"></sup>\n' + 
'</span><span class="line-840 line"><span class="lineno"> 840 </span><sup class="after"></sup>\n' + 
'</span><span class="line-841 line"><span class="lineno"> 841 </span>	<span class="cm">/*</span><sup class="after"></sup>\n' + 
'</span><span class="line-842 line"><span class="lineno"> 842 </span><span class="cm">	 * i is for traversing namelist, k is for files.</span><sup class="after"></sup>\n' + 
'</span><span class="line-843 line"><span class="lineno"> 843 </span><span class="cm">	 * i != k because we are ignoring &quot;.&quot; and &quot;..&quot; entries.</span><sup class="after"></sup>\n' + 
'</span><span class="line-844 line"><span class="lineno"> 844 </span><span class="cm">	 */</span><sup class="after"></sup>\n' + 
'</span><span class="line-845 line"><span class="lineno"> 845 </span>	<span class="k">for</span> <span class="p">(</span><span class="n">i</span> <span class="o">=</span> <span class="mi">0</span><span class="p">;</span> <span class="n">i</span> <span class="o">&lt;</span> <span class="n">n</span><span class="p">;</span> <span class="n">i</span><span class="o">++</span><span class="p">)</span> <span class="p">{</span><sup class="after"></sup>\n' + 
'</span><span class="line-846 line"><span class="lineno"> 846 </span>		<span class="cm">/* Ignore &quot;.&quot; and &quot;..&quot;. */</span><sup class="after"></sup>\n' + 
'</span><span class="line-847 line"><span class="lineno"> 847 </span>		<span class="k">if</span> <span class="p">(</span><span class="o">!</span><span class="n">strcmp</span><span class="p">(</span><span class="s">&quot;.&quot;</span><span class="p">,</span> <span class="n">namelist</span><span class="p">[</span><span class="n">i</span><span class="p">]</span><span class="o">-&gt;</span><span class="n">d_name</span><span class="p">)</span> <span class="o">||</span><sup class="after"></sup>\n' + 
'</span><span class="line-848 line"><span class="lineno"> 848 </span>		    <span class="o">!</span><span class="n">strcmp</span><span class="p">(</span><span class="s">&quot;..&quot;</span><span class="p">,</span> <span class="n">namelist</span><span class="p">[</span><span class="n">i</span><span class="p">]</span><span class="o">-&gt;</span><span class="n">d_name</span><span class="p">))</span><sup class="after"></sup>\n' + 
'</span><span class="line-849 line"><span class="lineno"> 849 </span>			<span class="k">continue</span><span class="p">;</span><sup class="after"></sup>\n' + 
'</span><span class="line-850 line"><span class="lineno"> 850 </span><sup class="after"></sup>\n' + 
'</span><span class="line-851 line"><span class="lineno"> 851 </span>		<span class="n">files</span><span class="p">[</span><span class="n">k</span><span class="p">]</span> <span class="o">=</span> <span class="p">(</span><span class="kt">char</span> <span class="o">*</span><span class="p">)</span> <span class="n">calloc</span><span class="p">(</span><span class="n">strlen</span><span class="p">(</span><span class="n">namelist</span><span class="p">[</span><span class="n">i</span><span class="p">]</span><span class="o">-&gt;</span><span class="n">d_name</span><span class="p">)</span> <span class="o">+</span> <span class="mi">1</span><span class="p">,</span> <span class="k">sizeof</span><span class="p">(</span><span class="kt">char</span><span class="p">));</span><sup class="after"></sup>\n' + 
'</span><span class="line-852 line"><span class="lineno"> 852 </span>		<span class="k">if</span> <span class="p">(</span><span class="o">!</span><span class="n">files</span><span class="p">[</span><span class="n">k</span><span class="p">])</span><sup class="after"></sup>\n' + 
'</span><span class="line-853 line"><span class="lineno"> 853 </span>			<span class="k">continue</span><span class="p">;</span><sup class="after"></sup>\n' + 
'</span><span class="line-854 line"><span class="lineno"> 854 </span><sup class="after"></sup>\n' + 
'</span><span class="line-855 line"><span class="lineno"> 855 </span>		<span class="n">strcpy</span><span class="p">(</span><span class="n">files</span><span class="p">[</span><span class="n">k</span><span class="o">++</span><span class="p">],</span> <span class="n">namelist</span><span class="p">[</span><span class="n">i</span><span class="p">]</span><span class="o">-&gt;</span><span class="n">d_name</span><span class="p">);</span><sup class="after"></sup>\n' + 
'</span><span class="line-856 line"><span class="lineno"> 856 </span>	<span class="p">}</span><sup class="after"></sup>\n' + 
'</span><span class="line-857 line"><span class="lineno"> 857 </span>	<span class="n">files</span><span class="p">[</span><span class="n">k</span><span class="p">]</span> <span class="o">=</span> <span class="nb">NULL</span><span class="p">;</span><sup class="after"></sup>\n' + 
'</span><span class="line-858 line"><span class="lineno"> 858 </span><sup class="after"></sup>\n' + 
'</span><span class="line-859 line"><span class="lineno"> 859 </span><span class="nl">free_list</span><span class="p">:</span><sup class="after"></sup>\n' + 
'</span><span class="line-860 line"><span class="lineno"> 860 </span><sup class="after"></sup>\n' + 
'</span><span class="line-861 line"><span class="lineno"> 861 </span>	<span class="k">for</span> <span class="p">(</span><span class="n">i</span> <span class="o">=</span> <span class="mi">0</span><span class="p">;</span> <span class="n">i</span> <span class="o">&lt;</span> <span class="n">n</span><span class="p">;</span> <span class="n">i</span><span class="o">++</span><span class="p">)</span> <span class="p">{</span><sup class="after"></sup>\n' + 
'</span><span class="line-862 line"><span class="lineno"> 862 </span>		<span class="n">free</span><span class="p">(</span><span class="n">namelist</span><span class="p">[</span><span class="n">i</span><span class="p">]);</span><sup class="after"></sup>\n' + 
'</span><span class="line-863 line"><span class="lineno"> 863 </span>	<span class="p">}</span><sup class="after"></sup>\n' + 
'</span><span class="line-864 line"><span class="lineno"> 864 </span>	<span class="n">free</span><span class="p">(</span><span class="n">namelist</span><span class="p">);</span><sup class="after"></sup>\n' + 
'</span><span class="line-865 line"><span class="lineno"> 865 </span><sup class="after"></sup>\n' + 
'</span><span class="line-866 line"><span class="lineno"> 866 </span>	<span class="k">return</span> <span class="p">(</span><span class="n">files</span><span class="p">);</span><sup class="after"></sup>\n' + 
'</span><span class="line-867 line"><span class="lineno"> 867 </span><span class="p">}</span><sup class="after"></sup>\n' + 
'</span><span class="line-868 line"><span class="lineno"> 868 </span><sup class="after"></sup>\n' + 
'</span><span class="line-869 line"><span class="lineno"> 869 </span><span class="cm">/*</span><sup class="after"></sup>\n' + 
'</span><span class="line-870 line"><span class="lineno"> 870 </span><span class="cm"> ***************************************************************************</span><sup class="after"></sup>\n' + 
'</span><span class="line-871 line"><span class="lineno"> 871 </span><span class="cm"> * Get persistent name from pretty name.</span><sup class="after"></sup>\n' + 
'</span><span class="line-872 line"><span class="lineno"> 872 </span><span class="cm"> *</span><sup class="after"></sup>\n' + 
'</span><span class="line-873 line"><span class="lineno"> 873 </span><span class="cm"> * IN:</span><sup class="after"></sup>\n' + 
'</span><span class="line-874 line"><span class="lineno"> 874 </span><span class="cm"> * @pretty	Pretty name (e.g. sda, sda1, ..).</span><sup class="after"></sup>\n' + 
'</span><span class="line-875 line"><span class="lineno"> 875 </span><span class="cm"> *</span><sup class="after"></sup>\n' + 
'</span><span class="line-876 line"><span class="lineno"> 876 </span><span class="cm"> * RETURNS:</span><sup class="after"></sup>\n' + 
'</span><span class="line-877 line"><span class="lineno"> 877 </span><span class="cm"> * Persistent name.</span><sup class="after"></sup>\n' + 
'</span><span class="line-878 line"><span class="lineno"> 878 </span><span class="cm"> ***************************************************************************</span><sup class="after"></sup>\n' + 
'</span><span class="line-879 line"><span class="lineno"> 879 </span><span class="cm">*/</span><sup class="after"></sup>\n' + 
'</span><span class="line-880 line"><span class="lineno"> 880 </span><span class="kt">char</span> <span class="o">*</span><span class="nf">get_persistent_name_from_pretty</span><span class="p">(</span><span class="kt">char</span> <span class="o">*</span><span class="n">pretty</span><span class="p">)</span><sup class="after"></sup>\n' + 
'</span><span class="line-881 line"><span class="lineno"> 881 </span><span class="p">{</span><sup class="after"></sup>\n' + 
'</span><span class="line-882 line"><span class="lineno"> 882 </span>	<span class="kt">int</span> <span class="n">i</span> <span class="o">=</span> <span class="o">-</span><span class="mi">1</span><span class="p">;</span><sup class="after"></sup>\n' + 
'</span><span class="line-883 line"><span class="lineno"> 883 </span>	<span class="kt">ssize_t</span> <span class="n">r</span><span class="p">;</span><sup class="after"></sup>\n' + 
'</span><span class="line-884 line"><span class="lineno"> 884 </span>	<span class="kt">char</span> <span class="o">*</span><span class="n">link</span><span class="p">,</span> <span class="o">*</span><span class="n">name</span><span class="p">;</span><sup class="after"></sup>\n' + 
'</span><span class="line-885 line"><span class="lineno"> 885 </span>	<span class="kt">char</span> <span class="o">**</span><span class="n">persist_names</span><span class="p">;</span><sup class="after"></sup>\n' + 
'</span><span class="line-886 line"><span class="lineno"> 886 </span>	<span class="kt">char</span> <span class="n">target</span><span class="p">[</span><span class="n">PATH_MAX</span><span class="p">];</span><sup class="after"></sup>\n' + 
'</span><span class="line-887 line"><span class="lineno"> 887 </span>	<span class="k">static</span> <span class="kt">char</span> <span class="n">persist_name</span><span class="p">[</span><span class="n">FILENAME_MAX</span><span class="p">];</span><sup class="after"></sup>\n' + 
'</span><span class="line-888 line"><span class="lineno"> 888 </span><sup class="after"></sup>\n' + 
'</span><span class="line-889 line"><span class="lineno"> 889 </span>	<span class="n">persist_name</span><span class="p">[</span><span class="mi">0</span><span class="p">]</span> <span class="o">=</span> <span class="sc">&#39;\\0&#39;</span><span class="p">;</span><sup class="after"></sup>\n' + 
'</span><span class="line-890 line"><span class="lineno"> 890 </span><sup class="after"></sup>\n' + 
'</span><span class="line-891 line"><span class="lineno"> 891 </span>	<span class="cm">/* Get list of files from persistent type name directory */</span><sup class="after"></sup>\n' + 
'</span><span class="line-892 line"><span class="lineno"> 892 </span>	<span class="n">persist_names</span> <span class="o">=</span> <span class="n">get_persistent_names</span><span class="p">();</span><sup class="after"></sup>\n' + 
'</span><span class="line-893 line"><span class="lineno"> 893 </span>	<span class="k">if</span> <span class="p">(</span><span class="o">!</span><span class="n">persist_names</span><span class="p">)</span><sup class="after"></sup>\n' + 
'</span><span class="line-894 line"><span class="lineno"> 894 </span>		<span class="k">return</span> <span class="p">(</span><span class="nb">NULL</span><span class="p">);</span><sup class="after"></sup>\n' + 
'</span><span class="line-895 line"><span class="lineno"> 895 </span><sup class="after"></sup>\n' + 
'</span><span class="line-896 line"><span class="lineno"> 896 </span>	<span class="k">while</span> <span class="p">(</span><span class="n">persist_names</span><span class="p">[</span><span class="o">++</span><span class="n">i</span><span class="p">])</span> <span class="p">{</span><sup class="after"></sup>\n' + 
'</span><span class="line-897 line"><span class="lineno"> 897 </span>		<span class="cm">/* Get absolute path for current persistent name */</span><sup class="after"></sup>\n' + 
'</span><span class="line-898 line"><span class="lineno"> 898 </span>		<span class="n">link</span> <span class="o">=</span> <span class="n">get_persistent_name_path</span><span class="p">(</span><span class="n">persist_names</span><span class="p">[</span><span class="n">i</span><span class="p">]);</span><sup class="after"></sup>\n' + 
'</span><span class="line-899 line"><span class="lineno"> 899 </span>		<span class="k">if</span> <span class="p">(</span><span class="o">!</span><span class="n">link</span><span class="p">)</span><sup class="after"></sup>\n' + 
'</span><span class="line-900 line"><span class="lineno"> 900 </span>			<span class="k">continue</span><span class="p">;</span><sup class="after"></sup>\n' + 
'</span><span class="line-901 line"><span class="lineno"> 901 </span><sup class="after"></sup>\n' + 
'</span><span class="line-902 line"><span class="lineno"> 902 </span>		<span class="cm">/* Persistent name is usually a symlink: Read it... */</span><sup class="after"></sup>\n' + 
'</span><span class="line-903 line"><span class="lineno"> 903 </span>		<span class="n">r</span> <span class="o">=</span> <span class="n">readlink</span><span class="p">(</span><span class="n">link</span><span class="p">,</span> <span class="n">target</span><span class="p">,</span> <span class="n">PATH_MAX</span><span class="p">);</span><sup class="after"></sup>\n' + 
'</span><span class="line-904 line"><span class="lineno"> 904 </span>		<span class="k">if</span> <span class="p">((</span><span class="n">r</span> <span class="o">&lt;=</span> <span class="mi">0</span><span class="p">)</span> <span class="o">||</span> <span class="p">(</span><span class="n">r</span> <span class="o">&gt;=</span> <span class="n">PATH_MAX</span><span class="p">))</span><sup class="after"></sup>\n' + 
'</span><span class="line-905 line"><span class="lineno"> 905 </span>			<span class="k">continue</span><span class="p">;</span><sup class="after"></sup>\n' + 
'</span><span class="line-906 line"><span class="lineno"> 906 </span><sup class="after"></sup>\n' + 
'</span><span class="line-907 line"><span class="lineno"> 907 </span>		<span class="n">target</span><span class="p">[</span><span class="n">r</span><span class="p">]</span> <span class="o">=</span> <span class="sc">&#39;\\0&#39;</span><span class="p">;</span><sup class="after"></sup>\n' + 
'</span><span class="line-908 line"><span class="lineno"> 908 </span><sup class="after"></sup>\n' + 
'</span><span class="line-909 line"><span class="lineno"> 909 </span>		<span class="cm">/* ... and get device pretty name it points at */</span><sup class="after"></sup>\n' + 
'</span><span class="line-910 line"><span class="lineno"> 910 </span>		<span class="n">name</span> <span class="o">=</span> <span class="n">basename</span><span class="p">(</span><span class="n">target</span><span class="p">);</span><sup class="after"></sup>\n' + 
'</span><span class="line-911 line"><span class="lineno"> 911 </span>		<span class="k">if</span> <span class="p">(</span><span class="o">!</span><span class="n">name</span> <span class="o">||</span> <span class="p">(</span><span class="n">name</span><span class="p">[</span><span class="mi">0</span><span class="p">]</span> <span class="o">==</span> <span class="sc">&#39;\\0&#39;</span><span class="p">))</span><sup class="after"></sup>\n' + 
'</span><span class="line-912 line"><span class="lineno"> 912 </span>			<span class="k">continue</span><span class="p">;</span><sup class="after"></sup>\n' + 
'</span><span class="line-913 line"><span class="lineno"> 913 </span><sup class="after"></sup>\n' + 
'</span><span class="line-914 line"><span class="lineno"> 914 </span>		<span class="k">if</span> <span class="p">(</span><span class="o">!</span><span class="n">strncmp</span><span class="p">(</span><span class="n">name</span><span class="p">,</span> <span class="n">pretty</span><span class="p">,</span> <span class="n">FILENAME_MAX</span><span class="p">))</span> <span class="p">{</span><sup class="after"></sup>\n' + 
'</span><span class="line-915 line"><span class="lineno"> 915 </span>			<span class="cm">/* We have found pretty name for current persistent one */</span><sup class="after"></sup>\n' + 
'</span><span class="line-916 line"><span class="lineno"> 916 </span>			<span class="n">strncpy</span><span class="p">(</span><span class="n">persist_name</span><span class="p">,</span> <span class="n">persist_names</span><span class="p">[</span><span class="n">i</span><span class="p">],</span> <span class="n">FILENAME_MAX</span><span class="p">);</span><sup class="after"></sup>\n' + 
'</span><span class="line-917 line"><span class="lineno"> 917 </span>			<span class="n">persist_name</span><span class="p">[</span><span class="n">FILENAME_MAX</span> <span class="o">-</span> <span class="mi">1</span><span class="p">]</span> <span class="o">=</span> <span class="sc">&#39;\\0&#39;</span><span class="p">;</span><sup class="after"></sup>\n' + 
'</span><span class="line-918 line"><span class="lineno"> 918 </span>			<span class="k">break</span><span class="p">;</span><sup class="after"></sup>\n' + 
'</span><span class="line-919 line"><span class="lineno"> 919 </span>		<span class="p">}</span><sup class="after"></sup>\n' + 
'</span><span class="line-920 line"><span class="lineno"> 920 </span>	<span class="p">}</span><sup class="after"></sup>\n' + 
'</span><span class="line-921 line"><span class="lineno"> 921 </span><sup class="after"></sup>\n' + 
'</span><span class="line-922 line"><span class="lineno"> 922 </span>	<span class="n">i</span> <span class="o">=</span> <span class="o">-</span><span class="mi">1</span><span class="p">;</span><sup class="after"></sup>\n' + 
'</span><span class="line-923 line"><span class="lineno"> 923 </span>	<span class="k">while</span> <span class="p">(</span><span class="n">persist_names</span><span class="p">[</span><span class="o">++</span><span class="n">i</span><span class="p">])</span> <span class="p">{</span><sup class="after"></sup>\n' + 
'</span><span class="line-924 line"><span class="lineno"> 924 </span>		<span class="n">free</span> <span class="p">(</span><span class="n">persist_names</span><span class="p">[</span><span class="n">i</span><span class="p">]);</span><sup class="after"></sup>\n' + 
'</span><span class="line-925 line"><span class="lineno"> 925 </span>	<span class="p">}</span><sup class="after"></sup>\n' + 
'</span><span class="line-926 line"><span class="lineno"> 926 </span>	<span class="n">free</span> <span class="p">(</span><span class="n">persist_names</span><span class="p">);</span><sup class="after"></sup>\n' + 
'</span><span class="line-927 line"><span class="lineno"> 927 </span><sup class="after"></sup>\n' + 
'</span><span class="line-928 line"><span class="lineno"> 928 </span>	<span class="k">if</span> <span class="p">(</span><span class="n">strlen</span><span class="p">(</span><span class="n">persist_name</span><span class="p">)</span> <span class="o">&lt;=</span> <span class="mi">0</span><span class="p">)</span><sup class="after"></sup>\n' + 
'</span><span class="line-929 line"><span class="lineno"> 929 </span>		<span class="k">return</span> <span class="p">(</span><span class="nb">NULL</span><span class="p">);</span><sup class="after"></sup>\n' + 
'</span><span class="line-930 line"><span class="lineno"> 930 </span><sup class="after"></sup>\n' + 
'</span><span class="line-931 line"><span class="lineno"> 931 </span>	<span class="k">return</span> <span class="n">persist_name</span><span class="p">;</span><sup class="after"></sup>\n' + 
'</span><span class="line-932 line"><span class="lineno"> 932 </span><span class="p">}</span><sup class="after"></sup>\n' + 
'</span><span class="line-933 line"><span class="lineno"> 933 </span><sup class="after"></sup>\n' + 
'</span><span class="line-934 line"><span class="lineno"> 934 </span><span class="cm">/*</span><sup class="after"></sup>\n' + 
'</span><span class="line-935 line"><span class="lineno"> 935 </span><span class="cm"> ***************************************************************************</span><sup class="after"></sup>\n' + 
'</span><span class="line-936 line"><span class="lineno"> 936 </span><span class="cm"> * Get pretty name (sda, sda1...) from persistent name.</span><sup class="after"></sup>\n' + 
'</span><span class="line-937 line"><span class="lineno"> 937 </span><span class="cm"> *</span><sup class="after"></sup>\n' + 
'</span><span class="line-938 line"><span class="lineno"> 938 </span><span class="cm"> * IN:</span><sup class="after"></sup>\n' + 
'</span><span class="line-939 line"><span class="lineno"> 939 </span><span class="cm"> * @persistent	Persistent name.</span><sup class="after"></sup>\n' + 
'</span><span class="line-940 line"><span class="lineno"> 940 </span><span class="cm"> *</span><sup class="after"></sup>\n' + 
'</span><span class="line-941 line"><span class="lineno"> 941 </span><span class="cm"> * RETURNS:</span><sup class="after"></sup>\n' + 
'</span><span class="line-942 line"><span class="lineno"> 942 </span><span class="cm"> * Pretty name.</span><sup class="after"></sup>\n' + 
'</span><span class="line-943 line"><span class="lineno"> 943 </span><span class="cm"> ***************************************************************************</span><sup class="after"></sup>\n' + 
'</span><span class="line-944 line"><span class="lineno"> 944 </span><span class="cm">*/</span><sup class="after"></sup>\n' + 
'</span><span class="line-945 line"><span class="lineno"> 945 </span><span class="kt">char</span> <span class="o">*</span><span class="nf">get_pretty_name_from_persistent</span><span class="p">(</span><span class="kt">char</span> <span class="o">*</span><span class="n">persistent</span><span class="p">)</span><sup class="after"></sup>\n' + 
'</span><span class="line-946 line"><span class="lineno"> 946 </span><span class="p">{</span><sup class="after"></sup>\n' + 
'</span><span class="line-947 line"><span class="lineno"> 947 </span>	<span class="kt">ssize_t</span> <span class="n">r</span><span class="p">;</span><sup class="after"></sup>\n' + 
'</span><span class="line-948 line"><span class="lineno"> 948 </span>	<span class="kt">char</span> <span class="o">*</span><span class="n">link</span><span class="p">,</span> <span class="o">*</span><span class="n">pretty</span><span class="p">,</span> <span class="n">target</span><span class="p">[</span><span class="n">PATH_MAX</span><span class="p">];</span><sup class="after"></sup>\n' + 
'</span><span class="line-949 line"><span class="lineno"> 949 </span><sup class="after"></sup>\n' + 
'</span><span class="line-950 line"><span class="lineno"> 950 </span>	<span class="cm">/* Get absolute path for persistent name */</span><sup class="after"></sup>\n' + 
'</span><span class="line-951 line"><span class="lineno"> 951 </span>	<span class="n">link</span> <span class="o">=</span> <span class="n">get_persistent_name_path</span><span class="p">(</span><span class="n">persistent</span><span class="p">);</span><sup class="after"></sup>\n' + 
'</span><span class="line-952 line"><span class="lineno"> 952 </span>	<span class="k">if</span> <span class="p">(</span><span class="o">!</span><span class="n">link</span><span class="p">)</span><sup class="after"></sup>\n' + 
'</span><span class="line-953 line"><span class="lineno"> 953 </span>		<span class="k">return</span> <span class="p">(</span><span class="nb">NULL</span><span class="p">);</span><sup class="after"></sup>\n' + 
'</span><span class="line-954 line"><span class="lineno"> 954 </span><sup class="after"></sup>\n' + 
'</span><span class="line-955 line"><span class="lineno"> 955 </span>	<span class="cm">/* Persistent name is usually a symlink: Read it... */</span><sup class="after"></sup>\n' + 
'</span><span class="line-956 line"><span class="lineno"> 956 </span>	<span class="n">r</span> <span class="o">=</span> <span class="n">readlink</span><span class="p">(</span><span class="n">link</span><span class="p">,</span> <span class="n">target</span><span class="p">,</span> <span class="n">PATH_MAX</span><span class="p">);</span><sup class="after"></sup>\n' + 
'</span><span class="line-957 line"><span class="lineno"> 957 </span>	<span class="k">if</span> <span class="p">((</span><span class="n">r</span> <span class="o">&lt;=</span> <span class="mi">0</span><span class="p">)</span> <span class="o">||</span> <span class="p">(</span><span class="n">r</span> <span class="o">&gt;=</span> <span class="n">PATH_MAX</span><span class="p">))</span><sup class="after"></sup>\n' + 
'</span><span class="line-958 line"><span class="lineno"> 958 </span>		<span class="k">return</span> <span class="p">(</span><span class="nb">NULL</span><span class="p">);</span><sup class="after"></sup>\n' + 
'</span><span class="line-959 line"><span class="lineno"> 959 </span><sup class="after"></sup>\n' + 
'</span><span class="line-960 line"><span class="lineno"> 960 </span>	<span class="n">target</span><span class="p">[</span><span class="n">r</span><span class="p">]</span> <span class="o">=</span> <span class="sc">&#39;\\0&#39;</span><span class="p">;</span><sup class="after"></sup>\n' + 
'</span><span class="line-961 line"><span class="lineno"> 961 </span><sup class="after"></sup>\n' + 
'</span><span class="line-962 line"><span class="lineno"> 962 </span>	<span class="cm">/* ... and get device pretty name it points at */</span><sup class="after"></sup>\n' + 
'</span><span class="line-963 line"><span class="lineno"> 963 </span>	<span class="n">pretty</span> <span class="o">=</span> <span class="n">basename</span><span class="p">(</span><span class="n">target</span><span class="p">);</span><sup class="after"></sup>\n' + 
'</span><span class="line-964 line"><span class="lineno"> 964 </span>	<span class="k">if</span> <span class="p">(</span><span class="o">!</span><span class="n">pretty</span> <span class="o">||</span> <span class="p">(</span><span class="n">pretty</span><span class="p">[</span><span class="mi">0</span><span class="p">]</span> <span class="o">==</span> <span class="sc">&#39;\\0&#39;</span><span class="p">))</span><sup class="after"></sup>\n' + 
'</span><span class="line-965 line"><span class="lineno"> 965 </span>		<span class="k">return</span> <span class="p">(</span><span class="nb">NULL</span><span class="p">);</span><sup class="after"></sup>\n' + 
'</span><span class="line-966 line"><span class="lineno"> 966 </span><sup class="after"></sup>\n' + 
'</span><span class="line-967 line"><span class="lineno"> 967 </span>	<span class="k">return</span> <span class="n">pretty</span><span class="p">;</span><sup class="after"></sup>\n' + 
'</span><span class="line-968 line"><span class="lineno"> 968 </span><span class="p">}</span><sup class="after"></sup>\n' + 
'</span><span class="line-969 line"><span class="lineno"> 969 </span><sup class="after"></sup>\n' + 
'</span><span class="line-970 line"><span class="lineno"> 970 </span><span class="cm">/*</span><sup class="after"></sup>\n' + 
'</span><span class="line-971 line"><span class="lineno"> 971 </span><span class="cm"> ***************************************************************************</span><sup class="after"></sup>\n' + 
'</span><span class="line-972 line"><span class="lineno"> 972 </span><span class="cm"> * Init color strings.</span><sup class="after"></sup>\n' + 
'</span><span class="line-973 line"><span class="lineno"> 973 </span><span class="cm"> ***************************************************************************</span><sup class="after"></sup>\n' + 
'</span><span class="line-974 line"><span class="lineno"> 974 </span><span class="cm"> */</span><sup class="after"></sup>\n' + 
'</span><span class="line-975 line"><span class="lineno"> 975 </span><span class="kt">void</span> <span class="nf">init_colors</span><span class="p">(</span><span class="kt">void</span><span class="p">)</span><sup class="after"></sup>\n' + 
'</span><span class="line-976 line"><span class="lineno"> 976 </span><span class="p">{</span><sup class="after"></sup>\n' + 
'</span><span class="line-977 line"><span class="lineno"> 977 </span>	<span class="kt">char</span> <span class="o">*</span><span class="n">e</span><span class="p">,</span> <span class="o">*</span><span class="n">p</span><span class="p">;</span><sup class="after"></sup>\n' + 
'</span><span class="line-978 line"><span class="lineno"> 978 </span>	<span class="kt">int</span> <span class="n">len</span><span class="p">;</span><sup class="after"></sup>\n' + 
'</span><span class="line-979 line"><span class="lineno"> 979 </span><sup class="after"></sup>\n' + 
'</span><span class="line-980 line"><span class="lineno"> 980 </span>	<span class="cm">/* Read S_COLORS environment variable */</span><sup class="after"></sup>\n' + 
'</span><span class="line-981 line"><span class="lineno"> 981 </span>	<span class="k">if</span> <span class="p">(((</span><span class="n">e</span> <span class="o">=</span> <span class="n">getenv</span><span class="p">(</span><span class="n">ENV_COLORS</span><span class="p">))</span> <span class="o">==</span> <span class="nb">NULL</span><span class="p">)</span> <span class="o">||</span><sup class="after"></sup>\n' + 
'</span><span class="line-982 line"><span class="lineno"> 982 </span>	    <span class="o">!</span><span class="n">strcmp</span><span class="p">(</span><span class="n">e</span><span class="p">,</span> <span class="n">C_NEVER</span><span class="p">)</span> <span class="o">||</span><sup class="after"></sup>\n' + 
'</span><span class="line-983 line"><span class="lineno"> 983 </span>	    <span class="p">(</span><span class="n">strcmp</span><span class="p">(</span><span class="n">e</span><span class="p">,</span> <span class="n">C_ALWAYS</span><span class="p">)</span> <span class="o">&amp;&amp;</span> <span class="o">!</span><span class="n">isatty</span><span class="p">(</span><span class="n">STDOUT_FILENO</span><span class="p">)))</span> <span class="p">{</span><sup class="after"></sup>\n' + 
'</span><span class="line-984 line"><span class="lineno"> 984 </span>		<span class="cm">/*</span><sup class="after"></sup>\n' + 
'</span><span class="line-985 line"><span class="lineno"> 985 </span><span class="cm">		 * Environment variable not set, or set to &quot;never&quot;,</span><sup class="after"></sup>\n' + 
'</span><span class="line-986 line"><span class="lineno"> 986 </span><span class="cm">		 * or set to &quot;auto&quot; and stdout is not a terminal:</span><sup class="after"></sup>\n' + 
'</span><span class="line-987 line"><span class="lineno"> 987 </span><span class="cm">		 * Unset color strings.</span><sup class="after"></sup>\n' + 
'</span><span class="line-988 line"><span class="lineno"> 988 </span><span class="cm">		 */</span><sup class="after"></sup>\n' + 
'</span><span class="line-989 line"><span class="lineno"> 989 </span>		<span class="n">strcpy</span><span class="p">(</span><span class="n">sc_percent_high</span><span class="p">,</span> <span class="s">&quot;&quot;</span><span class="p">);</span><sup class="after"></sup>\n' + 
'</span><span class="line-990 line"><span class="lineno"> 990 </span>		<span class="n">strcpy</span><span class="p">(</span><span class="n">sc_percent_low</span><span class="p">,</span> <span class="s">&quot;&quot;</span><span class="p">);</span><sup class="after"></sup>\n' + 
'</span><span class="line-991 line"><span class="lineno"> 991 </span>		<span class="n">strcpy</span><span class="p">(</span><span class="n">sc_zero_int_stat</span><span class="p">,</span> <span class="s">&quot;&quot;</span><span class="p">);</span><sup class="after"></sup>\n' + 
'</span><span class="line-992 line"><span class="lineno"> 992 </span>		<span class="n">strcpy</span><span class="p">(</span><span class="n">sc_int_stat</span><span class="p">,</span> <span class="s">&quot;&quot;</span><span class="p">);</span><sup class="after"></sup>\n' + 
'</span><span class="line-993 line"><span class="lineno"> 993 </span>		<span class="n">strcpy</span><span class="p">(</span><span class="n">sc_item_name</span><span class="p">,</span> <span class="s">&quot;&quot;</span><span class="p">);</span><sup class="after"></sup>\n' + 
'</span><span class="line-994 line"><span class="lineno"> 994 </span>		<span class="n">strcpy</span><span class="p">(</span><span class="n">sc_sa_comment</span><span class="p">,</span> <span class="s">&quot;&quot;</span><span class="p">);</span><sup class="after"></sup>\n' + 
'</span><span class="line-995 line"><span class="lineno"> 995 </span>		<span class="n">strcpy</span><span class="p">(</span><span class="n">sc_sa_restart</span><span class="p">,</span> <span class="s">&quot;&quot;</span><span class="p">);</span><sup class="after"></sup>\n' + 
'</span><span class="line-996 line"><span class="lineno"> 996 </span>		<span class="n">strcpy</span><span class="p">(</span><span class="n">sc_normal</span><span class="p">,</span> <span class="s">&quot;&quot;</span><span class="p">);</span><sup class="after"></sup>\n' + 
'</span><span class="line-997 line"><span class="lineno"> 997 </span><sup class="after"></sup>\n' + 
'</span><span class="line-998 line"><span class="lineno"> 998 </span>		<span class="k">return</span><span class="p">;</span><sup class="after"></sup>\n' + 
'</span><span class="line-999 line"><span class="lineno"> 999 </span>	<span class="p">}</span><sup class="after"></sup>\n' + 
'</span><span class="line-1000 line"><span class="lineno">1000 </span><sup class="after"></sup>\n' + 
'</span><span class="line-1001 line"><span class="lineno">1001 </span>	<span class="cm">/* Read S_COLORS_SGR environment variable */</span><sup class="after"></sup>\n' + 
'</span><span class="line-1002 line"><span class="lineno">1002 </span>	<span class="k">if</span> <span class="p">((</span><span class="n">e</span> <span class="o">=</span> <span class="n">getenv</span><span class="p">(</span><span class="n">ENV_COLORS_SGR</span><span class="p">))</span> <span class="o">==</span> <span class="nb">NULL</span><span class="p">)</span><sup class="after"></sup>\n' + 
'</span><span class="line-1003 line"><span class="lineno">1003 </span>		<span class="cm">/* Environment variable not set */</span><sup class="after"></sup>\n' + 
'</span><span class="line-1004 line"><span class="lineno">1004 </span>		<span class="k">return</span><span class="p">;</span><sup class="after"></sup>\n' + 
'</span><span class="line-1005 line"><span class="lineno">1005 </span><sup class="after"></sup>\n' + 
'</span><span class="line-1006 line"><span class="lineno">1006 </span>	<span class="k">for</span> <span class="p">(</span><span class="n">p</span> <span class="o">=</span> <span class="n">strtok</span><span class="p">(</span><span class="n">e</span><span class="p">,</span> <span class="s">&quot;:&quot;</span><span class="p">);</span> <span class="n">p</span><span class="p">;</span> <span class="n">p</span> <span class="o">=</span><span class="n">strtok</span><span class="p">(</span><span class="nb">NULL</span><span class="p">,</span> <span class="s">&quot;:&quot;</span><span class="p">))</span> <span class="p">{</span><sup class="after"></sup>\n' + 
'</span><span class="line-1007 line"><span class="lineno">1007 </span><sup class="after"></sup>\n' + 
'</span><span class="line-1008 line"><span class="lineno">1008 </span>		<span class="n">len</span> <span class="o">=</span> <span class="n">strlen</span><span class="p">(</span><span class="n">p</span><span class="p">);</span><sup class="after"></sup>\n' + 
'</span><span class="line-1009 line"><span class="lineno">1009 </span>		<span class="k">if</span> <span class="p">((</span><span class="n">len</span> <span class="o">&gt;</span> <span class="mi">7</span><span class="p">)</span> <span class="o">||</span> <span class="p">(</span><span class="n">len</span> <span class="o">&lt;</span> <span class="mi">3</span><span class="p">)</span> <span class="o">||</span> <span class="p">(</span><span class="o">*</span><span class="p">(</span><span class="n">p</span> <span class="o">+</span> <span class="mi">1</span><span class="p">)</span> <span class="o">!=</span> <span class="sc">&#39;=&#39;</span><span class="p">)</span> <span class="o">||</span><sup class="after"></sup>\n' + 
'</span><span class="line-1010 line"><span class="lineno">1010 </span>		    <span class="p">(</span><span class="n">strspn</span><span class="p">(</span><span class="n">p</span> <span class="o">+</span> <span class="mi">2</span><span class="p">,</span> <span class="s">&quot;;0123456789&quot;</span><span class="p">)</span> <span class="o">!=</span> <span class="p">(</span><span class="n">len</span> <span class="o">-</span> <span class="mi">2</span><span class="p">)))</span><sup class="after"></sup>\n' + 
'</span><span class="line-1011 line"><span class="lineno">1011 </span>			<span class="cm">/* Ignore malformed codes */</span><sup class="after"></sup>\n' + 
'</span><span class="line-1012 line"><span class="lineno">1012 </span>			<span class="k">continue</span><span class="p">;</span><sup class="after"></sup>\n' + 
'</span><span class="line-1013 line"><span class="lineno">1013 </span><sup class="after"></sup>\n' + 
'</span><span class="line-1014 line"><span class="lineno">1014 </span>		<span class="k">switch</span> <span class="p">(</span><span class="o">*</span><span class="n">p</span><span class="p">)</span> <span class="p">{</span><sup class="after"></sup>\n' + 
'</span><span class="line-1015 line"><span class="lineno">1015 </span>			<span class="k">case</span> <span class="sc">&#39;H&#39;</span><span class="o">:</span><sup class="after"></sup>\n' + 
'</span><span class="line-1016 line"><span class="lineno">1016 </span>				<span class="n">snprintf</span><span class="p">(</span><span class="n">sc_percent_high</span><span class="p">,</span> <span class="n">MAX_SGR_LEN</span><span class="p">,</span> <span class="s">&quot;\\e[%sm&quot;</span><span class="p">,</span> <span class="n">p</span> <span class="o">+</span> <span class="mi">2</span><span class="p">);</span><sup class="after"></sup>\n' + 
'</span><span class="line-1017 line"><span class="lineno">1017 </span>				<span class="k">break</span><span class="p">;</span><sup class="after"></sup>\n' + 
'</span><span class="line-1018 line"><span class="lineno">1018 </span>			<span class="k">case</span> <span class="sc">&#39;M&#39;</span><span class="o">:</span><sup class="after"></sup>\n' + 
'</span><span class="line-1019 line"><span class="lineno">1019 </span>				<span class="n">snprintf</span><span class="p">(</span><span class="n">sc_percent_low</span><span class="p">,</span> <span class="n">MAX_SGR_LEN</span><span class="p">,</span> <span class="s">&quot;\\e[%sm&quot;</span><span class="p">,</span> <span class="n">p</span> <span class="o">+</span> <span class="mi">2</span><span class="p">);</span><sup class="after"></sup>\n' + 
'</span><span class="line-1020 line"><span class="lineno">1020 </span>				<span class="k">break</span><span class="p">;</span><sup class="after"></sup>\n' + 
'</span><span class="line-1021 line"><span class="lineno">1021 </span>			<span class="k">case</span> <span class="sc">&#39;Z&#39;</span><span class="o">:</span><sup class="after"></sup>\n' + 
'</span><span class="line-1022 line"><span class="lineno">1022 </span>				<span class="n">snprintf</span><span class="p">(</span><span class="n">sc_zero_int_stat</span><span class="p">,</span> <span class="n">MAX_SGR_LEN</span><span class="p">,</span> <span class="s">&quot;\\e[%sm&quot;</span><span class="p">,</span> <span class="n">p</span> <span class="o">+</span> <span class="mi">2</span><span class="p">);</span><sup class="after"></sup>\n' + 
'</span><span class="line-1023 line"><span class="lineno">1023 </span>				<span class="k">break</span><span class="p">;</span><sup class="after"></sup>\n' + 
'</span><span class="line-1024 line"><span class="lineno">1024 </span>			<span class="k">case</span> <span class="sc">&#39;N&#39;</span><span class="o">:</span><sup class="after"></sup>\n' + 
'</span><span class="line-1025 line"><span class="lineno">1025 </span>				<span class="n">snprintf</span><span class="p">(</span><span class="n">sc_int_stat</span><span class="p">,</span> <span class="n">MAX_SGR_LEN</span><span class="p">,</span> <span class="s">&quot;\\e[%sm&quot;</span><span class="p">,</span> <span class="n">p</span> <span class="o">+</span> <span class="mi">2</span><span class="p">);</span><sup class="after"></sup>\n' + 
'</span><span class="line-1026 line"><span class="lineno">1026 </span>				<span class="k">break</span><span class="p">;</span><sup class="after"></sup>\n' + 
'</span><span class="line-1027 line"><span class="lineno">1027 </span>			<span class="k">case</span> <span class="sc">&#39;I&#39;</span><span class="o">:</span><sup class="after"></sup>\n' + 
'</span><span class="line-1028 line"><span class="lineno">1028 </span>				<span class="n">snprintf</span><span class="p">(</span><span class="n">sc_item_name</span><span class="p">,</span> <span class="n">MAX_SGR_LEN</span><span class="p">,</span> <span class="s">&quot;\\e[%sm&quot;</span><span class="p">,</span> <span class="n">p</span> <span class="o">+</span> <span class="mi">2</span><span class="p">);</span><sup class="after"></sup>\n' + 
'</span><span class="line-1029 line"><span class="lineno">1029 </span>				<span class="k">break</span><span class="p">;</span><sup class="after"></sup>\n' + 
'</span><span class="line-1030 line"><span class="lineno">1030 </span>			<span class="k">case</span> <span class="sc">&#39;C&#39;</span><span class="o">:</span><sup class="after"></sup>\n' + 
'</span><span class="line-1031 line"><span class="lineno">1031 </span>				<span class="n">snprintf</span><span class="p">(</span><span class="n">sc_sa_comment</span><span class="p">,</span> <span class="n">MAX_SGR_LEN</span><span class="p">,</span> <span class="s">&quot;\\e[%sm&quot;</span><span class="p">,</span> <span class="n">p</span> <span class="o">+</span> <span class="mi">2</span><span class="p">);</span><sup class="after"></sup>\n' + 
'</span><span class="line-1032 line"><span class="lineno">1032 </span>				<span class="k">break</span><span class="p">;</span><sup class="after"></sup>\n' + 
'</span><span class="line-1033 line"><span class="lineno">1033 </span>			<span class="k">case</span> <span class="sc">&#39;R&#39;</span><span class="o">:</span><sup class="after"></sup>\n' + 
'</span><span class="line-1034 line"><span class="lineno">1034 </span>				<span class="n">snprintf</span><span class="p">(</span><span class="n">sc_sa_restart</span><span class="p">,</span> <span class="n">MAX_SGR_LEN</span><span class="p">,</span> <span class="s">&quot;\\e[%sm&quot;</span><span class="p">,</span> <span class="n">p</span> <span class="o">+</span> <span class="mi">2</span><span class="p">);</span><sup class="after"></sup>\n' + 
'</span><span class="line-1035 line"><span class="lineno">1035 </span>				<span class="k">break</span><span class="p">;</span><sup class="after"></sup>\n' + 
'</span><span class="line-1036 line"><span class="lineno">1036 </span>		<span class="p">}</span><sup class="after"></sup>\n' + 
'</span><span class="line-1037 line"><span class="lineno">1037 </span>	<span class="p">}</span><sup class="after"></sup>\n' + 
'</span><span class="line-1038 line"><span class="lineno">1038 </span><span class="p">}</span><sup class="after"></sup>\n' + 
'</span><span class="line-1039 line"><span class="lineno">1039 </span><sup class="after"></sup>\n' + 
'</span><span class="line-1040 line"><span class="lineno">1040 </span><span class="cm">/*</span><sup class="after"></sup>\n' + 
'</span><span class="line-1041 line"><span class="lineno">1041 </span><span class="cm"> ***************************************************************************</span><sup class="after"></sup>\n' + 
'</span><span class="line-1042 line"><span class="lineno">1042 </span><span class="cm"> * Print a value in human readable format. Such a value is a decimal number</span><sup class="after"></sup>\n' + 
'</span><span class="line-1043 line"><span class="lineno">1043 </span><span class="cm"> * followed by a unit (B, k, M, etc.)</span><sup class="after"></sup>\n' + 
'</span><span class="line-1044 line"><span class="lineno">1044 </span><span class="cm"> *</span><sup class="after"></sup>\n' + 
'</span><span class="line-1045 line"><span class="lineno">1045 </span><span class="cm"> * IN:</span><sup class="after"></sup>\n' + 
'</span><span class="line-1046 line"><span class="lineno">1046 </span><span class="cm"> * @unit	Default value unit.</span><sup class="after"></sup>\n' + 
'</span><span class="line-1047 line"><span class="lineno">1047 </span><span class="cm"> * @dval	Value to print.</span><sup class="after"></sup>\n' + 
'</span><span class="line-1048 line"><span class="lineno">1048 </span><span class="cm"> * @wi		Output width.</span><sup class="after"></sup>\n' + 
'</span><span class="line-1049 line"><span class="lineno">1049 </span><span class="cm"> ***************************************************************************</span><sup class="after"></sup>\n' + 
'</span><span class="line-1050 line"><span class="lineno">1050 </span><span class="cm">*/</span><sup class="after"></sup>\n' + 
'</span><span class="line-1051 line"><span class="lineno">1051 </span><span class="kt">void</span> <span class="nf">cprintf_unit</span><span class="p">(</span><span class="kt">int</span> <span class="n">unit</span><span class="p">,</span> <span class="kt">int</span> <span class="n">wi</span><span class="p">,</span> <span class="kt">double</span> <span class="n">dval</span><span class="p">)</span><sup class="after"></sup>\n' + 
'</span><span class="line-1052 line"><span class="lineno">1052 </span><span class="p">{</span><sup class="after"></sup>\n' + 
'</span><span class="line-1053 line"><span class="lineno">1053 </span>	<span class="k">if</span> <span class="p">(</span><span class="n">wi</span> <span class="o">&lt;</span> <span class="mi">4</span><span class="p">)</span> <span class="p">{</span><sup class="after"></sup>\n' + 
'</span><span class="line-1054 line"><span class="lineno">1054 </span>		<span class="cm">/* E.g. 1.3M */</span><sup class="after"></sup>\n' + 
'</span><span class="line-1055 line"><span class="lineno">1055 </span>		<span class="n">wi</span> <span class="o">=</span> <span class="mi">4</span><span class="p">;</span><sup class="after"></sup>\n' + 
'</span><span class="line-1056 line"><span class="lineno">1056 </span>	<span class="p">}</span><sup class="after"></sup>\n' + 
'</span><span class="line-1057 line"><span class="lineno">1057 </span>	<span class="k">if</span> <span class="p">(</span><span class="o">!</span><span class="n">unit</span><span class="p">)</span> <span class="p">{</span><sup class="after"></sup>\n' + 
'</span><span class="line-1058 line"><span class="lineno">1058 </span>		<span class="cm">/* Value is a number of sectors. Convert it to kB */</span><sup class="after"></sup>\n' + 
'</span><span class="line-1059 line"><span class="lineno">1059 </span>		<span class="n">dval</span> <span class="o">/=</span> <span class="mi">2</span><span class="p">;</span><sup class="after"></sup>\n' + 
'</span><span class="line-1060 line"><span class="lineno">1060 </span>		<span class="n">unit</span> <span class="o">=</span> <span class="mi">2</span><span class="p">;</span><sup class="after"></sup>\n' + 
'</span><span class="line-1061 line"><span class="lineno">1061 </span>	<span class="p">}</span><sup class="after"></sup>\n' + 
'</span><span class="line-1062 line"><span class="lineno">1062 </span>	<span class="k">while</span> <span class="p">(</span><span class="n">dval</span> <span class="o">&gt;=</span> <span class="mi">1024</span><span class="p">)</span> <span class="p">{</span><sup class="after"></sup>\n' + 
'</span><span class="line-1063 line"><span class="lineno">1063 </span>		<span class="n">dval</span> <span class="o">/=</span> <span class="mi">1024</span><span class="p">;</span><sup class="after"></sup>\n' + 
'</span><span class="line-1064 line"><span class="lineno">1064 </span>		<span class="n">unit</span><span class="o">++</span><span class="p">;</span><sup class="after"></sup>\n' + 
'</span><span class="line-1065 line"><span class="lineno">1065 </span>	<span class="p">}</span><sup class="after"></sup>\n' + 
'</span><span class="line-1066 line"><span class="lineno">1066 </span>	<span class="n">printf</span><span class="p">(</span><span class="s">&quot; %*.*f&quot;</span><span class="p">,</span> <span class="n">wi</span> <span class="o">-</span> <span class="mi">1</span><span class="p">,</span> <span class="n">dplaces_nr</span> <span class="o">?</span> <span class="mi">1</span> <span class="o">:</span> <span class="mi">0</span><span class="p">,</span> <span class="n">dval</span><span class="p">);</span><sup class="after"></sup>\n' + 
'</span><span class="line-1067 line"><span class="lineno">1067 </span>	<span class="n">printf</span><span class="p">(</span><span class="s">&quot;%s&quot;</span><span class="p">,</span> <span class="n">sc_normal</span><span class="p">);</span><sup class="after"></sup>\n' + 
'</span><span class="line-1068 line"><span class="lineno">1068 </span><sup class="after"></sup>\n' + 
'</span><span class="line-1069 line"><span class="lineno">1069 </span>	<span class="cm">/* Display unit */</span><sup class="after"></sup>\n' + 
'</span><span class="line-1070 line"><span class="lineno">1070 </span>	<span class="k">if</span> <span class="p">(</span><span class="n">unit</span> <span class="o">&gt;=</span> <span class="n">NR_UNITS</span><span class="p">)</span> <span class="p">{</span><sup class="after"></sup>\n' + 
'</span><span class="line-1071 line"><span class="lineno">1071 </span>		<span class="n">unit</span> <span class="o">=</span> <span class="n">NR_UNITS</span> <span class="o">-</span> <span class="mi">1</span><span class="p">;</span><sup class="after"></sup>\n' + 
'</span><span class="line-1072 line"><span class="lineno">1072 </span>	<span class="p">}</span><sup class="after"></sup>\n' + 
'</span><span class="line-1073 line"><span class="lineno">1073 </span>	<span class="n">printf</span><span class="p">(</span><span class="s">&quot;%c&quot;</span><span class="p">,</span> <span class="n">units</span><span class="p">[</span><span class="n">unit</span><span class="p">]);</span><sup class="after"></sup>\n' + 
'</span><span class="line-1074 line"><span class="lineno">1074 </span><span class="p">}</span><sup class="after"></sup>\n' + 
'</span><span class="line-1075 line"><span class="lineno">1075 </span><sup class="after"></sup>\n' + 
'</span><span class="line-1076 line"><span class="lineno">1076 </span><span class="cm">/*</span><sup class="after"></sup>\n' + 
'</span><span class="line-1077 line"><span class="lineno">1077 </span><span class="cm"> ***************************************************************************</span><sup class="after"></sup>\n' + 
'</span><span class="line-1078 line"><span class="lineno">1078 </span><span class="cm"> * Print 64 bit unsigned values using colors, possibly followed by a unit.</span><sup class="after"></sup>\n' + 
'</span><span class="line-1079 line"><span class="lineno">1079 </span><span class="cm"> *</span><sup class="after"></sup>\n' + 
'</span><span class="line-1080 line"><span class="lineno">1080 </span><span class="cm"> * IN:</span><sup class="after"></sup>\n' + 
'</span><span class="line-1081 line"><span class="lineno">1081 </span><span class="cm"> * @unit	Default values unit. -1 if no unit should be displayed.</span><sup class="after"></sup>\n' + 
'</span><span class="line-1082 line"><span class="lineno">1082 </span><span class="cm"> * @num		Number of values to print.</span><sup class="after"></sup>\n' + 
'</span><span class="line-1083 line"><span class="lineno">1083 </span><span class="cm"> * @wi		Output width.</span><sup class="after"></sup>\n' + 
'</span><span class="line-1084 line"><span class="lineno">1084 </span><span class="cm"> ***************************************************************************</span><sup class="after"></sup>\n' + 
'</span><span class="line-1085 line"><span class="lineno">1085 </span><span class="cm">*/</span><sup class="after"></sup>\n' + 
'</span><span class="line-1086 line"><span class="lineno">1086 </span><span class="kt">void</span> <span class="nf">cprintf_u64</span><span class="p">(</span><span class="kt">int</span> <span class="n">unit</span><span class="p">,</span> <span class="kt">int</span> <span class="n">num</span><span class="p">,</span> <span class="kt">int</span> <span class="n">wi</span><span class="p">,</span> <span class="p">...)</span><sup class="after"></sup>\n' + 
'</span><span class="line-1087 line"><span class="lineno">1087 </span><span class="p">{</span><sup class="after"></sup>\n' + 
'</span><span class="line-1088 line"><span class="lineno">1088 </span>	<span class="kt">int</span> <span class="n">i</span><span class="p">;</span><sup class="after"></sup>\n' + 
'</span><span class="line-1089 line"><span class="lineno">1089 </span>	<span class="kt">uint64_t</span> <span class="n">val</span><span class="p">;</span><sup class="after"></sup>\n' + 
'</span><span class="line-1090 line"><span class="lineno">1090 </span>	<span class="kt">va_list</span> <span class="n">args</span><span class="p">;</span><sup class="after"></sup>\n' + 
'</span><span class="line-1091 line"><span class="lineno">1091 </span><sup class="after"></sup>\n' + 
'</span><span class="line-1092 line"><span class="lineno">1092 </span>	<span class="n">va_start</span><span class="p">(</span><span class="n">args</span><span class="p">,</span> <span class="n">wi</span><span class="p">);</span><sup class="after"></sup>\n' + 
'</span><span class="line-1093 line"><span class="lineno">1093 </span><sup class="after"></sup>\n' + 
'</span><span class="line-1094 line"><span class="lineno">1094 </span>	<span class="k">for</span> <span class="p">(</span><span class="n">i</span> <span class="o">=</span> <span class="mi">0</span><span class="p">;</span> <span class="n">i</span> <span class="o">&lt;</span> <span class="n">num</span><span class="p">;</span> <span class="n">i</span><span class="o">++</span><span class="p">)</span> <span class="p">{</span><sup class="after"></sup>\n' + 
'</span><span class="line-1095 line"><span class="lineno">1095 </span>		<span class="n">val</span> <span class="o">=</span> <span class="n">va_arg</span><span class="p">(</span><span class="n">args</span><span class="p">,</span> <span class="kt">unsigned</span> <span class="kt">long</span> <span class="kt">long</span><span class="p">);</span><sup class="after"></sup>\n' + 
'</span><span class="line-1096 line"><span class="lineno">1096 </span>		<span class="k">if</span> <span class="p">(</span><span class="o">!</span><span class="n">val</span><span class="p">)</span> <span class="p">{</span><sup class="after"></sup>\n' + 
'</span><span class="line-1097 line"><span class="lineno">1097 </span>			<span class="n">printf</span><span class="p">(</span><span class="s">&quot;%s&quot;</span><span class="p">,</span> <span class="n">sc_zero_int_stat</span><span class="p">);</span><sup class="after"></sup>\n' + 
'</span><span class="line-1098 line"><span class="lineno">1098 </span>		<span class="p">}</span><sup class="after"></sup>\n' + 
'</span><span class="line-1099 line"><span class="lineno">1099 </span>		<span class="k">else</span> <span class="p">{</span><sup class="after"></sup>\n' + 
'</span><span class="line-1100 line"><span class="lineno">1100 </span>			<span class="n">printf</span><span class="p">(</span><span class="s">&quot;%s&quot;</span><span class="p">,</span> <span class="n">sc_int_stat</span><span class="p">);</span><sup class="after"></sup>\n' + 
'</span><span class="line-1101 line"><span class="lineno">1101 </span>		<span class="p">}</span><sup class="after"></sup>\n' + 
'</span><span class="line-1102 line"><span class="lineno">1102 </span>		<span class="k">if</span> <span class="p">(</span><span class="n">unit</span> <span class="o">&lt;</span> <span class="mi">0</span><span class="p">)</span> <span class="p">{</span><sup class="after"></sup>\n' + 
'</span><span class="line-1103 line"><span class="lineno">1103 </span>			<span class="n">printf</span><span class="p">(</span><span class="s">&quot; %*&quot;</span><span class="n">PRIu64</span><span class="p">,</span> <span class="n">wi</span><span class="p">,</span> <span class="n">val</span><span class="p">);</span><sup class="after"></sup>\n' + 
'</span><span class="line-1104 line"><span class="lineno">1104 </span>			<span class="n">printf</span><span class="p">(</span><span class="s">&quot;%s&quot;</span><span class="p">,</span> <span class="n">sc_normal</span><span class="p">);</span><sup class="after"></sup>\n' + 
'</span><span class="line-1105 line"><span class="lineno">1105 </span>		<span class="p">}</span><sup class="after"></sup>\n' + 
'</span><span class="line-1106 line"><span class="lineno">1106 </span>		<span class="k">else</span> <span class="p">{</span><sup class="after"></sup>\n' + 
'</span><span class="line-1107 line"><span class="lineno">1107 </span>			<span class="n">cprintf_unit</span><span class="p">(</span><span class="n">unit</span><span class="p">,</span> <span class="n">wi</span><span class="p">,</span> <span class="p">(</span><span class="kt">double</span><span class="p">)</span> <span class="n">val</span><span class="p">);</span><sup class="after"></sup>\n' + 
'</span><span class="line-1108 line"><span class="lineno">1108 </span>		<span class="p">}</span><sup class="after"></sup>\n' + 
'</span><span class="line-1109 line"><span class="lineno">1109 </span>	<span class="p">}</span><sup class="after"></sup>\n' + 
'</span><span class="line-1110 line"><span class="lineno">1110 </span><sup class="after"></sup>\n' + 
'</span><span class="line-1111 line"><span class="lineno">1111 </span>	<span class="n">va_end</span><span class="p">(</span><span class="n">args</span><span class="p">);</span><sup class="after"></sup>\n' + 
'</span><span class="line-1112 line"><span class="lineno">1112 </span><span class="p">}</span><sup class="after"></sup>\n' + 
'</span><span class="line-1113 line"><span class="lineno">1113 </span><sup class="after"></sup>\n' + 
'</span><span class="line-1114 line"><span class="lineno">1114 </span><span class="cm">/*</span><sup class="after"></sup>\n' + 
'</span><span class="line-1115 line"><span class="lineno">1115 </span><span class="cm"> ***************************************************************************</span><sup class="after"></sup>\n' + 
'</span><span class="line-1116 line"><span class="lineno">1116 </span><span class="cm"> * Print hex values using colors.</span><sup class="after"></sup>\n' + 
'</span><span class="line-1117 line"><span class="lineno">1117 </span><span class="cm"> *</span><sup class="after"></sup>\n' + 
'</span><span class="line-1118 line"><span class="lineno">1118 </span><span class="cm"> * IN:</span><sup class="after"></sup>\n' + 
'</span><span class="line-1119 line"><span class="lineno">1119 </span><span class="cm"> * @num		Number of values to print.</span><sup class="after"></sup>\n' + 
'</span><span class="line-1120 line"><span class="lineno">1120 </span><span class="cm"> * @wi		Output width.</span><sup class="after"></sup>\n' + 
'</span><span class="line-1121 line"><span class="lineno">1121 </span><span class="cm"> ***************************************************************************</span><sup class="after"></sup>\n' + 
'</span><span class="line-1122 line"><span class="lineno">1122 </span><span class="cm">*/</span><sup class="after"></sup>\n' + 
'</span><span class="line-1123 line"><span class="lineno">1123 </span><span class="kt">void</span> <span class="nf">cprintf_x</span><span class="p">(</span><span class="kt">int</span> <span class="n">num</span><span class="p">,</span> <span class="kt">int</span> <span class="n">wi</span><span class="p">,</span> <span class="p">...)</span><sup class="after"></sup>\n' + 
'</span><span class="line-1124 line"><span class="lineno">1124 </span><span class="p">{</span><sup class="after"></sup>\n' + 
'</span><span class="line-1125 line"><span class="lineno">1125 </span>	<span class="kt">int</span> <span class="n">i</span><span class="p">;</span><sup class="after"></sup>\n' + 
'</span><span class="line-1126 line"><span class="lineno">1126 </span>	<span class="kt">unsigned</span> <span class="kt">int</span> <span class="n">val</span><span class="p">;</span><sup class="after"></sup>\n' + 
'</span><span class="line-1127 line"><span class="lineno">1127 </span>	<span class="kt">va_list</span> <span class="n">args</span><span class="p">;</span><sup class="after"></sup>\n' + 
'</span><span class="line-1128 line"><span class="lineno">1128 </span><sup class="after"></sup>\n' + 
'</span><span class="line-1129 line"><span class="lineno">1129 </span>	<span class="n">va_start</span><span class="p">(</span><span class="n">args</span><span class="p">,</span> <span class="n">wi</span><span class="p">);</span><sup class="after"></sup>\n' + 
'</span><span class="line-1130 line"><span class="lineno">1130 </span><sup class="after"></sup>\n' + 
'</span><span class="line-1131 line"><span class="lineno">1131 </span>	<span class="k">for</span> <span class="p">(</span><span class="n">i</span> <span class="o">=</span> <span class="mi">0</span><span class="p">;</span> <span class="n">i</span> <span class="o">&lt;</span> <span class="n">num</span><span class="p">;</span> <span class="n">i</span><span class="o">++</span><span class="p">)</span> <span class="p">{</span><sup class="after"></sup>\n' + 
'</span><span class="line-1132 line"><span class="lineno">1132 </span>		<span class="n">val</span> <span class="o">=</span> <span class="n">va_arg</span><span class="p">(</span><span class="n">args</span><span class="p">,</span> <span class="kt">unsigned</span> <span class="kt">int</span><span class="p">);</span><sup class="after"></sup>\n' + 
'</span><span class="line-1133 line"><span class="lineno">1133 </span>		<span class="n">printf</span><span class="p">(</span><span class="s">&quot;%s&quot;</span><span class="p">,</span> <span class="n">sc_int_stat</span><span class="p">);</span><sup class="after"></sup>\n' + 
'</span><span class="line-1134 line"><span class="lineno">1134 </span>		<span class="n">printf</span><span class="p">(</span><span class="s">&quot; %*x&quot;</span><span class="p">,</span> <span class="n">wi</span><span class="p">,</span> <span class="n">val</span><span class="p">);</span><sup class="after"></sup>\n' + 
'</span><span class="line-1135 line"><span class="lineno">1135 </span>		<span class="n">printf</span><span class="p">(</span><span class="s">&quot;%s&quot;</span><span class="p">,</span> <span class="n">sc_normal</span><span class="p">);</span><sup class="after"></sup>\n' + 
'</span><span class="line-1136 line"><span class="lineno">1136 </span>	<span class="p">}</span><sup class="after"></sup>\n' + 
'</span><span class="line-1137 line"><span class="lineno">1137 </span><sup class="after"></sup>\n' + 
'</span><span class="line-1138 line"><span class="lineno">1138 </span>	<span class="n">va_end</span><span class="p">(</span><span class="n">args</span><span class="p">);</span><sup class="after"></sup>\n' + 
'</span><span class="line-1139 line"><span class="lineno">1139 </span><span class="p">}</span><sup class="after"></sup>\n' + 
'</span><span class="line-1140 line"><span class="lineno">1140 </span><sup class="after"></sup>\n' + 
'</span><span class="line-1141 line"><span class="lineno">1141 </span><span class="cm">/*</span><sup class="after"></sup>\n' + 
'</span><span class="line-1142 line"><span class="lineno">1142 </span><span class="cm"> ***************************************************************************</span><sup class="after"></sup>\n' + 
'</span><span class="line-1143 line"><span class="lineno">1143 </span><span class="cm"> * Print &quot;double&quot; statistics values using colors, possibly followed by a</span><sup class="after"></sup>\n' + 
'</span><span class="line-1144 line"><span class="lineno">1144 </span><span class="cm"> * unit.</span><sup class="after"></sup>\n' + 
'</span><span class="line-1145 line"><span class="lineno">1145 </span><span class="cm"> *</span><sup class="after"></sup>\n' + 
'</span><span class="line-1146 line"><span class="lineno">1146 </span><span class="cm"> * IN:</span><sup class="after"></sup>\n' + 
'</span><span class="line-1147 line"><span class="lineno">1147 </span><span class="cm"> * @unit	Default values unit. -1 if no unit should be displayed.</span><sup class="after"></sup>\n' + 
'</span><span class="line-1148 line"><span class="lineno">1148 </span><span class="cm"> * @num		Number of values to print.</span><sup class="after"></sup>\n' + 
'</span><span class="line-1149 line"><span class="lineno">1149 </span><span class="cm"> * @wi		Output width.</span><sup class="after"></sup>\n' + 
'</span><span class="line-1150 line"><span class="lineno">1150 </span><span class="cm"> * @wd		Number of decimal places.</span><sup class="after"></sup>\n' + 
'</span><span class="line-1151 line"><span class="lineno">1151 </span><span class="cm"> ***************************************************************************</span><sup class="after"></sup>\n' + 
'</span><span class="line-1152 line"><span class="lineno">1152 </span><span class="cm">*/</span><sup class="after"></sup>\n' + 
'</span><span class="line-1153 line"><span class="lineno">1153 </span><span class="kt">void</span> <span class="nf">cprintf_f</span><span class="p">(</span><span class="kt">int</span> <span class="n">unit</span><span class="p">,</span> <span class="kt">int</span> <span class="n">num</span><span class="p">,</span> <span class="kt">int</span> <span class="n">wi</span><span class="p">,</span> <span class="kt">int</span> <span class="n">wd</span><span class="p">,</span> <span class="p">...)</span><sup class="after"></sup>\n' + 
'</span><span class="line-1154 line"><span class="lineno">1154 </span><span class="p">{</span><sup class="after"></sup>\n' + 
'</span><span class="line-1155 line"><span class="lineno">1155 </span>	<span class="kt">int</span> <span class="n">i</span><span class="p">;</span><sup class="after"></sup>\n' + 
'</span><span class="line-1156 line"><span class="lineno">1156 </span>	<span class="kt">double</span> <span class="n">val</span><span class="p">,</span> <span class="n">lim</span> <span class="o">=</span> <span class="mf">0.005</span><span class="p">;;</span><sup class="after"></sup>\n' + 
'</span><span class="line-1157 line"><span class="lineno">1157 </span>	<span class="kt">va_list</span> <span class="n">args</span><span class="p">;</span><sup class="after"></sup>\n' + 
'</span><span class="line-1158 line"><span class="lineno">1158 </span><sup class="after"></sup>\n' + 
'</span><span class="line-1159 line"><span class="lineno">1159 </span>	<span class="cm">/*</span><sup class="after"></sup>\n' + 
'</span><span class="line-1160 line"><span class="lineno">1160 </span><span class="cm">	 * If there are decimal places then get the value</span><sup class="after"></sup>\n' + 
'</span><span class="line-1161 line"><span class="lineno">1161 </span><span class="cm">	 * entered on the command line (if existing).</span><sup class="after"></sup>\n' + 
'</span><span class="line-1162 line"><span class="lineno">1162 </span><span class="cm">	 */</span><sup class="after"></sup>\n' + 
'</span><span class="line-1163 line"><span class="lineno">1163 </span>	<span class="k">if</span> <span class="p">((</span><span class="n">wd</span> <span class="o">&gt;</span> <span class="mi">0</span><span class="p">)</span> <span class="o">&amp;&amp;</span> <span class="p">(</span><span class="n">dplaces_nr</span> <span class="o">&gt;=</span> <span class="mi">0</span><span class="p">))</span> <span class="p">{</span><sup class="after"></sup>\n' + 
'</span><span class="line-1164 line"><span class="lineno">1164 </span>		<span class="n">wd</span> <span class="o">=</span> <span class="n">dplaces_nr</span><span class="p">;</span><sup class="after"></sup>\n' + 
'</span><span class="line-1165 line"><span class="lineno">1165 </span>	<span class="p">}</span><sup class="after"></sup>\n' + 
'</span><span class="line-1166 line"><span class="lineno">1166 </span><sup class="after"></sup>\n' + 
'</span><span class="line-1167 line"><span class="lineno">1167 </span>	<span class="cm">/* Update limit value according to number of decimal places */</span><sup class="after"></sup>\n' + 
'</span><span class="line-1168 line"><span class="lineno">1168 </span>	<span class="k">if</span> <span class="p">(</span><span class="n">wd</span> <span class="o">==</span> <span class="mi">1</span><span class="p">)</span> <span class="p">{</span><sup class="after"></sup>\n' + 
'</span><span class="line-1169 line"><span class="lineno">1169 </span>		<span class="n">lim</span> <span class="o">=</span> <span class="mf">0.05</span><span class="p">;</span><sup class="after"></sup>\n' + 
'</span><span class="line-1170 line"><span class="lineno">1170 </span>	<span class="p">}</span><sup class="after"></sup>\n' + 
'</span><span class="line-1171 line"><span class="lineno">1171 </span><sup class="after"></sup>\n' + 
'</span><span class="line-1172 line"><span class="lineno">1172 </span>	<span class="n">va_start</span><span class="p">(</span><span class="n">args</span><span class="p">,</span> <span class="n">wd</span><span class="p">);</span><sup class="after"></sup>\n' + 
'</span><span class="line-1173 line"><span class="lineno">1173 </span><sup class="after"></sup>\n' + 
'</span><span class="line-1174 line"><span class="lineno">1174 </span>	<span class="k">for</span> <span class="p">(</span><span class="n">i</span> <span class="o">=</span> <span class="mi">0</span><span class="p">;</span> <span class="n">i</span> <span class="o">&lt;</span> <span class="n">num</span><span class="p">;</span> <span class="n">i</span><span class="o">++</span><span class="p">)</span> <span class="p">{</span><sup class="after"></sup>\n' + 
'</span><span class="line-1175 line"><span class="lineno">1175 </span>		<span class="n">val</span> <span class="o">=</span> <span class="n">va_arg</span><span class="p">(</span><span class="n">args</span><span class="p">,</span> <span class="kt">double</span><span class="p">);</span><sup class="after"></sup>\n' + 
'</span><span class="line-1176 line"><span class="lineno">1176 </span>		<span class="k">if</span> <span class="p">(((</span><span class="n">wd</span> <span class="o">&gt;</span> <span class="mi">0</span><span class="p">)</span> <span class="o">&amp;&amp;</span> <span class="p">(</span><span class="n">val</span> <span class="o">&lt;</span> <span class="n">lim</span><span class="p">)</span> <span class="o">&amp;&amp;</span> <span class="p">(</span><span class="n">val</span> <span class="o">&gt;</span> <span class="p">(</span><span class="n">lim</span> <span class="o">*</span> <span class="o">-</span><span class="mi">1</span><span class="p">)))</span> <span class="o">||</span><sup class="after"></sup>\n' + 
'</span><span class="line-1177 line"><span class="lineno">1177 </span>		    <span class="p">((</span><span class="n">wd</span> <span class="o">==</span> <span class="mi">0</span><span class="p">)</span> <span class="o">&amp;&amp;</span> <span class="p">(</span><span class="n">val</span> <span class="o">&lt;=</span> <span class="mf">0.5</span><span class="p">)</span> <span class="o">&amp;&amp;</span> <span class="p">(</span><span class="n">val</span> <span class="o">&gt;=</span> <span class="o">-</span><span class="mf">0.5</span><span class="p">)))</span> <span class="p">{</span>	<span class="cm">/* &quot;Round half to even&quot; law */</span><sup class="after"></sup>\n' + 
'</span><span class="line-1178 line"><span class="lineno">1178 </span>			<span class="n">printf</span><span class="p">(</span><span class="s">&quot;%s&quot;</span><span class="p">,</span> <span class="n">sc_zero_int_stat</span><span class="p">);</span><sup class="after"></sup>\n' + 
'</span><span class="line-1179 line"><span class="lineno">1179 </span>		<span class="p">}</span><sup class="after"></sup>\n' + 
'</span><span class="line-1180 line"><span class="lineno">1180 </span>		<span class="k">else</span> <span class="p">{</span><sup class="after"></sup>\n' + 
'</span><span class="line-1181 line"><span class="lineno">1181 </span>			<span class="n">printf</span><span class="p">(</span><span class="s">&quot;%s&quot;</span><span class="p">,</span> <span class="n">sc_int_stat</span><span class="p">);</span><sup class="after"></sup>\n' + 
'</span><span class="line-1182 line"><span class="lineno">1182 </span>		<span class="p">}</span><sup class="after"></sup>\n' + 
'</span><span class="line-1183 line"><span class="lineno">1183 </span><sup class="after"></sup>\n' + 
'</span><span class="line-1184 line"><span class="lineno">1184 </span>		<span class="k">if</span> <span class="p">(</span><span class="n">unit</span> <span class="o">&lt;</span> <span class="mi">0</span><span class="p">)</span> <span class="p">{</span><sup class="after"></sup>\n' + 
'</span><span class="line-1185 line"><span class="lineno">1185 </span>			<span class="n">printf</span><span class="p">(</span><span class="s">&quot; %*.*f&quot;</span><span class="p">,</span> <span class="n">wi</span><span class="p">,</span> <span class="n">wd</span><span class="p">,</span> <span class="n">val</span><span class="p">);</span><sup class="after"></sup>\n' + 
'</span><span class="line-1186 line"><span class="lineno">1186 </span>			<span class="n">printf</span><span class="p">(</span><span class="s">&quot;%s&quot;</span><span class="p">,</span> <span class="n">sc_normal</span><span class="p">);</span><sup class="after"></sup>\n' + 
'</span><span class="line-1187 line"><span class="lineno">1187 </span>		<span class="p">}</span><sup class="after"></sup>\n' + 
'</span><span class="line-1188 line"><span class="lineno">1188 </span>		<span class="k">else</span> <span class="p">{</span><sup class="after"></sup>\n' + 
'</span><span class="line-1189 line"><span class="lineno">1189 </span>			<span class="n">cprintf_unit</span><span class="p">(</span><span class="n">unit</span><span class="p">,</span> <span class="n">wi</span><span class="p">,</span> <span class="n">val</span><span class="p">);</span><sup class="after"></sup>\n' + 
'</span><span class="line-1190 line"><span class="lineno">1190 </span>		<span class="p">}</span><sup class="after"></sup>\n' + 
'</span><span class="line-1191 line"><span class="lineno">1191 </span>	<span class="p">}</span><sup class="after"></sup>\n' + 
'</span><span class="line-1192 line"><span class="lineno">1192 </span><sup class="after"></sup>\n' + 
'</span><span class="line-1193 line"><span class="lineno">1193 </span>	<span class="n">va_end</span><span class="p">(</span><span class="n">args</span><span class="p">);</span><sup class="after"></sup>\n' + 
'</span><span class="line-1194 line"><span class="lineno">1194 </span><span class="p">}</span><sup class="after"></sup>\n' + 
'</span><span class="line-1195 line"><span class="lineno">1195 </span><sup class="after"></sup>\n' + 
'</span><span class="line-1196 line"><span class="lineno">1196 </span><span class="cm">/*</span><sup class="after"></sup>\n' + 
'</span><span class="line-1197 line"><span class="lineno">1197 </span><span class="cm"> ***************************************************************************</span><sup class="after"></sup>\n' + 
'</span><span class="line-1198 line"><span class="lineno">1198 </span><span class="cm"> * Print &quot;percent&quot; statistics values using colors.</span><sup class="after"></sup>\n' + 
'</span><span class="line-1199 line"><span class="lineno">1199 </span><span class="cm"> *</span><sup class="after"></sup>\n' + 
'</span><span class="line-1200 line"><span class="lineno">1200 </span><span class="cm"> * IN:</span><sup class="after"></sup>\n' + 
'</span><span class="line-1201 line"><span class="lineno">1201 </span><span class="cm"> * @human	Set to &gt; 0 if a percent sign (%) shall be displayed after</span><sup class="after"></sup>\n' + 
'</span><span class="line-1202 line"><span class="lineno">1202 </span><span class="cm"> *		the value.</span><sup class="after"></sup>\n' + 
'</span><span class="line-1203 line"><span class="lineno">1203 </span><span class="cm"> * @num		Number of values to print.</span><sup class="after"></sup>\n' + 
'</span><span class="line-1204 line"><span class="lineno">1204 </span><span class="cm"> * @wi		Output width.</span><sup class="after"></sup>\n' + 
'</span><span class="line-1205 line"><span class="lineno">1205 </span><span class="cm"> * @wd		Number of decimal places.</span><sup class="after"></sup>\n' + 
'</span><span class="line-1206 line"><span class="lineno">1206 </span><span class="cm"> ***************************************************************************</span><sup class="after"></sup>\n' + 
'</span><span class="line-1207 line"><span class="lineno">1207 </span><span class="cm">*/</span><sup class="after"></sup>\n' + 
'</span><span class="line-1208 line"><span class="lineno">1208 </span><span class="kt">void</span> <span class="nf">cprintf_pc</span><span class="p">(</span><span class="kt">int</span> <span class="n">human</span><span class="p">,</span> <span class="kt">int</span> <span class="n">num</span><span class="p">,</span> <span class="kt">int</span> <span class="n">wi</span><span class="p">,</span> <span class="kt">int</span> <span class="n">wd</span><span class="p">,</span> <span class="p">...)</span><sup class="after"></sup>\n' + 
'</span><span class="line-1209 line"><span class="lineno">1209 </span><span class="p">{</span><sup class="after"></sup>\n' + 
'</span><span class="line-1210 line"><span class="lineno">1210 </span>	<span class="kt">int</span> <span class="n">i</span><span class="p">;</span><sup class="after"></sup>\n' + 
'</span><span class="line-1211 line"><span class="lineno">1211 </span>	<span class="kt">double</span> <span class="n">val</span><span class="p">,</span> <span class="n">lim</span> <span class="o">=</span> <span class="mf">0.005</span><span class="p">;</span><sup class="after"></sup>\n' + 
'</span><span class="line-1212 line"><span class="lineno">1212 </span>	<span class="kt">va_list</span> <span class="n">args</span><span class="p">;</span><sup class="after"></sup>\n' + 
'</span><span class="line-1213 line"><span class="lineno">1213 </span><sup class="after"></sup>\n' + 
'</span><span class="line-1214 line"><span class="lineno">1214 </span>	<span class="cm">/*</span><sup class="after"></sup>\n' + 
'</span><span class="line-1215 line"><span class="lineno">1215 </span><span class="cm">	 * If there are decimal places then get the value</span><sup class="after"></sup>\n' + 
'</span><span class="line-1216 line"><span class="lineno">1216 </span><span class="cm">	 * entered on the command line (if existing).</span><sup class="after"></sup>\n' + 
'</span><span class="line-1217 line"><span class="lineno">1217 </span><span class="cm">	 */</span><sup class="after"></sup>\n' + 
'</span><span class="line-1218 line"><span class="lineno">1218 </span>	<span class="k">if</span> <span class="p">((</span><span class="n">wd</span> <span class="o">&gt;</span> <span class="mi">0</span><span class="p">)</span> <span class="o">&amp;&amp;</span> <span class="p">(</span><span class="n">dplaces_nr</span> <span class="o">&gt;=</span> <span class="mi">0</span><span class="p">))</span> <span class="p">{</span><sup class="after"></sup>\n' + 
'</span><span class="line-1219 line"><span class="lineno">1219 </span>		<span class="n">wd</span> <span class="o">=</span> <span class="n">dplaces_nr</span><span class="p">;</span><sup class="after"></sup>\n' + 
'</span><span class="line-1220 line"><span class="lineno">1220 </span>	<span class="p">}</span><sup class="after"></sup>\n' + 
'</span><span class="line-1221 line"><span class="lineno">1221 </span><sup class="after"></sup>\n' + 
'</span><span class="line-1222 line"><span class="lineno">1222 </span>	<span class="cm">/*</span><sup class="after"></sup>\n' + 
'</span><span class="line-1223 line"><span class="lineno">1223 </span><span class="cm">	 * If a percent sign is to be displayed, then there will be</span><sup class="after"></sup>\n' + 
'</span><span class="line-1224 line"><span class="lineno">1224 </span><span class="cm">	 * zero (or one) decimal place.</span><sup class="after"></sup>\n' + 
'</span><span class="line-1225 line"><span class="lineno">1225 </span><span class="cm">	 */</span><sup class="after"></sup>\n' + 
'</span><span class="line-1226 line"><span class="lineno">1226 </span>	<span class="k">if</span> <span class="p">(</span><span class="n">human</span> <span class="o">&gt;</span> <span class="mi">0</span><span class="p">)</span> <span class="p">{</span><sup class="after"></sup>\n' + 
'</span><span class="line-1227 line"><span class="lineno">1227 </span>		<span class="k">if</span> <span class="p">(</span><span class="n">wi</span> <span class="o">&lt;</span> <span class="mi">4</span><span class="p">)</span> <span class="p">{</span><sup class="after"></sup>\n' + 
'</span><span class="line-1228 line"><span class="lineno">1228 </span>			<span class="cm">/* E.g., 100% */</span><sup class="after"></sup>\n' + 
'</span><span class="line-1229 line"><span class="lineno">1229 </span>			<span class="n">wi</span> <span class="o">=</span> <span class="mi">4</span><span class="p">;</span><sup class="after"></sup>\n' + 
'</span><span class="line-1230 line"><span class="lineno">1230 </span>		<span class="p">}</span><sup class="after"></sup>\n' + 
'</span><span class="line-1231 line"><span class="lineno">1231 </span>		<span class="cm">/* Keep one place for the percent sign */</span><sup class="after"></sup>\n' + 
'</span><span class="line-1232 line"><span class="lineno">1232 </span>		<span class="n">wi</span> <span class="o">-=</span> <span class="mi">1</span><span class="p">;</span><sup class="after"></sup>\n' + 
'</span><span class="line-1233 line"><span class="lineno">1233 </span>		<span class="k">if</span> <span class="p">(</span><span class="n">wd</span> <span class="o">&gt;</span> <span class="mi">1</span><span class="p">)</span> <span class="p">{</span><sup class="after"></sup>\n' + 
'</span><span class="line-1234 line"><span class="lineno">1234 </span>			<span class="n">wd</span> <span class="o">-=</span> <span class="mi">1</span><span class="p">;</span><sup class="after"></sup>\n' + 
'</span><span class="line-1235 line"><span class="lineno">1235 </span>		<span class="p">}</span><sup class="after"></sup>\n' + 
'</span><span class="line-1236 line"><span class="lineno">1236 </span>	<span class="p">}</span><sup class="after"></sup>\n' + 
'</span><span class="line-1237 line"><span class="lineno">1237 </span><sup class="after"></sup>\n' + 
'</span><span class="line-1238 line"><span class="lineno">1238 </span>	<span class="cm">/* Update limit value according to number of decimal places */</span><sup class="after"></sup>\n' + 
'</span><span class="line-1239 line"><span class="lineno">1239 </span>	<span class="k">if</span> <span class="p">(</span><span class="n">wd</span> <span class="o">==</span> <span class="mi">1</span><span class="p">)</span> <span class="p">{</span><sup class="after"></sup>\n' + 
'</span><span class="line-1240 line"><span class="lineno">1240 </span>		<span class="n">lim</span> <span class="o">=</span> <span class="mf">0.05</span><span class="p">;</span><sup class="after"></sup>\n' + 
'</span><span class="line-1241 line"><span class="lineno">1241 </span>	<span class="p">}</span><sup class="after"></sup>\n' + 
'</span><span class="line-1242 line"><span class="lineno">1242 </span><sup class="after"></sup>\n' + 
'</span><span class="line-1243 line"><span class="lineno">1243 </span>	<span class="n">va_start</span><span class="p">(</span><span class="n">args</span><span class="p">,</span> <span class="n">wd</span><span class="p">);</span><sup class="after"></sup>\n' + 
'</span><span class="line-1244 line"><span class="lineno">1244 </span><sup class="after"></sup>\n' + 
'</span><span class="line-1245 line"><span class="lineno">1245 </span>	<span class="k">for</span> <span class="p">(</span><span class="n">i</span> <span class="o">=</span> <span class="mi">0</span><span class="p">;</span> <span class="n">i</span> <span class="o">&lt;</span> <span class="n">num</span><span class="p">;</span> <span class="n">i</span><span class="o">++</span><span class="p">)</span> <span class="p">{</span><sup class="after"></sup>\n' + 
'</span><span class="line-1246 line"><span class="lineno">1246 </span>		<span class="n">val</span> <span class="o">=</span> <span class="n">va_arg</span><span class="p">(</span><span class="n">args</span><span class="p">,</span> <span class="kt">double</span><span class="p">);</span><sup class="after"></sup>\n' + 
'</span><span class="line-1247 line"><span class="lineno">1247 </span>		<span class="k">if</span> <span class="p">(</span><span class="n">val</span> <span class="o">&gt;=</span> <span class="n">PERCENT_LIMIT_HIGH</span><span class="p">)</span> <span class="p">{</span><sup class="after"></sup>\n' + 
'</span><span class="line-1248 line"><span class="lineno">1248 </span>			<span class="n">printf</span><span class="p">(</span><span class="s">&quot;%s&quot;</span><span class="p">,</span> <span class="n">sc_percent_high</span><span class="p">);</span><sup class="after"></sup>\n' + 
'</span><span class="line-1249 line"><span class="lineno">1249 </span>		<span class="p">}</span><sup class="after"></sup>\n' + 
'</span><span class="line-1250 line"><span class="lineno">1250 </span>		<span class="k">else</span> <span class="k">if</span> <span class="p">(</span><span class="n">val</span> <span class="o">&gt;=</span> <span class="n">PERCENT_LIMIT_LOW</span><span class="p">)</span> <span class="p">{</span><sup class="after"></sup>\n' + 
'</span><span class="line-1251 line"><span class="lineno">1251 </span>			<span class="n">printf</span><span class="p">(</span><span class="s">&quot;%s&quot;</span><span class="p">,</span> <span class="n">sc_percent_low</span><span class="p">);</span><sup class="after"></sup>\n' + 
'</span><span class="line-1252 line"><span class="lineno">1252 </span>		<span class="p">}</span><sup class="after"></sup>\n' + 
'</span><span class="line-1253 line"><span class="lineno">1253 </span>		<span class="k">else</span> <span class="k">if</span> <span class="p">(((</span><span class="n">wd</span> <span class="o">&gt;</span> <span class="mi">0</span><span class="p">)</span> <span class="o">&amp;&amp;</span> <span class="p">(</span><span class="n">val</span> <span class="o">&lt;</span> <span class="n">lim</span><span class="p">))</span> <span class="o">||</span><sup class="after"></sup>\n' + 
'</span><span class="line-1254 line"><span class="lineno">1254 </span>			 <span class="p">((</span><span class="n">wd</span> <span class="o">==</span> <span class="mi">0</span><span class="p">)</span> <span class="o">&amp;&amp;</span> <span class="p">(</span><span class="n">val</span> <span class="o">&lt;=</span> <span class="mf">0.5</span><span class="p">)))</span> <span class="p">{</span>	<span class="cm">/* &quot;Round half to even&quot; law */</span><sup class="after"></sup>\n' + 
'</span><span class="line-1255 line"><span class="lineno">1255 </span>			<span class="n">printf</span><span class="p">(</span><span class="s">&quot;%s&quot;</span><span class="p">,</span> <span class="n">sc_zero_int_stat</span><span class="p">);</span><sup class="after"></sup>\n' + 
'</span><span class="line-1256 line"><span class="lineno">1256 </span>		<span class="p">}</span><sup class="after"></sup>\n' + 
'</span><span class="line-1257 line"><span class="lineno">1257 </span>		<span class="k">else</span> <span class="p">{</span><sup class="after"></sup>\n' + 
'</span><span class="line-1258 line"><span class="lineno">1258 </span>			<span class="n">printf</span><span class="p">(</span><span class="s">&quot;%s&quot;</span><span class="p">,</span> <span class="n">sc_int_stat</span><span class="p">);</span><sup class="after"></sup>\n' + 
'</span><span class="line-1259 line"><span class="lineno">1259 </span>		<span class="p">}</span><sup class="after"></sup>\n' + 
'</span><span class="line-1260 line"><span class="lineno">1260 </span>		<span class="n">printf</span><span class="p">(</span><span class="s">&quot; %*.*f&quot;</span><span class="p">,</span> <span class="n">wi</span><span class="p">,</span> <span class="n">wd</span><span class="p">,</span> <span class="n">val</span><span class="p">);</span><sup class="after"></sup>\n' + 
'</span><span class="line-1261 line"><span class="lineno">1261 </span>		<span class="n">printf</span><span class="p">(</span><span class="s">&quot;%s&quot;</span><span class="p">,</span> <span class="n">sc_normal</span><span class="p">);</span><sup class="after"></sup>\n' + 
'</span><span class="line-1262 line"><span class="lineno">1262 </span>		<span class="k">if</span> <span class="p">(</span><span class="n">human</span> <span class="o">&gt;</span> <span class="mi">0</span><span class="p">)</span> <span class="n">printf</span><span class="p">(</span><span class="s">&quot;%%&quot;</span><span class="p">);</span><sup class="after"></sup>\n' + 
'</span><span class="line-1263 line"><span class="lineno">1263 </span>	<span class="p">}</span><sup class="after"></sup>\n' + 
'</span><span class="line-1264 line"><span class="lineno">1264 </span><sup class="after"></sup>\n' + 
'</span><span class="line-1265 line"><span class="lineno">1265 </span>	<span class="n">va_end</span><span class="p">(</span><span class="n">args</span><span class="p">);</span><sup class="after"></sup>\n' + 
'</span><span class="line-1266 line"><span class="lineno">1266 </span><span class="p">}</span><sup class="after"></sup>\n' + 
'</span><span class="line-1267 line"><span class="lineno">1267 </span><sup class="after"></sup>\n' + 
'</span><span class="line-1268 line"><span class="lineno">1268 </span><span class="cm">/*</span><sup class="after"></sup>\n' + 
'</span><span class="line-1269 line"><span class="lineno">1269 </span><span class="cm"> ***************************************************************************</span><sup class="after"></sup>\n' + 
'</span><span class="line-1270 line"><span class="lineno">1270 </span><span class="cm"> * Print item name using selected color.</span><sup class="after"></sup>\n' + 
'</span><span class="line-1271 line"><span class="lineno">1271 </span><span class="cm"> * Only one name can be displayed. Name can be an integer or a string.</span><sup class="after"></sup>\n' + 
'</span><span class="line-1272 line"><span class="lineno">1272 </span><span class="cm"> *</span><sup class="after"></sup>\n' + 
'</span><span class="line-1273 line"><span class="lineno">1273 </span><span class="cm"> * IN:</span><sup class="after"></sup>\n' + 
'</span><span class="line-1274 line"><span class="lineno">1274 </span><span class="cm"> * @type	0 if name is an int, 1 if name is a string</span><sup class="after"></sup>\n' + 
'</span><span class="line-1275 line"><span class="lineno">1275 </span><span class="cm"> * @format	Output format.</span><sup class="after"></sup>\n' + 
'</span><span class="line-1276 line"><span class="lineno">1276 </span><span class="cm"> * @item_string	Item name (given as a string of characters).</span><sup class="after"></sup>\n' + 
'</span><span class="line-1277 line"><span class="lineno">1277 </span><span class="cm"> * @item_int	Item name (given as an integer value).</span><sup class="after"></sup>\n' + 
'</span><span class="line-1278 line"><span class="lineno">1278 </span><span class="cm"> ***************************************************************************</span><sup class="after"></sup>\n' + 
'</span><span class="line-1279 line"><span class="lineno">1279 </span><span class="cm">*/</span><sup class="after"></sup>\n' + 
'</span><span class="line-1280 line"><span class="lineno">1280 </span><span class="kt">void</span> <span class="nf">cprintf_in</span><span class="p">(</span><span class="kt">int</span> <span class="n">type</span><span class="p">,</span> <span class="kt">char</span> <span class="o">*</span><span class="n">format</span><span class="p">,</span> <span class="kt">char</span> <span class="o">*</span><span class="n">item_string</span><span class="p">,</span> <span class="kt">int</span> <span class="n">item_int</span><span class="p">)</span><sup class="after"></sup>\n' + 
'</span><span class="line-1281 line"><span class="lineno">1281 </span><span class="p">{</span><sup class="after"></sup>\n' + 
'</span><span class="line-1282 line"><span class="lineno">1282 </span>	<span class="n">printf</span><span class="p">(</span><span class="s">&quot;%s&quot;</span><span class="p">,</span> <span class="n">sc_item_name</span><span class="p">);</span><sup class="after"></sup>\n' + 
'</span><span class="line-1283 line"><span class="lineno">1283 </span>	<span class="k">if</span> <span class="p">(</span><span class="n">type</span><span class="p">)</span> <span class="p">{</span><sup class="after"></sup>\n' + 
'</span><span class="line-1284 line"><span class="lineno">1284 </span>		<span class="n">printf</span><span class="p">(</span><span class="n">format</span><span class="p">,</span> <span class="n">item_string</span><span class="p">);</span><sup class="after"></sup>\n' + 
'</span><span class="line-1285 line"><span class="lineno">1285 </span>	<span class="p">}</span><sup class="after"></sup>\n' + 
'</span><span class="line-1286 line"><span class="lineno">1286 </span>	<span class="k">else</span> <span class="p">{</span><sup class="after"></sup>\n' + 
'</span><span class="line-1287 line"><span class="lineno">1287 </span>		<span class="n">printf</span><span class="p">(</span><span class="n">format</span><span class="p">,</span> <span class="n">item_int</span><span class="p">);</span><sup class="after"></sup>\n' + 
'</span><span class="line-1288 line"><span class="lineno">1288 </span>	<span class="p">}</span><sup class="after"></sup>\n' + 
'</span><span class="line-1289 line"><span class="lineno">1289 </span>	<span class="n">printf</span><span class="p">(</span><span class="s">&quot;%s&quot;</span><span class="p">,</span> <span class="n">sc_normal</span><span class="p">);</span><sup class="after"></sup>\n' + 
'</span><span class="line-1290 line"><span class="lineno">1290 </span><span class="p">}</span><sup class="after"></sup>\n' + 
'</span><span class="line-1291 line"><span class="lineno">1291 </span><sup class="after"></sup>\n' + 
'</span><span class="line-1292 line"><span class="lineno">1292 </span><span class="cm">/*</span><sup class="after"></sup>\n' + 
'</span><span class="line-1293 line"><span class="lineno">1293 </span><span class="cm"> ***************************************************************************</span><sup class="after"></sup>\n' + 
'</span><span class="line-1294 line"><span class="lineno">1294 </span><span class="cm"> * Print a string using selected color.</span><sup class="after"></sup>\n' + 
'</span><span class="line-1295 line"><span class="lineno">1295 </span><span class="cm"> *</span><sup class="after"></sup>\n' + 
'</span><span class="line-1296 line"><span class="lineno">1296 </span><span class="cm"> * IN:</span><sup class="after"></sup>\n' + 
'</span><span class="line-1297 line"><span class="lineno">1297 </span><span class="cm"> * @type	Type of string to display.</span><sup class="after"></sup>\n' + 
'</span><span class="line-1298 line"><span class="lineno">1298 </span><span class="cm"> * @format	Output format.</span><sup class="after"></sup>\n' + 
'</span><span class="line-1299 line"><span class="lineno">1299 </span><span class="cm"> * @string	String to display.</span><sup class="after"></sup>\n' + 
'</span><span class="line-1300 line"><span class="lineno">1300 </span><span class="cm"> ***************************************************************************</span><sup class="after"></sup>\n' + 
'</span><span class="line-1301 line"><span class="lineno">1301 </span><span class="cm">*/</span><sup class="after"></sup>\n' + 
'</span><span class="line-1302 line"><span class="lineno">1302 </span><span class="kt">void</span> <span class="nf">cprintf_s</span><span class="p">(</span><span class="kt">int</span> <span class="n">type</span><span class="p">,</span> <span class="kt">char</span> <span class="o">*</span><span class="n">format</span><span class="p">,</span> <span class="kt">char</span> <span class="o">*</span><span class="n">string</span><span class="p">)</span><sup class="after"></sup>\n' + 
'</span><span class="line-1303 line"><span class="lineno">1303 </span><span class="p">{</span><sup class="after"></sup>\n' + 
'</span><span class="line-1304 line"><span class="lineno">1304 </span>	<span class="k">if</span> <span class="p">(</span><span class="n">type</span> <span class="o">==</span> <span class="n">IS_STR</span><span class="p">)</span> <span class="p">{</span><sup class="after"></sup>\n' + 
'</span><span class="line-1305 line"><span class="lineno">1305 </span>		<span class="n">printf</span><span class="p">(</span><span class="s">&quot;%s&quot;</span><span class="p">,</span> <span class="n">sc_int_stat</span><span class="p">);</span><sup class="after"></sup>\n' + 
'</span><span class="line-1306 line"><span class="lineno">1306 </span>	<span class="p">}</span><sup class="after"></sup>\n' + 
'</span><span class="line-1307 line"><span class="lineno">1307 </span>	<span class="k">else</span> <span class="k">if</span> <span class="p">(</span><span class="n">type</span> <span class="o">==</span> <span class="n">IS_ZERO</span><span class="p">)</span> <span class="p">{</span><sup class="after"></sup>\n' + 
'</span><span class="line-1308 line"><span class="lineno">1308 </span>		<span class="n">printf</span><span class="p">(</span><span class="s">&quot;%s&quot;</span><span class="p">,</span> <span class="n">sc_zero_int_stat</span><span class="p">);</span><sup class="after"></sup>\n' + 
'</span><span class="line-1309 line"><span class="lineno">1309 </span>	<span class="p">}</span><sup class="after"></sup>\n' + 
'</span><span class="line-1310 line"><span class="lineno">1310 </span>	<span class="k">else</span> <span class="k">if</span> <span class="p">(</span><span class="n">type</span> <span class="o">==</span> <span class="n">IS_RESTART</span><span class="p">)</span> <span class="p">{</span><sup class="after"></sup>\n' + 
'</span><span class="line-1311 line"><span class="lineno">1311 </span>		<span class="n">printf</span><span class="p">(</span><span class="s">&quot;%s&quot;</span><span class="p">,</span> <span class="n">sc_sa_restart</span><span class="p">);</span><sup class="after"></sup>\n' + 
'</span><span class="line-1312 line"><span class="lineno">1312 </span>	<span class="p">}</span><sup class="after"></sup>\n' + 
'</span><span class="line-1313 line"><span class="lineno">1313 </span>	<span class="k">else</span> <span class="p">{</span><sup class="after"></sup>\n' + 
'</span><span class="line-1314 line"><span class="lineno">1314 </span>		<span class="cm">/* IS_COMMENT */</span><sup class="after"></sup>\n' + 
'</span><span class="line-1315 line"><span class="lineno">1315 </span>		<span class="n">printf</span><span class="p">(</span><span class="s">&quot;%s&quot;</span><span class="p">,</span> <span class="n">sc_sa_comment</span><span class="p">);</span><sup class="after"></sup>\n' + 
'</span><span class="line-1316 line"><span class="lineno">1316 </span>	<span class="p">}</span><sup class="after"></sup>\n' + 
'</span><span class="line-1317 line"><span class="lineno">1317 </span>	<span class="n">printf</span><span class="p">(</span><span class="n">format</span><span class="p">,</span> <span class="n">string</span><span class="p">);</span><sup class="after"></sup>\n' + 
'</span><span class="line-1318 line"><span class="lineno">1318 </span>	<span class="n">printf</span><span class="p">(</span><span class="s">&quot;%s&quot;</span><span class="p">,</span> <span class="n">sc_normal</span><span class="p">);</span><sup class="after"></sup>\n' + 
'</span><span class="line-1319 line"><span class="lineno">1319 </span><span class="p">}</span><sup class="after"></sup>\n' + 
'</span><span class="line-1320 line"><span class="lineno">1320 </span><sup class="after"></sup>\n' + 
'</span><span class="line-1321 line"><span class="lineno">1321 </span><span class="cm">/*</span><sup class="after"></sup>\n' + 
'</span><span class="line-1322 line"><span class="lineno">1322 </span><span class="cm"> ***************************************************************************</span><sup class="after"></sup>\n' + 
'</span><span class="line-1323 line"><span class="lineno">1323 </span><span class="cm"> * Parse a string containing a numerical value (e.g. CPU or IRQ number).</span><sup class="after"></sup>\n' + 
'</span><span class="line-1324 line"><span class="lineno">1324 </span><span class="cm"> * The string should contain only one value, not a range of values.</span><sup class="after"></sup>\n' + 
'</span><span class="line-1325 line"><span class="lineno">1325 </span><span class="cm"> *</span><sup class="after"></sup>\n' + 
'</span><span class="line-1326 line"><span class="lineno">1326 </span><span class="cm"> * IN:</span><sup class="after"></sup>\n' + 
'</span><span class="line-1327 line"><span class="lineno">1327 </span><span class="cm"> * @s		String to parse.</span><sup class="after"></sup>\n' + 
'</span><span class="line-1328 line"><span class="lineno">1328 </span><span class="cm"> * @max_val	Upper limit that value should not reach.</span><sup class="after"></sup>\n' + 
'</span><span class="line-1329 line"><span class="lineno">1329 </span><span class="cm"> *</span><sup class="after"></sup>\n' + 
'</span><span class="line-1330 line"><span class="lineno">1330 </span><span class="cm"> * OUT:</span><sup class="after"></sup>\n' + 
'</span><span class="line-1331 line"><span class="lineno">1331 </span><span class="cm"> * @val		Value, or -1 if the string @s was empty.</span><sup class="after"></sup>\n' + 
'</span><span class="line-1332 line"><span class="lineno">1332 </span><span class="cm"> *</span><sup class="after"></sup>\n' + 
'</span><span class="line-1333 line"><span class="lineno">1333 </span><span class="cm"> * RETURNS:</span><sup class="after"></sup>\n' + 
'</span><span class="line-1334 line"><span class="lineno">1334 </span><span class="cm"> * 0 if the value has been properly read, 1 otherwise.</span><sup class="after"></sup>\n' + 
'</span><span class="line-1335 line"><span class="lineno">1335 </span><span class="cm"> ***************************************************************************</span><sup class="after"></sup>\n' + 
'</span><span class="line-1336 line"><span class="lineno">1336 </span><span class="cm"> */</span><sup class="after"></sup>\n' + 
'</span><span class="line-1337 line"><span class="lineno">1337 </span><span class="kt">int</span> <span class="nf">parse_valstr</span><span class="p">(</span><span class="kt">char</span> <span class="o">*</span><span class="n">s</span><span class="p">,</span> <span class="kt">int</span> <span class="n">max_val</span><span class="p">,</span> <span class="kt">int</span> <span class="o">*</span><span class="n">val</span><span class="p">)</span><sup class="after"></sup>\n' + 
'</span><span class="line-1338 line"><span class="lineno">1338 </span><span class="p">{</span><sup class="after"></sup>\n' + 
'</span><span class="line-1339 line"><span class="lineno">1339 </span>	<span class="k">if</span> <span class="p">(</span><span class="o">!</span><span class="n">strlen</span><span class="p">(</span><span class="n">s</span><span class="p">))</span> <span class="p">{</span><sup class="after"></sup>\n' + 
'</span><span class="line-1340 line"><span class="lineno">1340 </span>		<span class="o">*</span><span class="n">val</span> <span class="o">=</span> <span class="o">-</span><span class="mi">1</span><span class="p">;</span><sup class="after"></sup>\n' + 
'</span><span class="line-1341 line"><span class="lineno">1341 </span>		<span class="k">return</span> <span class="mi">0</span><span class="p">;</span><sup class="after"></sup>\n' + 
'</span><span class="line-1342 line"><span class="lineno">1342 </span>	<span class="p">}</span><sup class="after"></sup>\n' + 
'</span><span class="line-1343 line"><span class="lineno">1343 </span>	<span class="k">if</span> <span class="p">(</span><span class="n">strspn</span><span class="p">(</span><span class="n">s</span><span class="p">,</span> <span class="n">DIGITS</span><span class="p">)</span> <span class="o">!=</span> <span class="n">strlen</span><span class="p">(</span><span class="n">s</span><span class="p">))</span><sup class="after"></sup>\n' + 
'</span><span class="line-1344 line"><span class="lineno">1344 </span>		<span class="k">return</span> <span class="mi">1</span><span class="p">;</span><sup class="after"></sup>\n' + 
'</span><span class="line-1345 line"><span class="lineno">1345 </span><sup class="after"></sup>\n' + 
'</span><span class="line-1346 line"><span class="lineno">1346 </span>	<span class="o">*</span><span class="n">val</span> <span class="o">=</span> <span class="n">atoi</span><span class="p">(</span><span class="n">s</span><span class="p">);</span><sup class="after"></sup>\n' + 
'</span><span class="line-1347 line"><span class="lineno">1347 </span>	<span class="k">if</span> <span class="p">((</span><span class="o">*</span><span class="n">val</span> <span class="o">&lt;</span> <span class="mi">0</span><span class="p">)</span> <span class="o">||</span> <span class="p">(</span><span class="o">*</span><span class="n">val</span> <span class="o">&gt;=</span> <span class="n">max_val</span><span class="p">))</span><sup class="after"></sup>\n' + 
'</span><span class="line-1348 line"><span class="lineno">1348 </span>		<span class="k">return</span> <span class="mi">1</span><span class="p">;</span><sup class="after"></sup>\n' + 
'</span><span class="line-1349 line"><span class="lineno">1349 </span><sup class="after"></sup>\n' + 
'</span><span class="line-1350 line"><span class="lineno">1350 </span>	<span class="k">return</span> <span class="mi">0</span><span class="p">;</span><sup class="after"></sup>\n' + 
'</span><span class="line-1351 line"><span class="lineno">1351 </span><span class="p">}</span><sup class="after"></sup>\n' + 
'</span><span class="line-1352 line"><span class="lineno">1352 </span><sup class="after"></sup>\n' + 
'</span><span class="line-1353 line"><span class="lineno">1353 </span><span class="cm">/*</span><sup class="after"></sup>\n' + 
'</span><span class="line-1354 line"><span class="lineno">1354 </span><span class="cm"> ***************************************************************************</span><sup class="after"></sup>\n' + 
'</span><span class="line-1355 line"><span class="lineno">1355 </span><span class="cm"> * Parse string containing a set of coma-separated values or ranges of</span><sup class="after"></sup>\n' + 
'</span><span class="line-1356 line"><span class="lineno">1356 </span><span class="cm"> * values (e.g. &quot;0,2-5,10-&quot;). The ALL keyword is allowed and indicate that</span><sup class="after"></sup>\n' + 
'</span><span class="line-1357 line"><span class="lineno">1357 </span><span class="cm"> * all possible values are selected.</span><sup class="after"></sup>\n' + 
'</span><span class="line-1358 line"><span class="lineno">1358 </span><span class="cm"> *</span><sup class="after"></sup>\n' + 
'</span><span class="line-1359 line"><span class="lineno">1359 </span><span class="cm"> * IN:</span><sup class="after"></sup>\n' + 
'</span><span class="line-1360 line"><span class="lineno">1360 </span><span class="cm"> * @strargv	Current argument in list to parse.</span><sup class="after"></sup>\n' + 
'</span><span class="line-1361 line"><span class="lineno">1361 </span><span class="cm"> * @bitmap	Bitmap whose contents will indicate which values have been</span><sup class="after"></sup>\n' + 
'</span><span class="line-1362 line"><span class="lineno">1362 </span><span class="cm"> *		selected.</span><sup class="after"></sup>\n' + 
'</span><span class="line-1363 line"><span class="lineno">1363 </span><span class="cm"> * @max_val	Upper limit that value should not reach.</span><sup class="after"></sup>\n' + 
'</span><span class="line-1364 line"><span class="lineno">1364 </span><span class="cm"> * @__K_VALUE0	Keyword corresponding to the first bit in bitmap (e.g &quot;all&quot;,</span><sup class="after"></sup>\n' + 
'</span><span class="line-1365 line"><span class="lineno">1365 </span><span class="cm"> *		&quot;SUM&quot;...)</span><sup class="after"></sup>\n' + 
'</span><span class="line-1366 line"><span class="lineno">1366 </span><span class="cm"> *</span><sup class="after"></sup>\n' + 
'</span><span class="line-1367 line"><span class="lineno">1367 </span><span class="cm"> * OUT:</span><sup class="after"></sup>\n' + 
'</span><span class="line-1368 line"><span class="lineno">1368 </span><span class="cm"> * @bitmap	Bitmap updated with selected values.</span><sup class="after"></sup>\n' + 
'</span><span class="line-1369 line"><span class="lineno">1369 </span><span class="cm"> *</span><sup class="after"></sup>\n' + 
'</span><span class="line-1370 line"><span class="lineno">1370 </span><span class="cm"> * RETURNS:</span><sup class="after"></sup>\n' + 
'</span><span class="line-1371 line"><span class="lineno">1371 </span><span class="cm"> * 0 on success, 1 otherwise.</span><sup class="after"></sup>\n' + 
'</span><span class="line-1372 line"><span class="lineno">1372 </span><span class="cm"> ***************************************************************************</span><sup class="after"></sup>\n' + 
'</span><span class="line-1373 line"><span class="lineno">1373 </span><span class="cm"> */</span><sup class="after"></sup>\n' + 
'</span><span class="line-1374 line"><span class="lineno">1374 </span><span class="kt">int</span> <span class="nf">parse_values</span><span class="p">(</span><span class="kt">char</span> <span class="o">*</span><span class="n">strargv</span><span class="p">,</span> <span class="kt">unsigned</span> <span class="kt">char</span> <span class="n">bitmap</span><span class="p">[],</span> <span class="kt">int</span> <span class="n">max_val</span><span class="p">,</span> <span class="k">const</span> <span class="kt">char</span> <span class="o">*</span><span class="n">__K_VALUE0</span><span class="p">)</span><sup class="after"></sup>\n' + 
'</span><span class="line-1375 line"><span class="lineno">1375 </span><span class="p">{</span><sup class="after"></sup>\n' + 
'</span><span class="line-1376 line"><span class="lineno">1376 </span>	<span class="kt">int</span> <span class="n">i</span><span class="p">,</span> <span class="n">val_low</span><span class="p">,</span> <span class="n">val</span><span class="p">;</span><sup class="after"></sup>\n' + 
'</span><span class="line-1377 line"><span class="lineno">1377 </span>	<span class="kt">char</span> <span class="o">*</span><span class="n">t</span><span class="p">,</span> <span class="o">*</span><span class="n">s</span><span class="p">,</span> <span class="o">*</span><span class="n">valstr</span><span class="p">,</span> <span class="n">range</span><span class="p">[</span><span class="mi">16</span><span class="p">];</span><sup class="after"></sup>\n' + 
'</span><span class="line-1378 line"><span class="lineno">1378 </span><sup class="after"></sup>\n' + 
'</span><span class="line-1379 line"><span class="lineno">1379 </span>	<span class="k">if</span> <span class="p">(</span><span class="o">!</span><span class="n">strcmp</span><span class="p">(</span><span class="n">strargv</span><span class="p">,</span> <span class="n">K_ALL</span><span class="p">))</span> <span class="p">{</span><sup class="after"></sup>\n' + 
'</span><span class="line-1380 line"><span class="lineno">1380 </span>		<span class="cm">/* Set bit for every possible values (CPU, IRQ, etc.) */</span><sup class="after"></sup>\n' + 
'</span><span class="line-1381 line"><span class="lineno">1381 </span>		<span class="n">memset</span><span class="p">(</span><span class="n">bitmap</span><span class="p">,</span> <span class="o">~</span><span class="mi">0</span><span class="p">,</span> <span class="n">BITMAP_SIZE</span><span class="p">(</span><span class="n">max_val</span><span class="p">));</span><sup class="after"></sup>\n' + 
'</span><span class="line-1382 line"><span class="lineno">1382 </span>		<span class="k">return</span> <span class="mi">0</span><span class="p">;</span><sup class="after"></sup>\n' + 
'</span><span class="line-1383 line"><span class="lineno">1383 </span>	<span class="p">}</span><sup class="after"></sup>\n' + 
'</span><span class="line-1384 line"><span class="lineno">1384 </span><sup class="after"></sup>\n' + 
'</span><span class="line-1385 line"><span class="lineno">1385 </span>	<span class="k">for</span> <span class="p">(</span><span class="n">t</span> <span class="o">=</span> <span class="n">strtok</span><span class="p">(</span><span class="n">strargv</span><span class="p">,</span> <span class="s">&quot;,&quot;</span><span class="p">);</span> <span class="n">t</span><span class="p">;</span> <span class="n">t</span> <span class="o">=</span> <span class="n">strtok</span><span class="p">(</span><span class="nb">NULL</span><span class="p">,</span> <span class="s">&quot;,&quot;</span><span class="p">))</span> <span class="p">{</span><sup class="after"></sup>\n' + 
'</span><span class="line-1386 line"><span class="lineno">1386 </span>		<span class="k">if</span> <span class="p">(</span><span class="o">!</span><span class="n">strcmp</span><span class="p">(</span><span class="n">t</span><span class="p">,</span> <span class="n">__K_VALUE0</span><span class="p">))</span> <span class="p">{</span><sup class="after"></sup>\n' + 
'</span><span class="line-1387 line"><span class="lineno">1387 </span>			<span class="cm">/*</span><sup class="after"></sup>\n' + 
'</span><span class="line-1388 line"><span class="lineno">1388 </span><span class="cm">			 * Set bit 0 in bitmap. This may correspond</span><sup class="after"></sup>\n' + 
'</span><span class="line-1389 line"><span class="lineno">1389 </span><span class="cm">			 * to CPU &quot;all&quot; or IRQ &quot;SUM&quot; for example.</span><sup class="after"></sup>\n' + 
'</span><span class="line-1390 line"><span class="lineno">1390 </span><span class="cm">			 */</span><sup class="after"></sup>\n' + 
'</span><span class="line-1391 line"><span class="lineno">1391 </span>			<span class="n">bitmap</span><span class="p">[</span><span class="mi">0</span><span class="p">]</span> <span class="o">|=</span> <span class="mi">1</span><span class="p">;</span><sup class="after"></sup>\n' + 
'</span><span class="line-1392 line"><span class="lineno">1392 </span>		<span class="p">}</span><sup class="after"></sup>\n' + 
'</span><span class="line-1393 line"><span class="lineno">1393 </span>		<span class="k">else</span> <span class="p">{</span><sup class="after"></sup>\n' + 
'</span><span class="line-1394 line"><span class="lineno">1394 </span>			<span class="cm">/* Parse value or range of values */</span><sup class="after"></sup>\n' + 
'</span><span class="line-1395 line"><span class="lineno">1395 </span>			<span class="n">strncpy</span><span class="p">(</span><span class="n">range</span><span class="p">,</span> <span class="n">t</span><span class="p">,</span> <span class="mi">16</span><span class="p">);</span><sup class="after"></sup>\n' + 
'</span><span class="line-1396 line"><span class="lineno">1396 </span>			<span class="n">range</span><span class="p">[</span><span class="mi">15</span><span class="p">]</span> <span class="o">=</span> <span class="sc">&#39;\\0&#39;</span><span class="p">;</span><sup class="after"></sup>\n' + 
'</span><span class="line-1397 line"><span class="lineno">1397 </span>			<span class="n">valstr</span> <span class="o">=</span> <span class="n">t</span><span class="p">;</span><sup class="after"></sup>\n' + 
'</span><span class="line-1398 line"><span class="lineno">1398 </span>			<span class="k">if</span> <span class="p">((</span><span class="n">s</span> <span class="o">=</span> <span class="n">index</span><span class="p">(</span><span class="n">range</span><span class="p">,</span> <span class="sc">&#39;-&#39;</span><span class="p">))</span> <span class="o">!=</span> <span class="nb">NULL</span><span class="p">)</span> <span class="p">{</span><sup class="after"></sup>\n' + 
'</span><span class="line-1399 line"><span class="lineno">1399 </span>				<span class="cm">/* Possible range of values */</span><sup class="after"></sup>\n' + 
'</span><span class="line-1400 line"><span class="lineno">1400 </span>				<span class="o">*</span><span class="n">s</span> <span class="o">=</span> <span class="sc">&#39;\\0&#39;</span><span class="p">;</span><sup class="after"></sup>\n' + 
'</span><span class="line-1401 line"><span class="lineno">1401 </span>				<span class="k">if</span> <span class="p">(</span><span class="n">parse_valstr</span><span class="p">(</span><span class="n">range</span><span class="p">,</span> <span class="n">max_val</span><span class="p">,</span> <span class="o">&amp;</span><span class="n">val_low</span><span class="p">)</span> <span class="o">||</span> <span class="p">(</span><span class="n">val_low</span> <span class="o">&lt;</span> <span class="mi">0</span><span class="p">))</span><sup class="after"></sup>\n' + 
'</span><span class="line-1402 line"><span class="lineno">1402 </span>					<span class="k">return</span> <span class="mi">1</span><span class="p">;</span><sup class="after"></sup>\n' + 
'</span><span class="line-1403 line"><span class="lineno">1403 </span>				<span class="n">valstr</span> <span class="o">=</span> <span class="n">s</span> <span class="o">+</span> <span class="mi">1</span><span class="p">;</span><sup class="after"></sup>\n' + 
'</span><span class="line-1404 line"><span class="lineno">1404 </span>			<span class="p">}</span><sup class="after"></sup>\n' + 
'</span><span class="line-1405 line"><span class="lineno">1405 </span>			<span class="k">if</span> <span class="p">(</span><span class="n">parse_valstr</span><span class="p">(</span><span class="n">valstr</span><span class="p">,</span> <span class="n">max_val</span><span class="p">,</span> <span class="o">&amp;</span><span class="n">val</span><span class="p">))</span><sup class="after"></sup>\n' + 
'</span><span class="line-1406 line"><span class="lineno">1406 </span>				<span class="k">return</span> <span class="mi">1</span><span class="p">;</span><sup class="after"></sup>\n' + 
'</span><span class="line-1407 line"><span class="lineno">1407 </span>			<span class="k">if</span> <span class="p">(</span><span class="n">s</span> <span class="o">&amp;&amp;</span> <span class="n">val</span> <span class="o">&lt;</span> <span class="mi">0</span><span class="p">)</span> <span class="p">{</span><sup class="after"></sup>\n' + 
'</span><span class="line-1408 line"><span class="lineno">1408 </span>				<span class="cm">/* Range of values with no upper limit (e.g. &quot;3-&quot;) */</span><sup class="after"></sup>\n' + 
'</span><span class="line-1409 line"><span class="lineno">1409 </span>				<span class="n">val</span> <span class="o">=</span> <span class="n">max_val</span> <span class="o">-</span> <span class="mi">1</span><span class="p">;</span><sup class="after"></sup>\n' + 
'</span><span class="line-1410 line"><span class="lineno">1410 </span>			<span class="p">}</span><sup class="after"></sup>\n' + 
'</span><span class="line-1411 line"><span class="lineno">1411 </span>			<span class="k">if</span> <span class="p">((</span><span class="o">!</span><span class="n">s</span> <span class="o">&amp;&amp;</span> <span class="p">(</span><span class="n">val</span> <span class="o">&lt;</span> <span class="mi">0</span><span class="p">))</span> <span class="o">||</span> <span class="p">(</span><span class="n">s</span> <span class="o">&amp;&amp;</span> <span class="p">(</span><span class="n">val</span> <span class="o">&lt;</span> <span class="n">val_low</span><span class="p">)))</span><sup class="after"></sup>\n' + 
'</span><span class="line-1412 line"><span class="lineno">1412 </span>				<span class="cm">/*</span><sup class="after"></sup>\n' + 
'</span><span class="line-1413 line"><span class="lineno">1413 </span><span class="cm">				 * Individual value: string cannot be empty.</span><sup class="after"></sup>\n' + 
'</span><span class="line-1414 line"><span class="lineno">1414 </span><span class="cm">				 * Range of values: n-m: m can be empty (e.g. &quot;3-&quot;) but</span><sup class="after"></sup>\n' + 
'</span><span class="line-1415 line"><span class="lineno">1415 </span><span class="cm">				 * cannot be lower than n.</span><sup class="after"></sup>\n' + 
'</span><span class="line-1416 line"><span class="lineno">1416 </span><span class="cm">				 */</span><sup class="after"></sup>\n' + 
'</span><span class="line-1417 line"><span class="lineno">1417 </span>				<span class="k">return</span> <span class="mi">1</span><span class="p">;</span><sup class="after"></sup>\n' + 
'</span><span class="line-1418 line"><span class="lineno">1418 </span>			<span class="k">if</span> <span class="p">(</span><span class="o">!</span><span class="n">s</span><span class="p">)</span> <span class="p">{</span><sup class="after"></sup>\n' + 
'</span><span class="line-1419 line"><span class="lineno">1419 </span>				<span class="n">val_low</span> <span class="o">=</span> <span class="n">val</span><span class="p">;</span><sup class="after"></sup>\n' + 
'</span><span class="line-1420 line"><span class="lineno">1420 </span>			<span class="p">}</span><sup class="after"></sup>\n' + 
'</span><span class="line-1421 line"><span class="lineno">1421 </span>			<span class="k">for</span> <span class="p">(</span><span class="n">i</span> <span class="o">=</span> <span class="n">val_low</span><span class="p">;</span> <span class="n">i</span> <span class="o">&lt;=</span> <span class="n">val</span><span class="p">;</span> <span class="n">i</span><span class="o">++</span><span class="p">)</span> <span class="p">{</span><sup class="after"></sup>\n' + 
'</span><span class="line-1422 line"><span class="lineno">1422 </span>				<span class="n">bitmap</span><span class="p">[(</span><span class="n">i</span> <span class="o">+</span> <span class="mi">1</span><span class="p">)</span> <span class="o">&gt;&gt;</span> <span class="mi">3</span><span class="p">]</span> <span class="o">|=</span> <span class="mi">1</span> <span class="o">&lt;&lt;</span> <span class="p">((</span><span class="n">i</span> <span class="o">+</span> <span class="mi">1</span><span class="p">)</span> <span class="o">&amp;</span> <span class="mh">0x07</span><span class="p">);</span><sup class="after"></sup>\n' + 
'</span><span class="line-1423 line"><span class="lineno">1423 </span>			<span class="p">}</span><sup class="after"></sup>\n' + 
'</span><span class="line-1424 line"><span class="lineno">1424 </span>		<span class="p">}</span><sup class="after"></sup>\n' + 
'</span><span class="line-1425 line"><span class="lineno">1425 </span>	<span class="p">}</span><sup class="after"></sup>\n' + 
'</span><span class="line-1426 line"><span class="lineno">1426 </span><sup class="after"></sup>\n' + 
'</span><span class="line-1427 line"><span class="lineno">1427 </span>	<span class="k">return</span> <span class="mi">0</span><span class="p">;</span><sup class="after"></sup>\n' + 
'</span><span class="line-1428 line"><span class="lineno">1428 </span><span class="p">}</span><sup class="after"></sup>\n' + 
'</span><span class="line-1429 line"><span class="lineno">1429 </span><span class="cp">#endif </span><span class="cm">/* SOURCE_SADC undefined */</span><span class="cp"></span><sup class="after"></sup>\n' + 
'</span></div>'
