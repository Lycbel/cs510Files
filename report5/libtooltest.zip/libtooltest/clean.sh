rm -R temp >/dev/null 2>&1
rm -R .libs >/dev/null 2>&1
rm *.o >/dev/null 2>&1
rm *.lo >/dev/null 2>&1
rm *.la >/dev/null 2>&1
